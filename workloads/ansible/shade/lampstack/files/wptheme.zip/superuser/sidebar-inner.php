<?php
/**
 * The sidebar containing the inner-sidebar widget area.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package superuser
 */

?>
<div class="sidebar col col--1-of-3">
  <div class="<?php is_search() ? '' : 'sticky'; ?>">
  	<ul class="toplist">
  		<?php 

  		$postas = new WP_Query(array( 
					   'posts_per_page' => 15,
					   'orderby' => 'rand'
					) ); ?>
  		<?php
			if ( $postas->have_posts() ) {
				$i=0;
				while ( $postas->have_posts() ) {
					$postas->the_post();		
					if($i <= 1){
					?>
						<li id="post-<?php the_ID(); ?>" <?php post_class('mobile-grid articles-list'); ?> >
							<div class="mobile-col articles-list__item">
								<div class="article-card">
									<a href="<?php the_permalink(); ?>">
										<div class="article-cover">
											<?php echo get_image_or_fallback($post->ID, 'featured-image');?>
											<div class="date">
												<?php echo get_the_date(); ?>
											</div>
										</div>
										<div class="content">
											<h3><?php the_title(); ?></h3>
										</div>
										<div class="rider">
											<?php the_excerpt(); ?>
										</div>
										<div class="metadata">
											<div class="author">
												<?php echo get_authors_list(20, false); ?>
											</div>
										</div>
									</a>
								</div>
							</div>
						</li>
					<?php
					} /*elseif($i <= 3){
					?>
						<li class="toplist__item large">
							<a class="toplist__link" href="<?php the_permalink(); ?>">
								<img src="<?php the_post_thumbnail_url( 'featured-half-image' ); ?>" class="cover-image" alt="Build it yourself: How a small team deployed OpenStack">
								<h4><?php the_title(); ?></h4>
							</a>
						</li>
					<?php
					} */ elseif($i <= 14){
					?>
						<li class="toplist__item">
							<a class="toplist__link" href="<?php the_permalink(); ?>">
								<?php echo get_image_or_fallback($post->ID, 'thumbnail');?>
								<h4><?php the_title(); ?></h4>
							</a>
						</li>
					<?php	
					}
				$i++;
			?>



				<?php
				}
			}
			?>
  	</ul>
  </div>
</div>
