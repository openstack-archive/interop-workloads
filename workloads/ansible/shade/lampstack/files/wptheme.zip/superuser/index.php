<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package superuser
 */

get_header(); 


?>

	<main id="main" class="site-main" role="main">
		<div class="container main-container">
			<div class="grid">
				<div class="col col--2-of-3">
				<?php
			if (required_plugins()){ 
				echo required_plugins();
			} else {
				if ( have_posts() ) :

					if ( is_archive() || is_tag() ) : ?>
						<header>
							<div class="article-category">
								<span><?php if ( is_tag() ) {?>Tag: <?php } ?><?php single_cat_title(); ?></span>
							</div>
						</header>
					<?php
					endif;
					?>
						<div class="main-grid"> 
							<ul class="articles-list">
							<?php
								show_featured_area();
								/* Start the Loop */
								while ( have_posts() ) : the_post();

									get_template_part( 'template-parts/content', get_post_format() );

								endwhile;						
							?>
							</ul>
						</div>
				<?php
				else :

					get_template_part( 'template-parts/content', 'none' );

				endif; 

				?>
				</div>
				<?php if ($paged<=1){ 
					get_sidebar();
					} 
			}// end if required_plugins() 
			?>
			</div><!-- #grid -->	
		</div><!-- #container -->
	</main><!-- #main -->


<?php
get_footer();
