<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package superuser
 */

?>

	</div><!-- #content -->
	<footer class="page-footer">
		<div class="container">
			<div class="grid">
				<div class="col col--2-of-3">
				<?php if ( is_nav_menu( 'Superuser' )) { ?>
					<section class="nav-group widget widget_nav_menu">
					<h4>Superuser</h4>
					<?php 
					wp_nav_menu( array(
					    'menu' => 'Superuser',
					    'container' => 'div',
					    'container_class' => 'menu-container',
					) );
					?>
					</section>
				<?php } ?>
				<?php if ( is_nav_menu( 'Community' )) { ?>
					<section class="nav-group widget widget_nav_menu">
					<h4>Community</h4>
					<?php
					wp_nav_menu( array(
					    'menu' => 'Community',
					    'container' => 'div',
					    'container_class' => 'menu-container',
					) );
					?>
					</section>
				<?php } ?>
				<?php if ( is_nav_menu( 'User Resources' )) { ?>
					<section class="nav-group widget widget_nav_menu">
					<h4>User Resources</h4>
					<?php
					wp_nav_menu( array(
					    'menu' => 'User Resources',
					    'container' => 'div',
					    'container_class' => 'menu-container',
					) );
					?>
					</section>
				<?php } ?>
					<hr>
					<div class="grid">
						<div class="col col--1-of-3">
							<div class="logo">
								<img src="<?php echo get_template_directory_uri(); ?>/images/superuser.svg" class="logomark" alt="&gt; SU">
							</div>
						</div>
						<div class="col col--2-of-3">
							<div class="about-blurb site-description">
								<p><?php echo get_bloginfo('description'); ?></p>
							</div>
						</div>
					</div>
				</div>
				<div class="col col--1-of-3">
					<div class="character">
					</div>
					<?php // I hate doing this, but Open Graph is picking up and using this image instead of what is specified in OpenGraph tags ?>
					<script type="text/javascript">
						setTimeout(function(){
							try {
								document.querySelector('.character').innerHTML = '<img src="<?php echo get_template_directory_uri(); ?>/images/superuser-character.png" alt="Superuser character">';
							}catch(e){}
						}, 300);
					</script>
				</div>
			</div>
		</div>
	</footer>
</div><!-- #page -->

<?php wp_footer(); ?>
<script>
jQuery( document ).ready(function() {
	jQuery(".article-body iframe").parent('p').css("margin-left", "0px");
	jQuery(".article-body iframe").parent('p').css("margin-right", "0px");
});
</script>
</body>
</html>
