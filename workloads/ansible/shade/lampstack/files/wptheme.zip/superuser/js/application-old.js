/*!
 * jQuery JavaScript Library v1.11.0
 * http://jquery.com/
 *
 * Includes Sizzle.js
 * http://sizzlejs.com/
 *
 * Copyright 2005, 2014 jQuery Foundation, Inc. and other contributors
 * Released under the MIT license
 * http://jquery.org/license
 *
 * Date: 2014-01-23T21:02Z
 */
! function(t, e) {
    "object" == typeof module && "object" == typeof module.exports ? module.exports = t.document ? e(t, !0) : function(t) {
        if (!t.document) throw new Error("jQuery requires a window with a document");
        return e(t)
    } : e(t)
}("undefined" != typeof window ? window : this, function(t, e) {
    function n(t) {
        var e = t.length,
            n = oe.type(t);
        return "function" === n || oe.isWindow(t) ? !1 : 1 === t.nodeType && e ? !0 : "array" === n || 0 === e || "number" == typeof e && e > 0 && e - 1 in t
    }

    function r(t, e, n) {
        if (oe.isFunction(e)) return oe.grep(t, function(t, r) {
            return !!e.call(t, r, t) !== n
        });
        if (e.nodeType) return oe.grep(t, function(t) {
            return t === e !== n
        });
        if ("string" == typeof e) {
            if (he.test(e)) return oe.filter(e, t, n);
            e = oe.filter(e, t)
        }
        return oe.grep(t, function(t) {
            return oe.inArray(t, e) >= 0 !== n
        })
    }

    function i(t, e) {
        do t = t[e]; while (t && 1 !== t.nodeType);
        return t
    }

    function o(t) {
        var e = be[t] = {};
        return oe.each(t.match(xe) || [], function(t, n) {
            e[n] = !0
        }), e
    }

    function s() {
        me.addEventListener ? (me.removeEventListener("DOMContentLoaded", a, !1), t.removeEventListener("load", a, !1)) : (me.detachEvent("onreadystatechange", a), t.detachEvent("onload", a))
    }

    function a() {
        (me.addEventListener || "load" === event.type || "complete" === me.readyState) && (s(), oe.ready())
    }

    function l(t, e, n) {
        if (void 0 === n && 1 === t.nodeType) {
            var r = "data-" + e.replace(Ce, "-$1").toLowerCase();
            if (n = t.getAttribute(r), "string" == typeof n) {
                try {
                    n = "true" === n ? !0 : "false" === n ? !1 : "null" === n ? null : +n + "" === n ? +n : Se.test(n) ? oe.parseJSON(n) : n
                } catch (i) {}
                oe.data(t, e, n)
            } else n = void 0
        }
        return n
    }

    function u(t) {
        var e;
        for (e in t)
            if (("data" !== e || !oe.isEmptyObject(t[e])) && "toJSON" !== e) return !1;
        return !0
    }

    function c(t, e, n, r) {
        if (oe.acceptData(t)) {
            var i, o, s = oe.expando,
                a = t.nodeType,
                l = a ? oe.cache : t,
                u = a ? t[s] : t[s] && s;
            if (u && l[u] && (r || l[u].data) || void 0 !== n || "string" != typeof e) return u || (u = a ? t[s] = V.pop() || oe.guid++ : s), l[u] || (l[u] = a ? {} : {
                toJSON: oe.noop
            }), ("object" == typeof e || "function" == typeof e) && (r ? l[u] = oe.extend(l[u], e) : l[u].data = oe.extend(l[u].data, e)), o = l[u], r || (o.data || (o.data = {}), o = o.data), void 0 !== n && (o[oe.camelCase(e)] = n), "string" == typeof e ? (i = o[e], null == i && (i = o[oe.camelCase(e)])) : i = o, i
        }
    }

    function f(t, e, n) {
        if (oe.acceptData(t)) {
            var r, i, o = t.nodeType,
                s = o ? oe.cache : t,
                a = o ? t[oe.expando] : oe.expando;
            if (s[a]) {
                if (e && (r = n ? s[a] : s[a].data)) {
                    oe.isArray(e) ? e = e.concat(oe.map(e, oe.camelCase)) : e in r ? e = [e] : (e = oe.camelCase(e), e = e in r ? [e] : e.split(" ")), i = e.length;
                    for (; i--;) delete r[e[i]];
                    if (n ? !u(r) : !oe.isEmptyObject(r)) return
                }(n || (delete s[a].data, u(s[a]))) && (o ? oe.cleanData([t], !0) : re.deleteExpando || s != s.window ? delete s[a] : s[a] = null)
            }
        }
    }

    function p() {
        return !0
    }

    function h() {
        return !1
    }

    function d() {
        try {
            return me.activeElement
        } catch (t) {}
    }

    function m(t) {
        var e = Fe.split("|"),
            n = t.createDocumentFragment();
        if (n.createElement)
            for (; e.length;) n.createElement(e.pop());
        return n
    }

    function g(t, e) {
        var n, r, i = 0,
            o = typeof t.getElementsByTagName !== ke ? t.getElementsByTagName(e || "*") : typeof t.querySelectorAll !== ke ? t.querySelectorAll(e || "*") : void 0;
        if (!o)
            for (o = [], n = t.childNodes || t; null != (r = n[i]); i++) !e || oe.nodeName(r, e) ? o.push(r) : oe.merge(o, g(r, e));
        return void 0 === e || e && oe.nodeName(t, e) ? oe.merge([t], o) : o
    }

    function v(t) {
        Oe.test(t.type) && (t.defaultChecked = t.checked)
    }

    function y(t, e) {
        return oe.nodeName(t, "table") && oe.nodeName(11 !== e.nodeType ? e : e.firstChild, "tr") ? t.getElementsByTagName("tbody")[0] || t.appendChild(t.ownerDocument.createElement("tbody")) : t
    }

    function _(t) {
        return t.type = (null !== oe.find.attr(t, "type")) + "/" + t.type, t
    }

    function x(t) {
        var e = Ve.exec(t.type);
        return e ? t.type = e[1] : t.removeAttribute("type"), t
    }

    function b(t, e) {
        for (var n, r = 0; null != (n = t[r]); r++) oe._data(n, "globalEval", !e || oe._data(e[r], "globalEval"))
    }

    function w(t, e) {
        if (1 === e.nodeType && oe.hasData(t)) {
            var n, r, i, o = oe._data(t),
                s = oe._data(e, o),
                a = o.events;
            if (a) {
                delete s.handle, s.events = {};
                for (n in a)
                    for (r = 0, i = a[n].length; i > r; r++) oe.event.add(e, n, a[n][r])
            }
            s.data && (s.data = oe.extend({}, s.data))
        }
    }

    function T(t, e) {
        var n, r, i;
        if (1 === e.nodeType) {
            if (n = e.nodeName.toLowerCase(), !re.noCloneEvent && e[oe.expando]) {
                i = oe._data(e);
                for (r in i.events) oe.removeEvent(e, r, i.handle);
                e.removeAttribute(oe.expando)
            }
            "script" === n && e.text !== t.text ? (_(e).text = t.text, x(e)) : "object" === n ? (e.parentNode && (e.outerHTML = t.outerHTML), re.html5Clone && t.innerHTML && !oe.trim(e.innerHTML) && (e.innerHTML = t.innerHTML)) : "input" === n && Oe.test(t.type) ? (e.defaultChecked = e.checked = t.checked, e.value !== t.value && (e.value = t.value)) : "option" === n ? e.defaultSelected = e.selected = t.defaultSelected : ("input" === n || "textarea" === n) && (e.defaultValue = t.defaultValue)
        }
    }

    function k(e, n) {
        var r = oe(n.createElement(e)).appendTo(n.body),
            i = t.getDefaultComputedStyle ? t.getDefaultComputedStyle(r[0]).display : oe.css(r[0], "display");
        return r.detach(), i
    }

    function S(t) {
        var e = me,
            n = tn[t];
        return n || (n = k(t, e), "none" !== n && n || (Je = (Je || oe("<iframe frameborder='0' width='0' height='0'/>")).appendTo(e.documentElement), e = (Je[0].contentWindow || Je[0].contentDocument).document, e.write(), e.close(), n = k(t, e), Je.detach()), tn[t] = n), n
    }

    function C(t, e) {
        return {
            get: function() {
                var n = t();
                if (null != n) return n ? void delete this.get : (this.get = e).apply(this, arguments)
            }
        }
    }

    function P(t, e) {
        if (e in t) return e;
        for (var n = e.charAt(0).toUpperCase() + e.slice(1), r = e, i = dn.length; i--;)
            if (e = dn[i] + n, e in t) return e;
        return r
    }

    function E(t, e) {
        for (var n, r, i, o = [], s = 0, a = t.length; a > s; s++) r = t[s], r.style && (o[s] = oe._data(r, "olddisplay"), n = r.style.display, e ? (o[s] || "none" !== n || (r.style.display = ""), "" === r.style.display && Ae(r) && (o[s] = oe._data(r, "olddisplay", S(r.nodeName)))) : o[s] || (i = Ae(r), (n && "none" !== n || !i) && oe._data(r, "olddisplay", i ? n : oe.css(r, "display"))));
        for (s = 0; a > s; s++) r = t[s], r.style && (e && "none" !== r.style.display && "" !== r.style.display || (r.style.display = e ? o[s] || "" : "none"));
        return t
    }

    function A(t, e, n) {
        var r = cn.exec(e);
        return r ? Math.max(0, r[1] - (n || 0)) + (r[2] || "px") : e
    }

    function N(t, e, n, r, i) {
        for (var o = n === (r ? "border" : "content") ? 4 : "width" === e ? 1 : 0, s = 0; 4 > o; o += 2) "margin" === n && (s += oe.css(t, n + Ee[o], !0, i)), r ? ("content" === n && (s -= oe.css(t, "padding" + Ee[o], !0, i)), "margin" !== n && (s -= oe.css(t, "border" + Ee[o] + "Width", !0, i))) : (s += oe.css(t, "padding" + Ee[o], !0, i), "padding" !== n && (s += oe.css(t, "border" + Ee[o] + "Width", !0, i)));
        return s
    }

    function O(t, e, n) {
        var r = !0,
            i = "width" === e ? t.offsetWidth : t.offsetHeight,
            o = en(t),
            s = re.boxSizing() && "border-box" === oe.css(t, "boxSizing", !1, o);
        if (0 >= i || null == i) {
            if (i = nn(t, e, o), (0 > i || null == i) && (i = t.style[e]), on.test(i)) return i;
            r = s && (re.boxSizingReliable() || i === t.style[e]), i = parseFloat(i) || 0
        }
        return i + N(t, e, n || (s ? "border" : "content"), r, o) + "px"
    }

    function j(t, e, n, r, i) {
        return new j.prototype.init(t, e, n, r, i)
    }

    function D() {
        return setTimeout(function() {
            mn = void 0
        }), mn = oe.now()
    }

    function M(t, e) {
        var n, r = {
                height: t
            },
            i = 0;
        for (e = e ? 1 : 0; 4 > i; i += 2 - e) n = Ee[i], r["margin" + n] = r["padding" + n] = t;
        return e && (r.opacity = r.width = t), r
    }

    function L(t, e, n) {
        for (var r, i = (bn[e] || []).concat(bn["*"]), o = 0, s = i.length; s > o; o++)
            if (r = i[o].call(n, e, t)) return r
    }

    function R(t, e, n) {
        var r, i, o, s, a, l, u, c, f = this,
            p = {},
            h = t.style,
            d = t.nodeType && Ae(t),
            m = oe._data(t, "fxshow");
        n.queue || (a = oe._queueHooks(t, "fx"), null == a.unqueued && (a.unqueued = 0, l = a.empty.fire, a.empty.fire = function() {
            a.unqueued || l()
        }), a.unqueued++, f.always(function() {
            f.always(function() {
                a.unqueued--, oe.queue(t, "fx").length || a.empty.fire()
            })
        })), 1 === t.nodeType && ("height" in e || "width" in e) && (n.overflow = [h.overflow, h.overflowX, h.overflowY], u = oe.css(t, "display"), c = S(t.nodeName), "none" === u && (u = c), "inline" === u && "none" === oe.css(t, "float") && (re.inlineBlockNeedsLayout && "inline" !== c ? h.zoom = 1 : h.display = "inline-block")), n.overflow && (h.overflow = "hidden", re.shrinkWrapBlocks() || f.always(function() {
            h.overflow = n.overflow[0], h.overflowX = n.overflow[1], h.overflowY = n.overflow[2]
        }));
        for (r in e)
            if (i = e[r], vn.exec(i)) {
                if (delete e[r], o = o || "toggle" === i, i === (d ? "hide" : "show")) {
                    if ("show" !== i || !m || void 0 === m[r]) continue;
                    d = !0
                }
                p[r] = m && m[r] || oe.style(t, r)
            }
        if (!oe.isEmptyObject(p)) {
            m ? "hidden" in m && (d = m.hidden) : m = oe._data(t, "fxshow", {}), o && (m.hidden = !d), d ? oe(t).show() : f.done(function() {
                oe(t).hide()
            }), f.done(function() {
                var e;
                oe._removeData(t, "fxshow");
                for (e in p) oe.style(t, e, p[e])
            });
            for (r in p) s = L(d ? m[r] : 0, r, f), r in m || (m[r] = s.start, d && (s.end = s.start, s.start = "width" === r || "height" === r ? 1 : 0))
        }
    }

    function F(t, e) {
        var n, r, i, o, s;
        for (n in t)
            if (r = oe.camelCase(n), i = e[r], o = t[n], oe.isArray(o) && (i = o[1], o = t[n] = o[0]), n !== r && (t[r] = o, delete t[n]), s = oe.cssHooks[r], s && "expand" in s) {
                o = s.expand(o), delete t[r];
                for (n in o) n in t || (t[n] = o[n], e[n] = i)
            } else e[r] = i
    }

    function q(t, e, n) {
        var r, i, o = 0,
            s = xn.length,
            a = oe.Deferred().always(function() {
                delete l.elem
            }),
            l = function() {
                if (i) return !1;
                for (var e = mn || D(), n = Math.max(0, u.startTime + u.duration - e), r = n / u.duration || 0, o = 1 - r, s = 0, l = u.tweens.length; l > s; s++) u.tweens[s].run(o);
                return a.notifyWith(t, [u, o, n]), 1 > o && l ? n : (a.resolveWith(t, [u]), !1)
            },
            u = a.promise({
                elem: t,
                props: oe.extend({}, e),
                opts: oe.extend(!0, {
                    specialEasing: {}
                }, n),
                originalProperties: e,
                originalOptions: n,
                startTime: mn || D(),
                duration: n.duration,
                tweens: [],
                createTween: function(e, n) {
                    var r = oe.Tween(t, u.opts, e, n, u.opts.specialEasing[e] || u.opts.easing);
                    return u.tweens.push(r), r
                },
                stop: function(e) {
                    var n = 0,
                        r = e ? u.tweens.length : 0;
                    if (i) return this;
                    for (i = !0; r > n; n++) u.tweens[n].run(1);
                    return e ? a.resolveWith(t, [u, e]) : a.rejectWith(t, [u, e]), this
                }
            }),
            c = u.props;
        for (F(c, u.opts.specialEasing); s > o; o++)
            if (r = xn[o].call(u, t, c, u.opts)) return r;
        return oe.map(c, L, u), oe.isFunction(u.opts.start) && u.opts.start.call(t, u), oe.fx.timer(oe.extend(l, {
            elem: t,
            anim: u,
            queue: u.opts.queue
        })), u.progress(u.opts.progress).done(u.opts.done, u.opts.complete).fail(u.opts.fail).always(u.opts.always)
    }

    function H(t) {
        return function(e, n) {
            "string" != typeof e && (n = e, e = "*");
            var r, i = 0,
                o = e.toLowerCase().match(xe) || [];
            if (oe.isFunction(n))
                for (; r = o[i++];) "+" === r.charAt(0) ? (r = r.slice(1) || "*", (t[r] = t[r] || []).unshift(n)) : (t[r] = t[r] || []).push(n)
        }
    }

    function I(t, e, n, r) {
        function i(a) {
            var l;
            return o[a] = !0, oe.each(t[a] || [], function(t, a) {
                var u = a(e, n, r);
                return "string" != typeof u || s || o[u] ? s ? !(l = u) : void 0 : (e.dataTypes.unshift(u), i(u), !1)
            }), l
        }
        var o = {},
            s = t === Wn;
        return i(e.dataTypes[0]) || !o["*"] && i("*")
    }

    function z(t, e) {
        var n, r, i = oe.ajaxSettings.flatOptions || {};
        for (r in e) void 0 !== e[r] && ((i[r] ? t : n || (n = {}))[r] = e[r]);
        return n && oe.extend(!0, t, n), t
    }

    function X(t, e, n) {
        for (var r, i, o, s, a = t.contents, l = t.dataTypes;
            "*" === l[0];) l.shift(), void 0 === i && (i = t.mimeType || e.getResponseHeader("Content-Type"));
        if (i)
            for (s in a)
                if (a[s] && a[s].test(i)) {
                    l.unshift(s);
                    break
                }
        if (l[0] in n) o = l[0];
        else {
            for (s in n) {
                if (!l[0] || t.converters[s + " " + l[0]]) {
                    o = s;
                    break
                }
                r || (r = s)
            }
            o = o || r
        }
        return o ? (o !== l[0] && l.unshift(o), n[o]) : void 0
    }

    function B(t, e, n, r) {
        var i, o, s, a, l, u = {},
            c = t.dataTypes.slice();
        if (c[1])
            for (s in t.converters) u[s.toLowerCase()] = t.converters[s];
        for (o = c.shift(); o;)
            if (t.responseFields[o] && (n[t.responseFields[o]] = e), !l && r && t.dataFilter && (e = t.dataFilter(e, t.dataType)), l = o, o = c.shift())
                if ("*" === o) o = l;
                else if ("*" !== l && l !== o) {
            if (s = u[l + " " + o] || u["* " + o], !s)
                for (i in u)
                    if (a = i.split(" "), a[1] === o && (s = u[l + " " + a[0]] || u["* " + a[0]])) {
                        s === !0 ? s = u[i] : u[i] !== !0 && (o = a[0], c.unshift(a[1]));
                        break
                    }
            if (s !== !0)
                if (s && t["throws"]) e = s(e);
                else try {
                    e = s(e)
                } catch (f) {
                    return {
                        state: "parsererror",
                        error: s ? f : "No conversion from " + l + " to " + o
                    }
                }
        }
        return {
            state: "success",
            data: e
        }
    }

    function $(t, e, n, r) {
        var i;
        if (oe.isArray(e)) oe.each(e, function(e, i) {
            n || Qn.test(t) ? r(t, i) : $(t + "[" + ("object" == typeof i ? e : "") + "]", i, n, r)
        });
        else if (n || "object" !== oe.type(e)) r(t, e);
        else
            for (i in e) $(t + "[" + i + "]", e[i], n, r)
    }

    function W() {
        try {
            return new t.XMLHttpRequest
        } catch (e) {}
    }

    function Y() {
        try {
            return new t.ActiveXObject("Microsoft.XMLHTTP")
        } catch (e) {}
    }

    function U(t) {
        return oe.isWindow(t) ? t : 9 === t.nodeType ? t.defaultView || t.parentWindow : !1
    }
    var V = [],
        Q = V.slice,
        G = V.concat,
        Z = V.push,
        K = V.indexOf,
        J = {},
        te = J.toString,
        ee = J.hasOwnProperty,
        ne = "".trim,
        re = {},
        ie = "1.11.0",
        oe = function(t, e) {
            return new oe.fn.init(t, e)
        },
        se = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
        ae = /^-ms-/,
        le = /-([\da-z])/gi,
        ue = function(t, e) {
            return e.toUpperCase()
        };
    oe.fn = oe.prototype = {
        jquery: ie,
        constructor: oe,
        selector: "",
        length: 0,
        toArray: function() {
            return Q.call(this)
        },
        get: function(t) {
            return null != t ? 0 > t ? this[t + this.length] : this[t] : Q.call(this)
        },
        pushStack: function(t) {
            var e = oe.merge(this.constructor(), t);
            return e.prevObject = this, e.context = this.context, e
        },
        each: function(t, e) {
            return oe.each(this, t, e)
        },
        map: function(t) {
            return this.pushStack(oe.map(this, function(e, n) {
                return t.call(e, n, e)
            }))
        },
        slice: function() {
            return this.pushStack(Q.apply(this, arguments))
        },
        first: function() {
            return this.eq(0)
        },
        last: function() {
            return this.eq(-1)
        },
        eq: function(t) {
            var e = this.length,
                n = +t + (0 > t ? e : 0);
            return this.pushStack(n >= 0 && e > n ? [this[n]] : [])
        },
        end: function() {
            return this.prevObject || this.constructor(null)
        },
        push: Z,
        sort: V.sort,
        splice: V.splice
    }, oe.extend = oe.fn.extend = function() {
        var t, e, n, r, i, o, s = arguments[0] || {},
            a = 1,
            l = arguments.length,
            u = !1;
        for ("boolean" == typeof s && (u = s, s = arguments[a] || {}, a++), "object" == typeof s || oe.isFunction(s) || (s = {}), a === l && (s = this, a--); l > a; a++)
            if (null != (i = arguments[a]))
                for (r in i) t = s[r], n = i[r], s !== n && (u && n && (oe.isPlainObject(n) || (e = oe.isArray(n))) ? (e ? (e = !1, o = t && oe.isArray(t) ? t : []) : o = t && oe.isPlainObject(t) ? t : {}, s[r] = oe.extend(u, o, n)) : void 0 !== n && (s[r] = n));
        return s
    }, oe.extend({
        expando: "jQuery" + (ie + Math.random()).replace(/\D/g, ""),
        isReady: !0,
        error: function(t) {
            throw new Error(t)
        },
        noop: function() {},
        isFunction: function(t) {
            return "function" === oe.type(t)
        },
        isArray: Array.isArray || function(t) {
            return "array" === oe.type(t)
        },
        isWindow: function(t) {
            return null != t && t == t.window
        },
        isNumeric: function(t) {
            return t - parseFloat(t) >= 0
        },
        isEmptyObject: function(t) {
            var e;
            for (e in t) return !1;
            return !0
        },
        isPlainObject: function(t) {
            var e;
            if (!t || "object" !== oe.type(t) || t.nodeType || oe.isWindow(t)) return !1;
            try {
                if (t.constructor && !ee.call(t, "constructor") && !ee.call(t.constructor.prototype, "isPrototypeOf")) return !1
            } catch (n) {
                return !1
            }
            if (re.ownLast)
                for (e in t) return ee.call(t, e);
            for (e in t);
            return void 0 === e || ee.call(t, e)
        },
        type: function(t) {
            return null == t ? t + "" : "object" == typeof t || "function" == typeof t ? J[te.call(t)] || "object" : typeof t
        },
        globalEval: function(e) {
            e && oe.trim(e) && (t.execScript || function(e) {
                t.eval.call(t, e)
            })(e)
        },
        camelCase: function(t) {
            return t.replace(ae, "ms-").replace(le, ue)
        },
        nodeName: function(t, e) {
            return t.nodeName && t.nodeName.toLowerCase() === e.toLowerCase()
        },
        each: function(t, e, r) {
            var i, o = 0,
                s = t.length,
                a = n(t);
            if (r) {
                if (a)
                    for (; s > o && (i = e.apply(t[o], r), i !== !1); o++);
                else
                    for (o in t)
                        if (i = e.apply(t[o], r), i === !1) break
            } else if (a)
                for (; s > o && (i = e.call(t[o], o, t[o]), i !== !1); o++);
            else
                for (o in t)
                    if (i = e.call(t[o], o, t[o]), i === !1) break; return t
        },
        trim: ne && !ne.call("\ufeff\xa0") ? function(t) {
            return null == t ? "" : ne.call(t)
        } : function(t) {
            return null == t ? "" : (t + "").replace(se, "")
        },
        makeArray: function(t, e) {
            var r = e || [];
            return null != t && (n(Object(t)) ? oe.merge(r, "string" == typeof t ? [t] : t) : Z.call(r, t)), r
        },
        inArray: function(t, e, n) {
            var r;
            if (e) {
                if (K) return K.call(e, t, n);
                for (r = e.length, n = n ? 0 > n ? Math.max(0, r + n) : n : 0; r > n; n++)
                    if (n in e && e[n] === t) return n
            }
            return -1
        },
        merge: function(t, e) {
            for (var n = +e.length, r = 0, i = t.length; n > r;) t[i++] = e[r++];
            if (n !== n)
                for (; void 0 !== e[r];) t[i++] = e[r++];
            return t.length = i, t
        },
        grep: function(t, e, n) {
            for (var r, i = [], o = 0, s = t.length, a = !n; s > o; o++) r = !e(t[o], o), r !== a && i.push(t[o]);
            return i
        },
        map: function(t, e, r) {
            var i, o = 0,
                s = t.length,
                a = n(t),
                l = [];
            if (a)
                for (; s > o; o++) i = e(t[o], o, r), null != i && l.push(i);
            else
                for (o in t) i = e(t[o], o, r), null != i && l.push(i);
            return G.apply([], l)
        },
        guid: 1,
        proxy: function(t, e) {
            var n, r, i;
            return "string" == typeof e && (i = t[e], e = t, t = i), oe.isFunction(t) ? (n = Q.call(arguments, 2), r = function() {
                return t.apply(e || this, n.concat(Q.call(arguments)))
            }, r.guid = t.guid = t.guid || oe.guid++, r) : void 0
        },
        now: function() {
            return +new Date
        },
        support: re
    }), oe.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function(t, e) {
        J["[object " + e + "]"] = e.toLowerCase()
    });
    var ce =
        /*!
         * Sizzle CSS Selector Engine v1.10.16
         * http://sizzlejs.com/
         *
         * Copyright 2013 jQuery Foundation, Inc. and other contributors
         * Released under the MIT license
         * http://jquery.org/license
         *
         * Date: 2014-01-13
         */
        function(t) {
            function e(t, e, n, r) {
                var i, o, s, a, l, u, f, d, m, g;
                if ((e ? e.ownerDocument || e : I) !== j && O(e), e = e || j, n = n || [], !t || "string" != typeof t) return n;
                if (1 !== (a = e.nodeType) && 9 !== a) return [];
                if (M && !r) {
                    if (i = ye.exec(t))
                        if (s = i[1]) {
                            if (9 === a) {
                                if (o = e.getElementById(s), !o || !o.parentNode) return n;
                                if (o.id === s) return n.push(o), n
                            } else if (e.ownerDocument && (o = e.ownerDocument.getElementById(s)) && q(e, o) && o.id === s) return n.push(o), n
                        } else {
                            if (i[2]) return J.apply(n, e.getElementsByTagName(t)), n;
                            if ((s = i[3]) && T.getElementsByClassName && e.getElementsByClassName) return J.apply(n, e.getElementsByClassName(s)), n
                        }
                    if (T.qsa && (!L || !L.test(t))) {
                        if (d = f = H, m = e, g = 9 === a && t, 1 === a && "object" !== e.nodeName.toLowerCase()) {
                            for (u = p(t), (f = e.getAttribute("id")) ? d = f.replace(xe, "\\$&") : e.setAttribute("id", d), d = "[id='" + d + "'] ", l = u.length; l--;) u[l] = d + h(u[l]);
                            m = _e.test(t) && c(e.parentNode) || e, g = u.join(",")
                        }
                        if (g) try {
                            return J.apply(n, m.querySelectorAll(g)), n
                        } catch (v) {} finally {
                            f || e.removeAttribute("id")
                        }
                    }
                }
                return b(t.replace(le, "$1"), e, n, r)
            }

            function n() {
                function t(n, r) {
                    return e.push(n + " ") > k.cacheLength && delete t[e.shift()], t[n + " "] = r
                }
                var e = [];
                return t
            }

            function r(t) {
                return t[H] = !0, t
            }

            function i(t) {
                var e = j.createElement("div");
                try {
                    return !!t(e)
                } catch (n) {
                    return !1
                } finally {
                    e.parentNode && e.parentNode.removeChild(e), e = null
                }
            }

            function o(t, e) {
                for (var n = t.split("|"), r = t.length; r--;) k.attrHandle[n[r]] = e
            }

            function s(t, e) {
                var n = e && t,
                    r = n && 1 === t.nodeType && 1 === e.nodeType && (~e.sourceIndex || V) - (~t.sourceIndex || V);
                if (r) return r;
                if (n)
                    for (; n = n.nextSibling;)
                        if (n === e) return -1;
                return t ? 1 : -1
            }

            function a(t) {
                return function(e) {
                    var n = e.nodeName.toLowerCase();
                    return "input" === n && e.type === t
                }
            }

            function l(t) {
                return function(e) {
                    var n = e.nodeName.toLowerCase();
                    return ("input" === n || "button" === n) && e.type === t
                }
            }

            function u(t) {
                return r(function(e) {
                    return e = +e, r(function(n, r) {
                        for (var i, o = t([], n.length, e), s = o.length; s--;) n[i = o[s]] && (n[i] = !(r[i] = n[i]))
                    })
                })
            }

            function c(t) {
                return t && typeof t.getElementsByTagName !== U && t
            }

            function f() {}

            function p(t, n) {
                var r, i, o, s, a, l, u, c = $[t + " "];
                if (c) return n ? 0 : c.slice(0);
                for (a = t, l = [], u = k.preFilter; a;) {
                    (!r || (i = ue.exec(a))) && (i && (a = a.slice(i[0].length) || a), l.push(o = [])), r = !1, (i = ce.exec(a)) && (r = i.shift(), o.push({
                        value: r,
                        type: i[0].replace(le, " ")
                    }), a = a.slice(r.length));
                    for (s in k.filter) !(i = de[s].exec(a)) || u[s] && !(i = u[s](i)) || (r = i.shift(), o.push({
                        value: r,
                        type: s,
                        matches: i
                    }), a = a.slice(r.length));
                    if (!r) break
                }
                return n ? a.length : a ? e.error(t) : $(t, l).slice(0)
            }

            function h(t) {
                for (var e = 0, n = t.length, r = ""; n > e; e++) r += t[e].value;
                return r
            }

            function d(t, e, n) {
                var r = e.dir,
                    i = n && "parentNode" === r,
                    o = X++;
                return e.first ? function(e, n, o) {
                    for (; e = e[r];)
                        if (1 === e.nodeType || i) return t(e, n, o)
                } : function(e, n, s) {
                    var a, l, u = [z, o];
                    if (s) {
                        for (; e = e[r];)
                            if ((1 === e.nodeType || i) && t(e, n, s)) return !0
                    } else
                        for (; e = e[r];)
                            if (1 === e.nodeType || i) {
                                if (l = e[H] || (e[H] = {}), (a = l[r]) && a[0] === z && a[1] === o) return u[2] = a[2];
                                if (l[r] = u, u[2] = t(e, n, s)) return !0
                            }
                }
            }

            function m(t) {
                return t.length > 1 ? function(e, n, r) {
                    for (var i = t.length; i--;)
                        if (!t[i](e, n, r)) return !1;
                    return !0
                } : t[0]
            }

            function g(t, e, n, r, i) {
                for (var o, s = [], a = 0, l = t.length, u = null != e; l > a; a++)(o = t[a]) && (!n || n(o, r, i)) && (s.push(o), u && e.push(a));
                return s
            }

            function v(t, e, n, i, o, s) {
                return i && !i[H] && (i = v(i)), o && !o[H] && (o = v(o, s)), r(function(r, s, a, l) {
                    var u, c, f, p = [],
                        h = [],
                        d = s.length,
                        m = r || x(e || "*", a.nodeType ? [a] : a, []),
                        v = !t || !r && e ? m : g(m, p, t, a, l),
                        y = n ? o || (r ? t : d || i) ? [] : s : v;
                    if (n && n(v, y, a, l), i)
                        for (u = g(y, h), i(u, [], a, l), c = u.length; c--;)(f = u[c]) && (y[h[c]] = !(v[h[c]] = f));
                    if (r) {
                        if (o || t) {
                            if (o) {
                                for (u = [], c = y.length; c--;)(f = y[c]) && u.push(v[c] = f);
                                o(null, y = [], u, l)
                            }
                            for (c = y.length; c--;)(f = y[c]) && (u = o ? ee.call(r, f) : p[c]) > -1 && (r[u] = !(s[u] = f))
                        }
                    } else y = g(y === s ? y.splice(d, y.length) : y), o ? o(null, s, y, l) : J.apply(s, y)
                })
            }

            function y(t) {
                for (var e, n, r, i = t.length, o = k.relative[t[0].type], s = o || k.relative[" "], a = o ? 1 : 0, l = d(function(t) {
                        return t === e
                    }, s, !0), u = d(function(t) {
                        return ee.call(e, t) > -1
                    }, s, !0), c = [function(t, n, r) {
                        return !o && (r || n !== E) || ((e = n).nodeType ? l(t, n, r) : u(t, n, r))
                    }]; i > a; a++)
                    if (n = k.relative[t[a].type]) c = [d(m(c), n)];
                    else {
                        if (n = k.filter[t[a].type].apply(null, t[a].matches), n[H]) {
                            for (r = ++a; i > r && !k.relative[t[r].type]; r++);
                            return v(a > 1 && m(c), a > 1 && h(t.slice(0, a - 1).concat({
                                value: " " === t[a - 2].type ? "*" : ""
                            })).replace(le, "$1"), n, r > a && y(t.slice(a, r)), i > r && y(t = t.slice(r)), i > r && h(t))
                        }
                        c.push(n)
                    }
                return m(c)
            }

            function _(t, n) {
                var i = n.length > 0,
                    o = t.length > 0,
                    s = function(r, s, a, l, u) {
                        var c, f, p, h = 0,
                            d = "0",
                            m = r && [],
                            v = [],
                            y = E,
                            _ = r || o && k.find.TAG("*", u),
                            x = z += null == y ? 1 : Math.random() || .1,
                            b = _.length;
                        for (u && (E = s !== j && s); d !== b && null != (c = _[d]); d++) {
                            if (o && c) {
                                for (f = 0; p = t[f++];)
                                    if (p(c, s, a)) {
                                        l.push(c);
                                        break
                                    }
                                u && (z = x)
                            }
                            i && ((c = !p && c) && h--, r && m.push(c))
                        }
                        if (h += d, i && d !== h) {
                            for (f = 0; p = n[f++];) p(m, v, s, a);
                            if (r) {
                                if (h > 0)
                                    for (; d--;) m[d] || v[d] || (v[d] = Z.call(l));
                                v = g(v)
                            }
                            J.apply(l, v), u && !r && v.length > 0 && h + n.length > 1 && e.uniqueSort(l)
                        }
                        return u && (z = x, E = y), m
                    };
                return i ? r(s) : s
            }

            function x(t, n, r) {
                for (var i = 0, o = n.length; o > i; i++) e(t, n[i], r);
                return r
            }

            function b(t, e, n, r) {
                var i, o, s, a, l, u = p(t);
                if (!r && 1 === u.length) {
                    if (o = u[0] = u[0].slice(0), o.length > 2 && "ID" === (s = o[0]).type && T.getById && 9 === e.nodeType && M && k.relative[o[1].type]) {
                        if (e = (k.find.ID(s.matches[0].replace(be, we), e) || [])[0], !e) return n;
                        t = t.slice(o.shift().value.length)
                    }
                    for (i = de.needsContext.test(t) ? 0 : o.length; i-- && (s = o[i], !k.relative[a = s.type]);)
                        if ((l = k.find[a]) && (r = l(s.matches[0].replace(be, we), _e.test(o[0].type) && c(e.parentNode) || e))) {
                            if (o.splice(i, 1), t = r.length && h(o), !t) return J.apply(n, r), n;
                            break
                        }
                }
                return P(t, u)(r, e, !M, n, _e.test(t) && c(e.parentNode) || e), n
            }
            var w, T, k, S, C, P, E, A, N, O, j, D, M, L, R, F, q, H = "sizzle" + -new Date,
                I = t.document,
                z = 0,
                X = 0,
                B = n(),
                $ = n(),
                W = n(),
                Y = function(t, e) {
                    return t === e && (N = !0), 0
                },
                U = "undefined",
                V = 1 << 31,
                Q = {}.hasOwnProperty,
                G = [],
                Z = G.pop,
                K = G.push,
                J = G.push,
                te = G.slice,
                ee = G.indexOf || function(t) {
                    for (var e = 0, n = this.length; n > e; e++)
                        if (this[e] === t) return e;
                    return -1
                },
                ne = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
                re = "[\\x20\\t\\r\\n\\f]",
                ie = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",
                oe = ie.replace("w", "w#"),
                se = "\\[" + re + "*(" + ie + ")" + re + "*(?:([*^$|!~]?=)" + re + "*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|(" + oe + ")|)|)" + re + "*\\]",
                ae = ":(" + ie + ")(?:\\(((['\"])((?:\\\\.|[^\\\\])*?)\\3|((?:\\\\.|[^\\\\()[\\]]|" + se.replace(3, 8) + ")*)|.*)\\)|)",
                le = new RegExp("^" + re + "+|((?:^|[^\\\\])(?:\\\\.)*)" + re + "+$", "g"),
                ue = new RegExp("^" + re + "*," + re + "*"),
                ce = new RegExp("^" + re + "*([>+~]|" + re + ")" + re + "*"),
                fe = new RegExp("=" + re + "*([^\\]'\"]*?)" + re + "*\\]", "g"),
                pe = new RegExp(ae),
                he = new RegExp("^" + oe + "$"),
                de = {
                    ID: new RegExp("^#(" + ie + ")"),
                    CLASS: new RegExp("^\\.(" + ie + ")"),
                    TAG: new RegExp("^(" + ie.replace("w", "w*") + ")"),
                    ATTR: new RegExp("^" + se),
                    PSEUDO: new RegExp("^" + ae),
                    CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + re + "*(even|odd|(([+-]|)(\\d*)n|)" + re + "*(?:([+-]|)" + re + "*(\\d+)|))" + re + "*\\)|)", "i"),
                    bool: new RegExp("^(?:" + ne + ")$", "i"),
                    needsContext: new RegExp("^" + re + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + re + "*((?:-\\d)?\\d*)" + re + "*\\)|)(?=[^-]|$)", "i")
                },
                me = /^(?:input|select|textarea|button)$/i,
                ge = /^h\d$/i,
                ve = /^[^{]+\{\s*\[native \w/,
                ye = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
                _e = /[+~]/,
                xe = /'|\\/g,
                be = new RegExp("\\\\([\\da-f]{1,6}" + re + "?|(" + re + ")|.)", "ig"),
                we = function(t, e, n) {
                    var r = "0x" + e - 65536;
                    return r !== r || n ? e : 0 > r ? String.fromCharCode(r + 65536) : String.fromCharCode(r >> 10 | 55296, 1023 & r | 56320)
                };
            try {
                J.apply(G = te.call(I.childNodes), I.childNodes), G[I.childNodes.length].nodeType
            } catch (Te) {
                J = {
                    apply: G.length ? function(t, e) {
                        K.apply(t, te.call(e))
                    } : function(t, e) {
                        for (var n = t.length, r = 0; t[n++] = e[r++];);
                        t.length = n - 1
                    }
                }
            }
            T = e.support = {}, C = e.isXML = function(t) {
                var e = t && (t.ownerDocument || t).documentElement;
                return e ? "HTML" !== e.nodeName : !1
            }, O = e.setDocument = function(t) {
                var e, n = t ? t.ownerDocument || t : I,
                    r = n.defaultView;
                return n !== j && 9 === n.nodeType && n.documentElement ? (j = n, D = n.documentElement, M = !C(n), r && r !== r.top && (r.addEventListener ? r.addEventListener("unload", function() {
                    O()
                }, !1) : r.attachEvent && r.attachEvent("onunload", function() {
                    O()
                })), T.attributes = i(function(t) {
                    return t.className = "i", !t.getAttribute("className")
                }), T.getElementsByTagName = i(function(t) {
                    return t.appendChild(n.createComment("")), !t.getElementsByTagName("*").length
                }), T.getElementsByClassName = ve.test(n.getElementsByClassName) && i(function(t) {
                    return t.innerHTML = "<div class='a'></div><div class='a i'></div>", t.firstChild.className = "i", 2 === t.getElementsByClassName("i").length
                }), T.getById = i(function(t) {
                    return D.appendChild(t).id = H, !n.getElementsByName || !n.getElementsByName(H).length
                }), T.getById ? (k.find.ID = function(t, e) {
                    if (typeof e.getElementById !== U && M) {
                        var n = e.getElementById(t);
                        return n && n.parentNode ? [n] : []
                    }
                }, k.filter.ID = function(t) {
                    var e = t.replace(be, we);
                    return function(t) {
                        return t.getAttribute("id") === e
                    }
                }) : (delete k.find.ID, k.filter.ID = function(t) {
                    var e = t.replace(be, we);
                    return function(t) {
                        var n = typeof t.getAttributeNode !== U && t.getAttributeNode("id");
                        return n && n.value === e
                    }
                }), k.find.TAG = T.getElementsByTagName ? function(t, e) {
                    return typeof e.getElementsByTagName !== U ? e.getElementsByTagName(t) : void 0
                } : function(t, e) {
                    var n, r = [],
                        i = 0,
                        o = e.getElementsByTagName(t);
                    if ("*" === t) {
                        for (; n = o[i++];) 1 === n.nodeType && r.push(n);
                        return r
                    }
                    return o
                }, k.find.CLASS = T.getElementsByClassName && function(t, e) {
                    return typeof e.getElementsByClassName !== U && M ? e.getElementsByClassName(t) : void 0
                }, R = [], L = [], (T.qsa = ve.test(n.querySelectorAll)) && (i(function(t) {
                    t.innerHTML = "<select t=''><option selected=''></option></select>", t.querySelectorAll("[t^='']").length && L.push("[*^$]=" + re + "*(?:''|\"\")"), t.querySelectorAll("[selected]").length || L.push("\\[" + re + "*(?:value|" + ne + ")"), t.querySelectorAll(":checked").length || L.push(":checked")
                }), i(function(t) {
                    var e = n.createElement("input");
                    e.setAttribute("type", "hidden"), t.appendChild(e).setAttribute("name", "D"), t.querySelectorAll("[name=d]").length && L.push("name" + re + "*[*^$|!~]?="), t.querySelectorAll(":enabled").length || L.push(":enabled", ":disabled"), t.querySelectorAll("*,:x"), L.push(",.*:")
                })), (T.matchesSelector = ve.test(F = D.webkitMatchesSelector || D.mozMatchesSelector || D.oMatchesSelector || D.msMatchesSelector)) && i(function(t) {
                    T.disconnectedMatch = F.call(t, "div"), F.call(t, "[s!='']:x"), R.push("!=", ae)
                }), L = L.length && new RegExp(L.join("|")), R = R.length && new RegExp(R.join("|")), e = ve.test(D.compareDocumentPosition), q = e || ve.test(D.contains) ? function(t, e) {
                    var n = 9 === t.nodeType ? t.documentElement : t,
                        r = e && e.parentNode;
                    return t === r || !(!r || 1 !== r.nodeType || !(n.contains ? n.contains(r) : t.compareDocumentPosition && 16 & t.compareDocumentPosition(r)))
                } : function(t, e) {
                    if (e)
                        for (; e = e.parentNode;)
                            if (e === t) return !0;
                    return !1
                }, Y = e ? function(t, e) {
                    if (t === e) return N = !0, 0;
                    var r = !t.compareDocumentPosition - !e.compareDocumentPosition;
                    return r ? r : (r = (t.ownerDocument || t) === (e.ownerDocument || e) ? t.compareDocumentPosition(e) : 1, 1 & r || !T.sortDetached && e.compareDocumentPosition(t) === r ? t === n || t.ownerDocument === I && q(I, t) ? -1 : e === n || e.ownerDocument === I && q(I, e) ? 1 : A ? ee.call(A, t) - ee.call(A, e) : 0 : 4 & r ? -1 : 1)
                } : function(t, e) {
                    if (t === e) return N = !0, 0;
                    var r, i = 0,
                        o = t.parentNode,
                        a = e.parentNode,
                        l = [t],
                        u = [e];
                    if (!o || !a) return t === n ? -1 : e === n ? 1 : o ? -1 : a ? 1 : A ? ee.call(A, t) - ee.call(A, e) : 0;
                    if (o === a) return s(t, e);
                    for (r = t; r = r.parentNode;) l.unshift(r);
                    for (r = e; r = r.parentNode;) u.unshift(r);
                    for (; l[i] === u[i];) i++;
                    return i ? s(l[i], u[i]) : l[i] === I ? -1 : u[i] === I ? 1 : 0
                }, n) : j
            }, e.matches = function(t, n) {
                return e(t, null, null, n)
            }, e.matchesSelector = function(t, n) {
                if ((t.ownerDocument || t) !== j && O(t), n = n.replace(fe, "='$1']"), !(!T.matchesSelector || !M || R && R.test(n) || L && L.test(n))) try {
                    var r = F.call(t, n);
                    if (r || T.disconnectedMatch || t.document && 11 !== t.document.nodeType) return r
                } catch (i) {}
                return e(n, j, null, [t]).length > 0
            }, e.contains = function(t, e) {
                return (t.ownerDocument || t) !== j && O(t), q(t, e)
            }, e.attr = function(t, e) {
                (t.ownerDocument || t) !== j && O(t);
                var n = k.attrHandle[e.toLowerCase()],
                    r = n && Q.call(k.attrHandle, e.toLowerCase()) ? n(t, e, !M) : void 0;
                return void 0 !== r ? r : T.attributes || !M ? t.getAttribute(e) : (r = t.getAttributeNode(e)) && r.specified ? r.value : null
            }, e.error = function(t) {
                throw new Error("Syntax error, unrecognized expression: " + t)
            }, e.uniqueSort = function(t) {
                var e, n = [],
                    r = 0,
                    i = 0;
                if (N = !T.detectDuplicates, A = !T.sortStable && t.slice(0), t.sort(Y), N) {
                    for (; e = t[i++];) e === t[i] && (r = n.push(i));
                    for (; r--;) t.splice(n[r], 1)
                }
                return A = null, t
            }, S = e.getText = function(t) {
                var e, n = "",
                    r = 0,
                    i = t.nodeType;
                if (i) {
                    if (1 === i || 9 === i || 11 === i) {
                        if ("string" == typeof t.textContent) return t.textContent;
                        for (t = t.firstChild; t; t = t.nextSibling) n += S(t)
                    } else if (3 === i || 4 === i) return t.nodeValue
                } else
                    for (; e = t[r++];) n += S(e);
                return n
            }, k = e.selectors = {
                cacheLength: 50,
                createPseudo: r,
                match: de,
                attrHandle: {},
                find: {},
                relative: {
                    ">": {
                        dir: "parentNode",
                        first: !0
                    },
                    " ": {
                        dir: "parentNode"
                    },
                    "+": {
                        dir: "previousSibling",
                        first: !0
                    },
                    "~": {
                        dir: "previousSibling"
                    }
                },
                preFilter: {
                    ATTR: function(t) {
                        return t[1] = t[1].replace(be, we), t[3] = (t[4] || t[5] || "").replace(be, we), "~=" === t[2] && (t[3] = " " + t[3] + " "), t.slice(0, 4)
                    },
                    CHILD: function(t) {
                        return t[1] = t[1].toLowerCase(), "nth" === t[1].slice(0, 3) ? (t[3] || e.error(t[0]), t[4] = +(t[4] ? t[5] + (t[6] || 1) : 2 * ("even" === t[3] || "odd" === t[3])), t[5] = +(t[7] + t[8] || "odd" === t[3])) : t[3] && e.error(t[0]), t
                    },
                    PSEUDO: function(t) {
                        var e, n = !t[5] && t[2];
                        return de.CHILD.test(t[0]) ? null : (t[3] && void 0 !== t[4] ? t[2] = t[4] : n && pe.test(n) && (e = p(n, !0)) && (e = n.indexOf(")", n.length - e) - n.length) && (t[0] = t[0].slice(0, e), t[2] = n.slice(0, e)), t.slice(0, 3))
                    }
                },
                filter: {
                    TAG: function(t) {
                        var e = t.replace(be, we).toLowerCase();
                        return "*" === t ? function() {
                            return !0
                        } : function(t) {
                            return t.nodeName && t.nodeName.toLowerCase() === e
                        }
                    },
                    CLASS: function(t) {
                        var e = B[t + " "];
                        return e || (e = new RegExp("(^|" + re + ")" + t + "(" + re + "|$)")) && B(t, function(t) {
                            return e.test("string" == typeof t.className && t.className || typeof t.getAttribute !== U && t.getAttribute("class") || "")
                        })
                    },
                    ATTR: function(t, n, r) {
                        return function(i) {
                            var o = e.attr(i, t);
                            return null == o ? "!=" === n : n ? (o += "", "=" === n ? o === r : "!=" === n ? o !== r : "^=" === n ? r && 0 === o.indexOf(r) : "*=" === n ? r && o.indexOf(r) > -1 : "$=" === n ? r && o.slice(-r.length) === r : "~=" === n ? (" " + o + " ").indexOf(r) > -1 : "|=" === n ? o === r || o.slice(0, r.length + 1) === r + "-" : !1) : !0
                        }
                    },
                    CHILD: function(t, e, n, r, i) {
                        var o = "nth" !== t.slice(0, 3),
                            s = "last" !== t.slice(-4),
                            a = "of-type" === e;
                        return 1 === r && 0 === i ? function(t) {
                            return !!t.parentNode
                        } : function(e, n, l) {
                            var u, c, f, p, h, d, m = o !== s ? "nextSibling" : "previousSibling",
                                g = e.parentNode,
                                v = a && e.nodeName.toLowerCase(),
                                y = !l && !a;
                            if (g) {
                                if (o) {
                                    for (; m;) {
                                        for (f = e; f = f[m];)
                                            if (a ? f.nodeName.toLowerCase() === v : 1 === f.nodeType) return !1;
                                        d = m = "only" === t && !d && "nextSibling"
                                    }
                                    return !0
                                }
                                if (d = [s ? g.firstChild : g.lastChild], s && y) {
                                    for (c = g[H] || (g[H] = {}), u = c[t] || [], h = u[0] === z && u[1], p = u[0] === z && u[2], f = h && g.childNodes[h]; f = ++h && f && f[m] || (p = h = 0) || d.pop();)
                                        if (1 === f.nodeType && ++p && f === e) {
                                            c[t] = [z, h, p];
                                            break
                                        }
                                } else if (y && (u = (e[H] || (e[H] = {}))[t]) && u[0] === z) p = u[1];
                                else
                                    for (;
                                        (f = ++h && f && f[m] || (p = h = 0) || d.pop()) && ((a ? f.nodeName.toLowerCase() !== v : 1 !== f.nodeType) || !++p || (y && ((f[H] || (f[H] = {}))[t] = [z, p]), f !== e)););
                                return p -= i, p === r || p % r === 0 && p / r >= 0
                            }
                        }
                    },
                    PSEUDO: function(t, n) {
                        var i, o = k.pseudos[t] || k.setFilters[t.toLowerCase()] || e.error("unsupported pseudo: " + t);
                        return o[H] ? o(n) : o.length > 1 ? (i = [t, t, "", n], k.setFilters.hasOwnProperty(t.toLowerCase()) ? r(function(t, e) {
                            for (var r, i = o(t, n), s = i.length; s--;) r = ee.call(t, i[s]), t[r] = !(e[r] = i[s])
                        }) : function(t) {
                            return o(t, 0, i)
                        }) : o
                    }
                },
                pseudos: {
                    not: r(function(t) {
                        var e = [],
                            n = [],
                            i = P(t.replace(le, "$1"));
                        return i[H] ? r(function(t, e, n, r) {
                            for (var o, s = i(t, null, r, []), a = t.length; a--;)(o = s[a]) && (t[a] = !(e[a] = o))
                        }) : function(t, r, o) {
                            return e[0] = t, i(e, null, o, n), !n.pop()
                        }
                    }),
                    has: r(function(t) {
                        return function(n) {
                            return e(t, n).length > 0
                        }
                    }),
                    contains: r(function(t) {
                        return function(e) {
                            return (e.textContent || e.innerText || S(e)).indexOf(t) > -1
                        }
                    }),
                    lang: r(function(t) {
                        return he.test(t || "") || e.error("unsupported lang: " + t), t = t.replace(be, we).toLowerCase(),
                            function(e) {
                                var n;
                                do
                                    if (n = M ? e.lang : e.getAttribute("xml:lang") || e.getAttribute("lang")) return n = n.toLowerCase(), n === t || 0 === n.indexOf(t + "-");
                                while ((e = e.parentNode) && 1 === e.nodeType);
                                return !1
                            }
                    }),
                    target: function(e) {
                        var n = t.location && t.location.hash;
                        return n && n.slice(1) === e.id
                    },
                    root: function(t) {
                        return t === D
                    },
                    focus: function(t) {
                        return t === j.activeElement && (!j.hasFocus || j.hasFocus()) && !!(t.type || t.href || ~t.tabIndex)
                    },
                    enabled: function(t) {
                        return t.disabled === !1
                    },
                    disabled: function(t) {
                        return t.disabled === !0
                    },
                    checked: function(t) {
                        var e = t.nodeName.toLowerCase();
                        return "input" === e && !!t.checked || "option" === e && !!t.selected
                    },
                    selected: function(t) {
                        return t.parentNode && t.parentNode.selectedIndex, t.selected === !0
                    },
                    empty: function(t) {
                        for (t = t.firstChild; t; t = t.nextSibling)
                            if (t.nodeType < 6) return !1;
                        return !0
                    },
                    parent: function(t) {
                        return !k.pseudos.empty(t)
                    },
                    header: function(t) {
                        return ge.test(t.nodeName)
                    },
                    input: function(t) {
                        return me.test(t.nodeName)
                    },
                    button: function(t) {
                        var e = t.nodeName.toLowerCase();
                        return "input" === e && "button" === t.type || "button" === e
                    },
                    text: function(t) {
                        var e;
                        return "input" === t.nodeName.toLowerCase() && "text" === t.type && (null == (e = t.getAttribute("type")) || "text" === e.toLowerCase())
                    },
                    first: u(function() {
                        return [0]
                    }),
                    last: u(function(t, e) {
                        return [e - 1]
                    }),
                    eq: u(function(t, e, n) {
                        return [0 > n ? n + e : n]
                    }),
                    even: u(function(t, e) {
                        for (var n = 0; e > n; n += 2) t.push(n);
                        return t
                    }),
                    odd: u(function(t, e) {
                        for (var n = 1; e > n; n += 2) t.push(n);
                        return t
                    }),
                    lt: u(function(t, e, n) {
                        for (var r = 0 > n ? n + e : n; --r >= 0;) t.push(r);
                        return t
                    }),
                    gt: u(function(t, e, n) {
                        for (var r = 0 > n ? n + e : n; ++r < e;) t.push(r);
                        return t
                    })
                }
            }, k.pseudos.nth = k.pseudos.eq;
            for (w in {
                    radio: !0,
                    checkbox: !0,
                    file: !0,
                    password: !0,
                    image: !0
                }) k.pseudos[w] = a(w);
            for (w in {
                    submit: !0,
                    reset: !0
                }) k.pseudos[w] = l(w);
            return f.prototype = k.filters = k.pseudos, k.setFilters = new f, P = e.compile = function(t, e) {
                var n, r = [],
                    i = [],
                    o = W[t + " "];
                if (!o) {
                    for (e || (e = p(t)), n = e.length; n--;) o = y(e[n]), o[H] ? r.push(o) : i.push(o);
                    o = W(t, _(i, r))
                }
                return o
            }, T.sortStable = H.split("").sort(Y).join("") === H, T.detectDuplicates = !!N, O(), T.sortDetached = i(function(t) {
                return 1 & t.compareDocumentPosition(j.createElement("div"))
            }), i(function(t) {
                return t.innerHTML = "<a href='#'></a>", "#" === t.firstChild.getAttribute("href")
            }) || o("type|href|height|width", function(t, e, n) {
                return n ? void 0 : t.getAttribute(e, "type" === e.toLowerCase() ? 1 : 2)
            }), T.attributes && i(function(t) {
                return t.innerHTML = "<input/>", t.firstChild.setAttribute("value", ""), "" === t.firstChild.getAttribute("value")
            }) || o("value", function(t, e, n) {
                return n || "input" !== t.nodeName.toLowerCase() ? void 0 : t.defaultValue
            }), i(function(t) {
                return null == t.getAttribute("disabled")
            }) || o(ne, function(t, e, n) {
                var r;
                return n ? void 0 : t[e] === !0 ? e.toLowerCase() : (r = t.getAttributeNode(e)) && r.specified ? r.value : null
            }), e
        }(t);
    oe.find = ce, oe.expr = ce.selectors, oe.expr[":"] = oe.expr.pseudos, oe.unique = ce.uniqueSort, oe.text = ce.getText, oe.isXMLDoc = ce.isXML, oe.contains = ce.contains;
    var fe = oe.expr.match.needsContext,
        pe = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,
        he = /^.[^:#\[\.,]*$/;
    oe.filter = function(t, e, n) {
        var r = e[0];
        return n && (t = ":not(" + t + ")"), 1 === e.length && 1 === r.nodeType ? oe.find.matchesSelector(r, t) ? [r] : [] : oe.find.matches(t, oe.grep(e, function(t) {
            return 1 === t.nodeType
        }))
    }, oe.fn.extend({
        find: function(t) {
            var e, n = [],
                r = this,
                i = r.length;
            if ("string" != typeof t) return this.pushStack(oe(t).filter(function() {
                for (e = 0; i > e; e++)
                    if (oe.contains(r[e], this)) return !0
            }));
            for (e = 0; i > e; e++) oe.find(t, r[e], n);
            return n = this.pushStack(i > 1 ? oe.unique(n) : n), n.selector = this.selector ? this.selector + " " + t : t, n
        },
        filter: function(t) {
            return this.pushStack(r(this, t || [], !1))
        },
        not: function(t) {
            return this.pushStack(r(this, t || [], !0))
        },
        is: function(t) {
            return !!r(this, "string" == typeof t && fe.test(t) ? oe(t) : t || [], !1).length
        }
    });
    var de, me = t.document,
        ge = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,
        ve = oe.fn.init = function(t, e) {
            var n, r;
            if (!t) return this;
            if ("string" == typeof t) {
                if (n = "<" === t.charAt(0) && ">" === t.charAt(t.length - 1) && t.length >= 3 ? [null, t, null] : ge.exec(t), !n || !n[1] && e) return !e || e.jquery ? (e || de).find(t) : this.constructor(e).find(t);
                if (n[1]) {
                    if (e = e instanceof oe ? e[0] : e, oe.merge(this, oe.parseHTML(n[1], e && e.nodeType ? e.ownerDocument || e : me, !0)), pe.test(n[1]) && oe.isPlainObject(e))
                        for (n in e) oe.isFunction(this[n]) ? this[n](e[n]) : this.attr(n, e[n]);
                    return this
                }
                if (r = me.getElementById(n[2]), r && r.parentNode) {
                    if (r.id !== n[2]) return de.find(t);
                    this.length = 1, this[0] = r
                }
                return this.context = me, this.selector = t, this
            }
            return t.nodeType ? (this.context = this[0] = t, this.length = 1, this) : oe.isFunction(t) ? "undefined" != typeof de.ready ? de.ready(t) : t(oe) : (void 0 !== t.selector && (this.selector = t.selector, this.context = t.context), oe.makeArray(t, this))
        };
    ve.prototype = oe.fn, de = oe(me);
    var ye = /^(?:parents|prev(?:Until|All))/,
        _e = {
            children: !0,
            contents: !0,
            next: !0,
            prev: !0
        };
    oe.extend({
        dir: function(t, e, n) {
            for (var r = [], i = t[e]; i && 9 !== i.nodeType && (void 0 === n || 1 !== i.nodeType || !oe(i).is(n));) 1 === i.nodeType && r.push(i), i = i[e];
            return r
        },
        sibling: function(t, e) {
            for (var n = []; t; t = t.nextSibling) 1 === t.nodeType && t !== e && n.push(t);
            return n
        }
    }), oe.fn.extend({
        has: function(t) {
            var e, n = oe(t, this),
                r = n.length;
            return this.filter(function() {
                for (e = 0; r > e; e++)
                    if (oe.contains(this, n[e])) return !0
            })
        },
        closest: function(t, e) {
            for (var n, r = 0, i = this.length, o = [], s = fe.test(t) || "string" != typeof t ? oe(t, e || this.context) : 0; i > r; r++)
                for (n = this[r]; n && n !== e; n = n.parentNode)
                    if (n.nodeType < 11 && (s ? s.index(n) > -1 : 1 === n.nodeType && oe.find.matchesSelector(n, t))) {
                        o.push(n);
                        break
                    }
            return this.pushStack(o.length > 1 ? oe.unique(o) : o)
        },
        index: function(t) {
            return t ? "string" == typeof t ? oe.inArray(this[0], oe(t)) : oe.inArray(t.jquery ? t[0] : t, this) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
        },
        add: function(t, e) {
            return this.pushStack(oe.unique(oe.merge(this.get(), oe(t, e))))
        },
        addBack: function(t) {
            return this.add(null == t ? this.prevObject : this.prevObject.filter(t))
        }
    }), oe.each({
        parent: function(t) {
            var e = t.parentNode;
            return e && 11 !== e.nodeType ? e : null
        },
        parents: function(t) {
            return oe.dir(t, "parentNode")
        },
        parentsUntil: function(t, e, n) {
            return oe.dir(t, "parentNode", n)
        },
        next: function(t) {
            return i(t, "nextSibling")
        },
        prev: function(t) {
            return i(t, "previousSibling")
        },
        nextAll: function(t) {
            return oe.dir(t, "nextSibling")
        },
        prevAll: function(t) {
            return oe.dir(t, "previousSibling")
        },
        nextUntil: function(t, e, n) {
            return oe.dir(t, "nextSibling", n)
        },
        prevUntil: function(t, e, n) {
            return oe.dir(t, "previousSibling", n)
        },
        siblings: function(t) {
            return oe.sibling((t.parentNode || {}).firstChild, t)
        },
        children: function(t) {
            return oe.sibling(t.firstChild)
        },
        contents: function(t) {
            return oe.nodeName(t, "iframe") ? t.contentDocument || t.contentWindow.document : oe.merge([], t.childNodes)
        }
    }, function(t, e) {
        oe.fn[t] = function(n, r) {
            var i = oe.map(this, e, n);
            return "Until" !== t.slice(-5) && (r = n), r && "string" == typeof r && (i = oe.filter(r, i)), this.length > 1 && (_e[t] || (i = oe.unique(i)), ye.test(t) && (i = i.reverse())), this.pushStack(i)
        }
    });
    var xe = /\S+/g,
        be = {};
    oe.Callbacks = function(t) {
        t = "string" == typeof t ? be[t] || o(t) : oe.extend({}, t);
        var e, n, r, i, s, a, l = [],
            u = !t.once && [],
            c = function(o) {
                for (n = t.memory && o, r = !0, s = a || 0, a = 0, i = l.length, e = !0; l && i > s; s++)
                    if (l[s].apply(o[0], o[1]) === !1 && t.stopOnFalse) {
                        n = !1;
                        break
                    }
                e = !1, l && (u ? u.length && c(u.shift()) : n ? l = [] : f.disable())
            },
            f = {
                add: function() {
                    if (l) {
                        var r = l.length;
                        ! function o(e) {
                            oe.each(e, function(e, n) {
                                var r = oe.type(n);
                                "function" === r ? t.unique && f.has(n) || l.push(n) : n && n.length && "string" !== r && o(n)
                            })
                        }(arguments), e ? i = l.length : n && (a = r, c(n))
                    }
                    return this
                },
                remove: function() {
                    return l && oe.each(arguments, function(t, n) {
                        for (var r;
                            (r = oe.inArray(n, l, r)) > -1;) l.splice(r, 1), e && (i >= r && i--, s >= r && s--)
                    }), this
                },
                has: function(t) {
                    return t ? oe.inArray(t, l) > -1 : !(!l || !l.length)
                },
                empty: function() {
                    return l = [], i = 0, this
                },
                disable: function() {
                    return l = u = n = void 0, this
                },
                disabled: function() {
                    return !l
                },
                lock: function() {
                    return u = void 0, n || f.disable(), this
                },
                locked: function() {
                    return !u
                },
                fireWith: function(t, n) {
                    return !l || r && !u || (n = n || [], n = [t, n.slice ? n.slice() : n], e ? u.push(n) : c(n)), this
                },
                fire: function() {
                    return f.fireWith(this, arguments), this
                },
                fired: function() {
                    return !!r
                }
            };
        return f
    }, oe.extend({
        Deferred: function(t) {
            var e = [
                    ["resolve", "done", oe.Callbacks("once memory"), "resolved"],
                    ["reject", "fail", oe.Callbacks("once memory"), "rejected"],
                    ["notify", "progress", oe.Callbacks("memory")]
                ],
                n = "pending",
                r = {
                    state: function() {
                        return n
                    },
                    always: function() {
                        return i.done(arguments).fail(arguments), this
                    },
                    then: function() {
                        var t = arguments;
                        return oe.Deferred(function(n) {
                            oe.each(e, function(e, o) {
                                var s = oe.isFunction(t[e]) && t[e];
                                i[o[1]](function() {
                                    var t = s && s.apply(this, arguments);
                                    t && oe.isFunction(t.promise) ? t.promise().done(n.resolve).fail(n.reject).progress(n.notify) : n[o[0] + "With"](this === r ? n.promise() : this, s ? [t] : arguments)
                                })
                            }), t = null
                        }).promise()
                    },
                    promise: function(t) {
                        return null != t ? oe.extend(t, r) : r
                    }
                },
                i = {};
            return r.pipe = r.then, oe.each(e, function(t, o) {
                var s = o[2],
                    a = o[3];
                r[o[1]] = s.add, a && s.add(function() {
                    n = a
                }, e[1 ^ t][2].disable, e[2][2].lock), i[o[0]] = function() {
                    return i[o[0] + "With"](this === i ? r : this, arguments), this
                }, i[o[0] + "With"] = s.fireWith
            }), r.promise(i), t && t.call(i, i), i
        },
        when: function(t) {
            var e, n, r, i = 0,
                o = Q.call(arguments),
                s = o.length,
                a = 1 !== s || t && oe.isFunction(t.promise) ? s : 0,
                l = 1 === a ? t : oe.Deferred(),
                u = function(t, n, r) {
                    return function(i) {
                        n[t] = this, r[t] = arguments.length > 1 ? Q.call(arguments) : i, r === e ? l.notifyWith(n, r) : --a || l.resolveWith(n, r)
                    }
                };
            if (s > 1)
                for (e = new Array(s), n = new Array(s), r = new Array(s); s > i; i++) o[i] && oe.isFunction(o[i].promise) ? o[i].promise().done(u(i, r, o)).fail(l.reject).progress(u(i, n, e)) : --a;
            return a || l.resolveWith(r, o), l.promise()
        }
    });
    var we;
    oe.fn.ready = function(t) {
        return oe.ready.promise().done(t), this
    }, oe.extend({
        isReady: !1,
        readyWait: 1,
        holdReady: function(t) {
            t ? oe.readyWait++ : oe.ready(!0)
        },
        ready: function(t) {
            if (t === !0 ? !--oe.readyWait : !oe.isReady) {
                if (!me.body) return setTimeout(oe.ready);
                oe.isReady = !0, t !== !0 && --oe.readyWait > 0 || (we.resolveWith(me, [oe]), oe.fn.trigger && oe(me).trigger("ready").off("ready"))
            }
        }
    }), oe.ready.promise = function(e) {
        if (!we)
            if (we = oe.Deferred(), "complete" === me.readyState) setTimeout(oe.ready);
            else if (me.addEventListener) me.addEventListener("DOMContentLoaded", a, !1), t.addEventListener("load", a, !1);
        else {
            me.attachEvent("onreadystatechange", a), t.attachEvent("onload", a);
            var n = !1;
            try {
                n = null == t.frameElement && me.documentElement
            } catch (r) {}
            n && n.doScroll && ! function i() {
                if (!oe.isReady) {
                    try {
                        n.doScroll("left")
                    } catch (t) {
                        return setTimeout(i, 50)
                    }
                    s(), oe.ready()
                }
            }()
        }
        return we.promise(e)
    };
    var Te, ke = "undefined";
    for (Te in oe(re)) break;
    re.ownLast = "0" !== Te, re.inlineBlockNeedsLayout = !1, oe(function() {
            var t, e, n = me.getElementsByTagName("body")[0];
            n && (t = me.createElement("div"), t.style.cssText = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px", e = me.createElement("div"), n.appendChild(t).appendChild(e), typeof e.style.zoom !== ke && (e.style.cssText = "border:0;margin:0;width:1px;padding:1px;display:inline;zoom:1", (re.inlineBlockNeedsLayout = 3 === e.offsetWidth) && (n.style.zoom = 1)), n.removeChild(t), t = e = null)
        }),
        function() {
            var t = me.createElement("div");
            if (null == re.deleteExpando) {
                re.deleteExpando = !0;
                try {
                    delete t.test
                } catch (e) {
                    re.deleteExpando = !1
                }
            }
            t = null
        }(), oe.acceptData = function(t) {
            var e = oe.noData[(t.nodeName + " ").toLowerCase()],
                n = +t.nodeType || 1;
            return 1 !== n && 9 !== n ? !1 : !e || e !== !0 && t.getAttribute("classid") === e
        };
    var Se = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
        Ce = /([A-Z])/g;
    oe.extend({
        cache: {},
        noData: {
            "applet ": !0,
            "embed ": !0,
            "object ": "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
        },
        hasData: function(t) {
            return t = t.nodeType ? oe.cache[t[oe.expando]] : t[oe.expando], !!t && !u(t)
        },
        data: function(t, e, n) {
            return c(t, e, n)
        },
        removeData: function(t, e) {
            return f(t, e)
        },
        _data: function(t, e, n) {
            return c(t, e, n, !0)
        },
        _removeData: function(t, e) {
            return f(t, e, !0)
        }
    }), oe.fn.extend({
        data: function(t, e) {
            var n, r, i, o = this[0],
                s = o && o.attributes;
            if (void 0 === t) {
                if (this.length && (i = oe.data(o), 1 === o.nodeType && !oe._data(o, "parsedAttrs"))) {
                    for (n = s.length; n--;) r = s[n].name, 0 === r.indexOf("data-") && (r = oe.camelCase(r.slice(5)), l(o, r, i[r]));
                    oe._data(o, "parsedAttrs", !0)
                }
                return i
            }
            return "object" == typeof t ? this.each(function() {
                oe.data(this, t)
            }) : arguments.length > 1 ? this.each(function() {
                oe.data(this, t, e)
            }) : o ? l(o, t, oe.data(o, t)) : void 0
        },
        removeData: function(t) {
            return this.each(function() {
                oe.removeData(this, t)
            })
        }
    }), oe.extend({
        queue: function(t, e, n) {
            var r;
            return t ? (e = (e || "fx") + "queue", r = oe._data(t, e), n && (!r || oe.isArray(n) ? r = oe._data(t, e, oe.makeArray(n)) : r.push(n)), r || []) : void 0
        },
        dequeue: function(t, e) {
            e = e || "fx";
            var n = oe.queue(t, e),
                r = n.length,
                i = n.shift(),
                o = oe._queueHooks(t, e),
                s = function() {
                    oe.dequeue(t, e)
                };
            "inprogress" === i && (i = n.shift(), r--), i && ("fx" === e && n.unshift("inprogress"), delete o.stop, i.call(t, s, o)), !r && o && o.empty.fire()
        },
        _queueHooks: function(t, e) {
            var n = e + "queueHooks";
            return oe._data(t, n) || oe._data(t, n, {
                empty: oe.Callbacks("once memory").add(function() {
                    oe._removeData(t, e + "queue"), oe._removeData(t, n)
                })
            })
        }
    }), oe.fn.extend({
        queue: function(t, e) {
            var n = 2;
            return "string" != typeof t && (e = t, t = "fx", n--), arguments.length < n ? oe.queue(this[0], t) : void 0 === e ? this : this.each(function() {
                var n = oe.queue(this, t, e);
                oe._queueHooks(this, t), "fx" === t && "inprogress" !== n[0] && oe.dequeue(this, t)
            })
        },
        dequeue: function(t) {
            return this.each(function() {
                oe.dequeue(this, t)
            })
        },
        clearQueue: function(t) {
            return this.queue(t || "fx", [])
        },
        promise: function(t, e) {
            var n, r = 1,
                i = oe.Deferred(),
                o = this,
                s = this.length,
                a = function() {
                    --r || i.resolveWith(o, [o])
                };
            for ("string" != typeof t && (e = t, t = void 0), t = t || "fx"; s--;) n = oe._data(o[s], t + "queueHooks"), n && n.empty && (r++, n.empty.add(a));
            return a(), i.promise(e)
        }
    });
    var Pe = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
        Ee = ["Top", "Right", "Bottom", "Left"],
        Ae = function(t, e) {
            return t = e || t, "none" === oe.css(t, "display") || !oe.contains(t.ownerDocument, t)
        },
        Ne = oe.access = function(t, e, n, r, i, o, s) {
            var a = 0,
                l = t.length,
                u = null == n;
            if ("object" === oe.type(n)) {
                i = !0;
                for (a in n) oe.access(t, e, a, n[a], !0, o, s)
            } else if (void 0 !== r && (i = !0, oe.isFunction(r) || (s = !0), u && (s ? (e.call(t, r), e = null) : (u = e, e = function(t, e, n) {
                    return u.call(oe(t), n)
                })), e))
                for (; l > a; a++) e(t[a], n, s ? r : r.call(t[a], a, e(t[a], n)));
            return i ? t : u ? e.call(t) : l ? e(t[0], n) : o
        },
        Oe = /^(?:checkbox|radio)$/i;
    ! function() {
        var t = me.createDocumentFragment(),
            e = me.createElement("div"),
            n = me.createElement("input");
        if (e.setAttribute("className", "t"), e.innerHTML = "  <link/><table></table><a href='/a'>a</a>", re.leadingWhitespace = 3 === e.firstChild.nodeType, re.tbody = !e.getElementsByTagName("tbody").length, re.htmlSerialize = !!e.getElementsByTagName("link").length, re.html5Clone = "<:nav></:nav>" !== me.createElement("nav").cloneNode(!0).outerHTML, n.type = "checkbox", n.checked = !0, t.appendChild(n), re.appendChecked = n.checked, e.innerHTML = "<textarea>x</textarea>", re.noCloneChecked = !!e.cloneNode(!0).lastChild.defaultValue, t.appendChild(e), e.innerHTML = "<input type='radio' checked='checked' name='t'/>", re.checkClone = e.cloneNode(!0).cloneNode(!0).lastChild.checked, re.noCloneEvent = !0, e.attachEvent && (e.attachEvent("onclick", function() {
                re.noCloneEvent = !1
            }), e.cloneNode(!0).click()), null == re.deleteExpando) {
            re.deleteExpando = !0;
            try {
                delete e.test
            } catch (r) {
                re.deleteExpando = !1
            }
        }
        t = e = n = null
    }(),
    function() {
        var e, n, r = me.createElement("div");
        for (e in {
                submit: !0,
                change: !0,
                focusin: !0
            }) n = "on" + e, (re[e + "Bubbles"] = n in t) || (r.setAttribute(n, "t"), re[e + "Bubbles"] = r.attributes[n].expando === !1);
        r = null
    }();
    var je = /^(?:input|select|textarea)$/i,
        De = /^key/,
        Me = /^(?:mouse|contextmenu)|click/,
        Le = /^(?:focusinfocus|focusoutblur)$/,
        Re = /^([^.]*)(?:\.(.+)|)$/;
    oe.event = {
        global: {},
        add: function(t, e, n, r, i) {
            var o, s, a, l, u, c, f, p, h, d, m, g = oe._data(t);
            if (g) {
                for (n.handler && (l = n, n = l.handler, i = l.selector), n.guid || (n.guid = oe.guid++), (s = g.events) || (s = g.events = {}), (c = g.handle) || (c = g.handle = function(t) {
                        return typeof oe === ke || t && oe.event.triggered === t.type ? void 0 : oe.event.dispatch.apply(c.elem, arguments)
                    }, c.elem = t), e = (e || "").match(xe) || [""], a = e.length; a--;) o = Re.exec(e[a]) || [], h = m = o[1], d = (o[2] || "").split(".").sort(), h && (u = oe.event.special[h] || {}, h = (i ? u.delegateType : u.bindType) || h, u = oe.event.special[h] || {}, f = oe.extend({
                    type: h,
                    origType: m,
                    data: r,
                    handler: n,
                    guid: n.guid,
                    selector: i,
                    needsContext: i && oe.expr.match.needsContext.test(i),
                    namespace: d.join(".")
                }, l), (p = s[h]) || (p = s[h] = [], p.delegateCount = 0, u.setup && u.setup.call(t, r, d, c) !== !1 || (t.addEventListener ? t.addEventListener(h, c, !1) : t.attachEvent && t.attachEvent("on" + h, c))), u.add && (u.add.call(t, f), f.handler.guid || (f.handler.guid = n.guid)), i ? p.splice(p.delegateCount++, 0, f) : p.push(f), oe.event.global[h] = !0);
                t = null
            }
        },
        remove: function(t, e, n, r, i) {
            var o, s, a, l, u, c, f, p, h, d, m, g = oe.hasData(t) && oe._data(t);
            if (g && (c = g.events)) {
                for (e = (e || "").match(xe) || [""], u = e.length; u--;)
                    if (a = Re.exec(e[u]) || [], h = m = a[1], d = (a[2] || "").split(".").sort(), h) {
                        for (f = oe.event.special[h] || {}, h = (r ? f.delegateType : f.bindType) || h, p = c[h] || [], a = a[2] && new RegExp("(^|\\.)" + d.join("\\.(?:.*\\.|)") + "(\\.|$)"), l = o = p.length; o--;) s = p[o], !i && m !== s.origType || n && n.guid !== s.guid || a && !a.test(s.namespace) || r && r !== s.selector && ("**" !== r || !s.selector) || (p.splice(o, 1), s.selector && p.delegateCount--, f.remove && f.remove.call(t, s));
                        l && !p.length && (f.teardown && f.teardown.call(t, d, g.handle) !== !1 || oe.removeEvent(t, h, g.handle), delete c[h])
                    } else
                        for (h in c) oe.event.remove(t, h + e[u], n, r, !0);
                oe.isEmptyObject(c) && (delete g.handle, oe._removeData(t, "events"))
            }
        },
        trigger: function(e, n, r, i) {
            var o, s, a, l, u, c, f, p = [r || me],
                h = ee.call(e, "type") ? e.type : e,
                d = ee.call(e, "namespace") ? e.namespace.split(".") : [];
            if (a = c = r = r || me, 3 !== r.nodeType && 8 !== r.nodeType && !Le.test(h + oe.event.triggered) && (h.indexOf(".") >= 0 && (d = h.split("."), h = d.shift(), d.sort()), s = h.indexOf(":") < 0 && "on" + h, e = e[oe.expando] ? e : new oe.Event(h, "object" == typeof e && e), e.isTrigger = i ? 2 : 3, e.namespace = d.join("."), e.namespace_re = e.namespace ? new RegExp("(^|\\.)" + d.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, e.result = void 0, e.target || (e.target = r), n = null == n ? [e] : oe.makeArray(n, [e]), u = oe.event.special[h] || {}, i || !u.trigger || u.trigger.apply(r, n) !== !1)) {
                if (!i && !u.noBubble && !oe.isWindow(r)) {
                    for (l = u.delegateType || h, Le.test(l + h) || (a = a.parentNode); a; a = a.parentNode) p.push(a), c = a;
                    c === (r.ownerDocument || me) && p.push(c.defaultView || c.parentWindow || t)
                }
                for (f = 0;
                    (a = p[f++]) && !e.isPropagationStopped();) e.type = f > 1 ? l : u.bindType || h, o = (oe._data(a, "events") || {})[e.type] && oe._data(a, "handle"), o && o.apply(a, n), o = s && a[s], o && o.apply && oe.acceptData(a) && (e.result = o.apply(a, n), e.result === !1 && e.preventDefault());
                if (e.type = h, !i && !e.isDefaultPrevented() && (!u._default || u._default.apply(p.pop(), n) === !1) && oe.acceptData(r) && s && r[h] && !oe.isWindow(r)) {
                    c = r[s], c && (r[s] = null), oe.event.triggered = h;
                    try {
                        r[h]()
                    } catch (m) {}
                    oe.event.triggered = void 0, c && (r[s] = c)
                }
                return e.result
            }
        },
        dispatch: function(t) {
            t = oe.event.fix(t);
            var e, n, r, i, o, s = [],
                a = Q.call(arguments),
                l = (oe._data(this, "events") || {})[t.type] || [],
                u = oe.event.special[t.type] || {};
            if (a[0] = t, t.delegateTarget = this, !u.preDispatch || u.preDispatch.call(this, t) !== !1) {
                for (s = oe.event.handlers.call(this, t, l), e = 0;
                    (i = s[e++]) && !t.isPropagationStopped();)
                    for (t.currentTarget = i.elem, o = 0;
                        (r = i.handlers[o++]) && !t.isImmediatePropagationStopped();)(!t.namespace_re || t.namespace_re.test(r.namespace)) && (t.handleObj = r, t.data = r.data, n = ((oe.event.special[r.origType] || {}).handle || r.handler).apply(i.elem, a), void 0 !== n && (t.result = n) === !1 && (t.preventDefault(), t.stopPropagation()));
                return u.postDispatch && u.postDispatch.call(this, t), t.result
            }
        },
        handlers: function(t, e) {
            var n, r, i, o, s = [],
                a = e.delegateCount,
                l = t.target;
            if (a && l.nodeType && (!t.button || "click" !== t.type))
                for (; l != this; l = l.parentNode || this)
                    if (1 === l.nodeType && (l.disabled !== !0 || "click" !== t.type)) {
                        for (i = [], o = 0; a > o; o++) r = e[o], n = r.selector + " ", void 0 === i[n] && (i[n] = r.needsContext ? oe(n, this).index(l) >= 0 : oe.find(n, this, null, [l]).length), i[n] && i.push(r);
                        i.length && s.push({
                            elem: l,
                            handlers: i
                        })
                    }
            return a < e.length && s.push({
                elem: this,
                handlers: e.slice(a)
            }), s
        },
        fix: function(t) {
            if (t[oe.expando]) return t;
            var e, n, r, i = t.type,
                o = t,
                s = this.fixHooks[i];
            for (s || (this.fixHooks[i] = s = Me.test(i) ? this.mouseHooks : De.test(i) ? this.keyHooks : {}), r = s.props ? this.props.concat(s.props) : this.props, t = new oe.Event(o), e = r.length; e--;) n = r[e], t[n] = o[n];
            return t.target || (t.target = o.srcElement || me), 3 === t.target.nodeType && (t.target = t.target.parentNode), t.metaKey = !!t.metaKey, s.filter ? s.filter(t, o) : t
        },
        props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
        fixHooks: {},
        keyHooks: {
            props: "char charCode key keyCode".split(" "),
            filter: function(t, e) {
                return null == t.which && (t.which = null != e.charCode ? e.charCode : e.keyCode), t
            }
        },
        mouseHooks: {
            props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
            filter: function(t, e) {
                var n, r, i, o = e.button,
                    s = e.fromElement;
                return null == t.pageX && null != e.clientX && (r = t.target.ownerDocument || me, i = r.documentElement, n = r.body, t.pageX = e.clientX + (i && i.scrollLeft || n && n.scrollLeft || 0) - (i && i.clientLeft || n && n.clientLeft || 0), t.pageY = e.clientY + (i && i.scrollTop || n && n.scrollTop || 0) - (i && i.clientTop || n && n.clientTop || 0)), !t.relatedTarget && s && (t.relatedTarget = s === t.target ? e.toElement : s), t.which || void 0 === o || (t.which = 1 & o ? 1 : 2 & o ? 3 : 4 & o ? 2 : 0), t
            }
        },
        special: {
            load: {
                noBubble: !0
            },
            focus: {
                trigger: function() {
                    if (this !== d() && this.focus) try {
                        return this.focus(), !1
                    } catch (t) {}
                },
                delegateType: "focusin"
            },
            blur: {
                trigger: function() {
                    return this === d() && this.blur ? (this.blur(), !1) : void 0
                },
                delegateType: "focusout"
            },
            click: {
                trigger: function() {
                    return oe.nodeName(this, "input") && "checkbox" === this.type && this.click ? (this.click(), !1) : void 0
                },
                _default: function(t) {
                    return oe.nodeName(t.target, "a")
                }
            },
            beforeunload: {
                postDispatch: function(t) {
                    void 0 !== t.result && (t.originalEvent.returnValue = t.result)
                }
            }
        },
        simulate: function(t, e, n, r) {
            var i = oe.extend(new oe.Event, n, {
                type: t,
                isSimulated: !0,
                originalEvent: {}
            });
            r ? oe.event.trigger(i, null, e) : oe.event.dispatch.call(e, i), i.isDefaultPrevented() && n.preventDefault()
        }
    }, oe.removeEvent = me.removeEventListener ? function(t, e, n) {
        t.removeEventListener && t.removeEventListener(e, n, !1)
    } : function(t, e, n) {
        var r = "on" + e;
        t.detachEvent && (typeof t[r] === ke && (t[r] = null), t.detachEvent(r, n))
    }, oe.Event = function(t, e) {
        return this instanceof oe.Event ? (t && t.type ? (this.originalEvent = t, this.type = t.type, this.isDefaultPrevented = t.defaultPrevented || void 0 === t.defaultPrevented && (t.returnValue === !1 || t.getPreventDefault && t.getPreventDefault()) ? p : h) : this.type = t, e && oe.extend(this, e), this.timeStamp = t && t.timeStamp || oe.now(), void(this[oe.expando] = !0)) : new oe.Event(t, e)
    }, oe.Event.prototype = {
        isDefaultPrevented: h,
        isPropagationStopped: h,
        isImmediatePropagationStopped: h,
        preventDefault: function() {
            var t = this.originalEvent;
            this.isDefaultPrevented = p, t && (t.preventDefault ? t.preventDefault() : t.returnValue = !1)
        },
        stopPropagation: function() {
            var t = this.originalEvent;
            this.isPropagationStopped = p, t && (t.stopPropagation && t.stopPropagation(), t.cancelBubble = !0)
        },
        stopImmediatePropagation: function() {
            this.isImmediatePropagationStopped = p, this.stopPropagation()
        }
    }, oe.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout"
    }, function(t, e) {
        oe.event.special[t] = {
            delegateType: e,
            bindType: e,
            handle: function(t) {
                var n, r = this,
                    i = t.relatedTarget,
                    o = t.handleObj;
                return (!i || i !== r && !oe.contains(r, i)) && (t.type = o.origType, n = o.handler.apply(this, arguments), t.type = e), n
            }
        }
    }), re.submitBubbles || (oe.event.special.submit = {
        setup: function() {
            return oe.nodeName(this, "form") ? !1 : void oe.event.add(this, "click._submit keypress._submit", function(t) {
                var e = t.target,
                    n = oe.nodeName(e, "input") || oe.nodeName(e, "button") ? e.form : void 0;
                n && !oe._data(n, "submitBubbles") && (oe.event.add(n, "submit._submit", function(t) {
                    t._submit_bubble = !0
                }), oe._data(n, "submitBubbles", !0))
            })
        },
        postDispatch: function(t) {
            t._submit_bubble && (delete t._submit_bubble, this.parentNode && !t.isTrigger && oe.event.simulate("submit", this.parentNode, t, !0))
        },
        teardown: function() {
            return oe.nodeName(this, "form") ? !1 : void oe.event.remove(this, "._submit")
        }
    }), re.changeBubbles || (oe.event.special.change = {
        setup: function() {
            return je.test(this.nodeName) ? (("checkbox" === this.type || "radio" === this.type) && (oe.event.add(this, "propertychange._change", function(t) {
                "checked" === t.originalEvent.propertyName && (this._just_changed = !0)
            }), oe.event.add(this, "click._change", function(t) {
                this._just_changed && !t.isTrigger && (this._just_changed = !1), oe.event.simulate("change", this, t, !0)
            })), !1) : void oe.event.add(this, "beforeactivate._change", function(t) {
                var e = t.target;
                je.test(e.nodeName) && !oe._data(e, "changeBubbles") && (oe.event.add(e, "change._change", function(t) {
                    !this.parentNode || t.isSimulated || t.isTrigger || oe.event.simulate("change", this.parentNode, t, !0)
                }), oe._data(e, "changeBubbles", !0))
            })
        },
        handle: function(t) {
            var e = t.target;
            return this !== e || t.isSimulated || t.isTrigger || "radio" !== e.type && "checkbox" !== e.type ? t.handleObj.handler.apply(this, arguments) : void 0
        },
        teardown: function() {
            return oe.event.remove(this, "._change"), !je.test(this.nodeName)
        }
    }), re.focusinBubbles || oe.each({
        focus: "focusin",
        blur: "focusout"
    }, function(t, e) {
        var n = function(t) {
            oe.event.simulate(e, t.target, oe.event.fix(t), !0)
        };
        oe.event.special[e] = {
            setup: function() {
                var r = this.ownerDocument || this,
                    i = oe._data(r, e);
                i || r.addEventListener(t, n, !0), oe._data(r, e, (i || 0) + 1)
            },
            teardown: function() {
                var r = this.ownerDocument || this,
                    i = oe._data(r, e) - 1;
                i ? oe._data(r, e, i) : (r.removeEventListener(t, n, !0), oe._removeData(r, e))
            }
        }
    }), oe.fn.extend({
        on: function(t, e, n, r, i) {
            var o, s;
            if ("object" == typeof t) {
                "string" != typeof e && (n = n || e, e = void 0);
                for (o in t) this.on(o, e, n, t[o], i);
                return this
            }
            if (null == n && null == r ? (r = e, n = e = void 0) : null == r && ("string" == typeof e ? (r = n, n = void 0) : (r = n, n = e, e = void 0)), r === !1) r = h;
            else if (!r) return this;
            return 1 === i && (s = r, r = function(t) {
                return oe().off(t), s.apply(this, arguments)
            }, r.guid = s.guid || (s.guid = oe.guid++)), this.each(function() {
                oe.event.add(this, t, r, n, e)
            })
        },
        one: function(t, e, n, r) {
            return this.on(t, e, n, r, 1)
        },
        off: function(t, e, n) {
            var r, i;
            if (t && t.preventDefault && t.handleObj) return r = t.handleObj, oe(t.delegateTarget).off(r.namespace ? r.origType + "." + r.namespace : r.origType, r.selector, r.handler), this;
            if ("object" == typeof t) {
                for (i in t) this.off(i, e, t[i]);
                return this
            }
            return (e === !1 || "function" == typeof e) && (n = e, e = void 0), n === !1 && (n = h), this.each(function() {
                oe.event.remove(this, t, n, e)
            })
        },
        trigger: function(t, e) {
            return this.each(function() {
                oe.event.trigger(t, e, this)
            })
        },
        triggerHandler: function(t, e) {
            var n = this[0];
            return n ? oe.event.trigger(t, e, n, !0) : void 0
        }
    });
    var Fe = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",
        qe = / jQuery\d+="(?:null|\d+)"/g,
        He = new RegExp("<(?:" + Fe + ")[\\s/>]", "i"),
        Ie = /^\s+/,
        ze = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,
        Xe = /<([\w:]+)/,
        Be = /<tbody/i,
        $e = /<|&#?\w+;/,
        We = /<(?:script|style|link)/i,
        Ye = /checked\s*(?:[^=]|=\s*.checked.)/i,
        Ue = /^$|\/(?:java|ecma)script/i,
        Ve = /^true\/(.*)/,
        Qe = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,
        Ge = {
            option: [1, "<select multiple='multiple'>", "</select>"],
            legend: [1, "<fieldset>", "</fieldset>"],
            area: [1, "<map>", "</map>"],
            param: [1, "<object>", "</object>"],
            thead: [1, "<table>", "</table>"],
            tr: [2, "<table><tbody>", "</tbody></table>"],
            col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
            td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
            _default: re.htmlSerialize ? [0, "", ""] : [1, "X<div>", "</div>"]
        },
        Ze = m(me),
        Ke = Ze.appendChild(me.createElement("div"));
    Ge.optgroup = Ge.option, Ge.tbody = Ge.tfoot = Ge.colgroup = Ge.caption = Ge.thead, Ge.th = Ge.td, oe.extend({
        clone: function(t, e, n) {
            var r, i, o, s, a, l = oe.contains(t.ownerDocument, t);
            if (re.html5Clone || oe.isXMLDoc(t) || !He.test("<" + t.nodeName + ">") ? o = t.cloneNode(!0) : (Ke.innerHTML = t.outerHTML, Ke.removeChild(o = Ke.firstChild)), !(re.noCloneEvent && re.noCloneChecked || 1 !== t.nodeType && 11 !== t.nodeType || oe.isXMLDoc(t)))
                for (r = g(o), a = g(t), s = 0; null != (i = a[s]); ++s) r[s] && T(i, r[s]);
            if (e)
                if (n)
                    for (a = a || g(t), r = r || g(o), s = 0; null != (i = a[s]); s++) w(i, r[s]);
                else w(t, o);
            return r = g(o, "script"), r.length > 0 && b(r, !l && g(t, "script")), r = a = i = null, o
        },
        buildFragment: function(t, e, n, r) {
            for (var i, o, s, a, l, u, c, f = t.length, p = m(e), h = [], d = 0; f > d; d++)
                if (o = t[d], o || 0 === o)
                    if ("object" === oe.type(o)) oe.merge(h, o.nodeType ? [o] : o);
                    else if ($e.test(o)) {
                for (a = a || p.appendChild(e.createElement("div")), l = (Xe.exec(o) || ["", ""])[1].toLowerCase(), c = Ge[l] || Ge._default, a.innerHTML = c[1] + o.replace(ze, "<$1></$2>") + c[2], i = c[0]; i--;) a = a.lastChild;
                if (!re.leadingWhitespace && Ie.test(o) && h.push(e.createTextNode(Ie.exec(o)[0])), !re.tbody)
                    for (o = "table" !== l || Be.test(o) ? "<table>" !== c[1] || Be.test(o) ? 0 : a : a.firstChild, i = o && o.childNodes.length; i--;) oe.nodeName(u = o.childNodes[i], "tbody") && !u.childNodes.length && o.removeChild(u);
                for (oe.merge(h, a.childNodes), a.textContent = ""; a.firstChild;) a.removeChild(a.firstChild);
                a = p.lastChild
            } else h.push(e.createTextNode(o));
            for (a && p.removeChild(a), re.appendChecked || oe.grep(g(h, "input"), v), d = 0; o = h[d++];)
                if ((!r || -1 === oe.inArray(o, r)) && (s = oe.contains(o.ownerDocument, o), a = g(p.appendChild(o), "script"), s && b(a), n))
                    for (i = 0; o = a[i++];) Ue.test(o.type || "") && n.push(o);
            return a = null, p
        },
        cleanData: function(t, e) {
            for (var n, r, i, o, s = 0, a = oe.expando, l = oe.cache, u = re.deleteExpando, c = oe.event.special; null != (n = t[s]); s++)
                if ((e || oe.acceptData(n)) && (i = n[a], o = i && l[i])) {
                    if (o.events)
                        for (r in o.events) c[r] ? oe.event.remove(n, r) : oe.removeEvent(n, r, o.handle);
                    l[i] && (delete l[i], u ? delete n[a] : typeof n.removeAttribute !== ke ? n.removeAttribute(a) : n[a] = null, V.push(i))
                }
        }
    }), oe.fn.extend({
        text: function(t) {
            return Ne(this, function(t) {
                return void 0 === t ? oe.text(this) : this.empty().append((this[0] && this[0].ownerDocument || me).createTextNode(t))
            }, null, t, arguments.length)
        },
        append: function() {
            return this.domManip(arguments, function(t) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var e = y(this, t);
                    e.appendChild(t)
                }
            })
        },
        prepend: function() {
            return this.domManip(arguments, function(t) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var e = y(this, t);
                    e.insertBefore(t, e.firstChild)
                }
            })
        },
        before: function() {
            return this.domManip(arguments, function(t) {
                this.parentNode && this.parentNode.insertBefore(t, this)
            })
        },
        after: function() {
            return this.domManip(arguments, function(t) {
                this.parentNode && this.parentNode.insertBefore(t, this.nextSibling)
            })
        },
        remove: function(t, e) {
            for (var n, r = t ? oe.filter(t, this) : this, i = 0; null != (n = r[i]); i++) e || 1 !== n.nodeType || oe.cleanData(g(n)), n.parentNode && (e && oe.contains(n.ownerDocument, n) && b(g(n, "script")), n.parentNode.removeChild(n));
            return this
        },
        empty: function() {
            for (var t, e = 0; null != (t = this[e]); e++) {
                for (1 === t.nodeType && oe.cleanData(g(t, !1)); t.firstChild;) t.removeChild(t.firstChild);
                t.options && oe.nodeName(t, "select") && (t.options.length = 0)
            }
            return this
        },
        clone: function(t, e) {
            return t = null == t ? !1 : t, e = null == e ? t : e, this.map(function() {
                return oe.clone(this, t, e)
            })
        },
        html: function(t) {
            return Ne(this, function(t) {
                var e = this[0] || {},
                    n = 0,
                    r = this.length;
                if (void 0 === t) return 1 === e.nodeType ? e.innerHTML.replace(qe, "") : void 0;
                if (!("string" != typeof t || We.test(t) || !re.htmlSerialize && He.test(t) || !re.leadingWhitespace && Ie.test(t) || Ge[(Xe.exec(t) || ["", ""])[1].toLowerCase()])) {
                    t = t.replace(ze, "<$1></$2>");
                    try {
                        for (; r > n; n++) e = this[n] || {}, 1 === e.nodeType && (oe.cleanData(g(e, !1)), e.innerHTML = t);
                        e = 0
                    } catch (i) {}
                }
                e && this.empty().append(t)
            }, null, t, arguments.length)
        },
        replaceWith: function() {
            var t = arguments[0];
            return this.domManip(arguments, function(e) {
                t = this.parentNode, oe.cleanData(g(this)), t && t.replaceChild(e, this)
            }), t && (t.length || t.nodeType) ? this : this.remove()
        },
        detach: function(t) {
            return this.remove(t, !0)
        },
        domManip: function(t, e) {
            t = G.apply([], t);
            var n, r, i, o, s, a, l = 0,
                u = this.length,
                c = this,
                f = u - 1,
                p = t[0],
                h = oe.isFunction(p);
            if (h || u > 1 && "string" == typeof p && !re.checkClone && Ye.test(p)) return this.each(function(n) {
                var r = c.eq(n);
                h && (t[0] = p.call(this, n, r.html())), r.domManip(t, e)
            });
            if (u && (a = oe.buildFragment(t, this[0].ownerDocument, !1, this), n = a.firstChild, 1 === a.childNodes.length && (a = n), n)) {
                for (o = oe.map(g(a, "script"), _), i = o.length; u > l; l++) r = a, l !== f && (r = oe.clone(r, !0, !0), i && oe.merge(o, g(r, "script"))), e.call(this[l], r, l);
                if (i)
                    for (s = o[o.length - 1].ownerDocument, oe.map(o, x), l = 0; i > l; l++) r = o[l], Ue.test(r.type || "") && !oe._data(r, "globalEval") && oe.contains(s, r) && (r.src ? oe._evalUrl && oe._evalUrl(r.src) : oe.globalEval((r.text || r.textContent || r.innerHTML || "").replace(Qe, "")));
                a = n = null
            }
            return this
        }
    }), oe.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function(t, e) {
        oe.fn[t] = function(t) {
            for (var n, r = 0, i = [], o = oe(t), s = o.length - 1; s >= r; r++) n = r === s ? this : this.clone(!0), oe(o[r])[e](n), Z.apply(i, n.get());
            return this.pushStack(i)
        }
    });
    var Je, tn = {};
    ! function() {
        var t, e, n = me.createElement("div"),
            r = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;padding:0;margin:0;border:0";
        n.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", t = n.getElementsByTagName("a")[0], t.style.cssText = "float:left;opacity:.5", re.opacity = /^0.5/.test(t.style.opacity), re.cssFloat = !!t.style.cssFloat, n.style.backgroundClip = "content-box", n.cloneNode(!0).style.backgroundClip = "", re.clearCloneStyle = "content-box" === n.style.backgroundClip, t = n = null, re.shrinkWrapBlocks = function() {
            var t, n, i, o;
            if (null == e) {
                if (t = me.getElementsByTagName("body")[0], !t) return;
                o = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px", n = me.createElement("div"), i = me.createElement("div"), t.appendChild(n).appendChild(i), e = !1, typeof i.style.zoom !== ke && (i.style.cssText = r + ";width:1px;padding:1px;zoom:1", i.innerHTML = "<div></div>", i.firstChild.style.width = "5px", e = 3 !== i.offsetWidth), t.removeChild(n), t = n = i = null
            }
            return e
        }
    }();
    var en, nn, rn = /^margin/,
        on = new RegExp("^(" + Pe + ")(?!px)[a-z%]+$", "i"),
        sn = /^(top|right|bottom|left)$/;
    t.getComputedStyle ? (en = function(t) {
            return t.ownerDocument.defaultView.getComputedStyle(t, null)
        }, nn = function(t, e, n) {
            var r, i, o, s, a = t.style;
            return n = n || en(t), s = n ? n.getPropertyValue(e) || n[e] : void 0, n && ("" !== s || oe.contains(t.ownerDocument, t) || (s = oe.style(t, e)), on.test(s) && rn.test(e) && (r = a.width, i = a.minWidth, o = a.maxWidth, a.minWidth = a.maxWidth = a.width = s, s = n.width, a.width = r, a.minWidth = i, a.maxWidth = o)), void 0 === s ? s : s + ""
        }) : me.documentElement.currentStyle && (en = function(t) {
            return t.currentStyle
        }, nn = function(t, e, n) {
            var r, i, o, s, a = t.style;
            return n = n || en(t), s = n ? n[e] : void 0, null == s && a && a[e] && (s = a[e]), on.test(s) && !sn.test(e) && (r = a.left, i = t.runtimeStyle, o = i && i.left, o && (i.left = t.currentStyle.left), a.left = "fontSize" === e ? "1em" : s, s = a.pixelLeft + "px", a.left = r, o && (i.left = o)), void 0 === s ? s : s + "" || "auto"
        }),
        function() {
            function e() {
                var e, n, r = me.getElementsByTagName("body")[0];
                r && (e = me.createElement("div"), n = me.createElement("div"), e.style.cssText = u, r.appendChild(e).appendChild(n), n.style.cssText = "-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;position:absolute;display:block;padding:1px;border:1px;width:4px;margin-top:1%;top:1%", oe.swap(r, null != r.style.zoom ? {
                    zoom: 1
                } : {}, function() {
                    i = 4 === n.offsetWidth
                }), o = !0, s = !1, a = !0, t.getComputedStyle && (s = "1%" !== (t.getComputedStyle(n, null) || {}).top, o = "4px" === (t.getComputedStyle(n, null) || {
                    width: "4px"
                }).width), r.removeChild(e), n = r = null)
            }
            var n, r, i, o, s, a, l = me.createElement("div"),
                u = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px",
                c = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;padding:0;margin:0;border:0";
            l.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", n = l.getElementsByTagName("a")[0], n.style.cssText = "float:left;opacity:.5", re.opacity = /^0.5/.test(n.style.opacity), re.cssFloat = !!n.style.cssFloat, l.style.backgroundClip = "content-box", l.cloneNode(!0).style.backgroundClip = "", re.clearCloneStyle = "content-box" === l.style.backgroundClip, n = l = null, oe.extend(re, {
                reliableHiddenOffsets: function() {
                    if (null != r) return r;
                    var t, e, n, i = me.createElement("div"),
                        o = me.getElementsByTagName("body")[0];
                    if (o) return i.setAttribute("className", "t"), i.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", t = me.createElement("div"), t.style.cssText = u, o.appendChild(t).appendChild(i), i.innerHTML = "<table><tr><td></td><td>t</td></tr></table>", e = i.getElementsByTagName("td"), e[0].style.cssText = "padding:0;margin:0;border:0;display:none", n = 0 === e[0].offsetHeight, e[0].style.display = "", e[1].style.display = "none", r = n && 0 === e[0].offsetHeight, o.removeChild(t), i = o = null, r
                },
                boxSizing: function() {
                    return null == i && e(), i
                },
                boxSizingReliable: function() {
                    return null == o && e(), o
                },
                pixelPosition: function() {
                    return null == s && e(), s
                },
                reliableMarginRight: function() {
                    var e, n, r, i;
                    if (null == a && t.getComputedStyle) {
                        if (e = me.getElementsByTagName("body")[0], !e) return;
                        n = me.createElement("div"), r = me.createElement("div"), n.style.cssText = u, e.appendChild(n).appendChild(r), i = r.appendChild(me.createElement("div")), i.style.cssText = r.style.cssText = c, i.style.marginRight = i.style.width = "0", r.style.width = "1px", a = !parseFloat((t.getComputedStyle(i, null) || {}).marginRight), e.removeChild(n)
                    }
                    return a
                }
            })
        }(), oe.swap = function(t, e, n, r) {
            var i, o, s = {};
            for (o in e) s[o] = t.style[o], t.style[o] = e[o];
            i = n.apply(t, r || []);
            for (o in e) t.style[o] = s[o];
            return i
        };
    var an = /alpha\([^)]*\)/i,
        ln = /opacity\s*=\s*([^)]*)/,
        un = /^(none|table(?!-c[ea]).+)/,
        cn = new RegExp("^(" + Pe + ")(.*)$", "i"),
        fn = new RegExp("^([+-])=(" + Pe + ")", "i"),
        pn = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        },
        hn = {
            letterSpacing: 0,
            fontWeight: 400
        },
        dn = ["Webkit", "O", "Moz", "ms"];
    oe.extend({
        cssHooks: {
            opacity: {
                get: function(t, e) {
                    if (e) {
                        var n = nn(t, "opacity");
                        return "" === n ? "1" : n
                    }
                }
            }
        },
        cssNumber: {
            columnCount: !0,
            fillOpacity: !0,
            fontWeight: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {
            "float": re.cssFloat ? "cssFloat" : "styleFloat"
        },
        style: function(t, e, n, r) {
            if (t && 3 !== t.nodeType && 8 !== t.nodeType && t.style) {
                var i, o, s, a = oe.camelCase(e),
                    l = t.style;
                if (e = oe.cssProps[a] || (oe.cssProps[a] = P(l, a)), s = oe.cssHooks[e] || oe.cssHooks[a], void 0 === n) return s && "get" in s && void 0 !== (i = s.get(t, !1, r)) ? i : l[e];
                if (o = typeof n, "string" === o && (i = fn.exec(n)) && (n = (i[1] + 1) * i[2] + parseFloat(oe.css(t, e)), o = "number"), null != n && n === n && ("number" !== o || oe.cssNumber[a] || (n += "px"), re.clearCloneStyle || "" !== n || 0 !== e.indexOf("background") || (l[e] = "inherit"), !(s && "set" in s && void 0 === (n = s.set(t, n, r))))) try {
                    l[e] = "", l[e] = n
                } catch (u) {}
            }
        },
        css: function(t, e, n, r) {
            var i, o, s, a = oe.camelCase(e);
            return e = oe.cssProps[a] || (oe.cssProps[a] = P(t.style, a)), s = oe.cssHooks[e] || oe.cssHooks[a], s && "get" in s && (o = s.get(t, !0, n)), void 0 === o && (o = nn(t, e, r)), "normal" === o && e in hn && (o = hn[e]), "" === n || n ? (i = parseFloat(o), n === !0 || oe.isNumeric(i) ? i || 0 : o) : o
        }
    }), oe.each(["height", "width"], function(t, e) {
        oe.cssHooks[e] = {
            get: function(t, n, r) {
                return n ? 0 === t.offsetWidth && un.test(oe.css(t, "display")) ? oe.swap(t, pn, function() {
                    return O(t, e, r)
                }) : O(t, e, r) : void 0
            },
            set: function(t, n, r) {
                var i = r && en(t);
                return A(t, n, r ? N(t, e, r, re.boxSizing() && "border-box" === oe.css(t, "boxSizing", !1, i), i) : 0)
            }
        }
    }), re.opacity || (oe.cssHooks.opacity = {
        get: function(t, e) {
            return ln.test((e && t.currentStyle ? t.currentStyle.filter : t.style.filter) || "") ? .01 * parseFloat(RegExp.$1) + "" : e ? "1" : ""
        },
        set: function(t, e) {
            var n = t.style,
                r = t.currentStyle,
                i = oe.isNumeric(e) ? "alpha(opacity=" + 100 * e + ")" : "",
                o = r && r.filter || n.filter || "";
            n.zoom = 1, (e >= 1 || "" === e) && "" === oe.trim(o.replace(an, "")) && n.removeAttribute && (n.removeAttribute("filter"), "" === e || r && !r.filter) || (n.filter = an.test(o) ? o.replace(an, i) : o + " " + i)
        }
    }), oe.cssHooks.marginRight = C(re.reliableMarginRight, function(t, e) {
        return e ? oe.swap(t, {
            display: "inline-block"
        }, nn, [t, "marginRight"]) : void 0
    }), oe.each({
        margin: "",
        padding: "",
        border: "Width"
    }, function(t, e) {
        oe.cssHooks[t + e] = {
            expand: function(n) {
                for (var r = 0, i = {}, o = "string" == typeof n ? n.split(" ") : [n]; 4 > r; r++) i[t + Ee[r] + e] = o[r] || o[r - 2] || o[0];
                return i
            }
        }, rn.test(t) || (oe.cssHooks[t + e].set = A)
    }), oe.fn.extend({
        css: function(t, e) {
            return Ne(this, function(t, e, n) {
                var r, i, o = {},
                    s = 0;
                if (oe.isArray(e)) {
                    for (r = en(t), i = e.length; i > s; s++) o[e[s]] = oe.css(t, e[s], !1, r);
                    return o
                }
                return void 0 !== n ? oe.style(t, e, n) : oe.css(t, e)
            }, t, e, arguments.length > 1)
        },
        show: function() {
            return E(this, !0)
        },
        hide: function() {
            return E(this)
        },
        toggle: function(t) {
            return "boolean" == typeof t ? t ? this.show() : this.hide() : this.each(function() {
                Ae(this) ? oe(this).show() : oe(this).hide()
            })
        }
    }), oe.Tween = j, j.prototype = {
        constructor: j,
        init: function(t, e, n, r, i, o) {
            this.elem = t, this.prop = n, this.easing = i || "swing", this.options = e, this.start = this.now = this.cur(), this.end = r, this.unit = o || (oe.cssNumber[n] ? "" : "px")
        },
        cur: function() {
            var t = j.propHooks[this.prop];
            return t && t.get ? t.get(this) : j.propHooks._default.get(this)
        },
        run: function(t) {
            var e, n = j.propHooks[this.prop];
            return this.pos = e = this.options.duration ? oe.easing[this.easing](t, this.options.duration * t, 0, 1, this.options.duration) : t, this.now = (this.end - this.start) * e + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n && n.set ? n.set(this) : j.propHooks._default.set(this), this
        }
    }, j.prototype.init.prototype = j.prototype, j.propHooks = {
        _default: {
            get: function(t) {
                var e;
                return null == t.elem[t.prop] || t.elem.style && null != t.elem.style[t.prop] ? (e = oe.css(t.elem, t.prop, ""), e && "auto" !== e ? e : 0) : t.elem[t.prop]
            },
            set: function(t) {
                oe.fx.step[t.prop] ? oe.fx.step[t.prop](t) : t.elem.style && (null != t.elem.style[oe.cssProps[t.prop]] || oe.cssHooks[t.prop]) ? oe.style(t.elem, t.prop, t.now + t.unit) : t.elem[t.prop] = t.now
            }
        }
    }, j.propHooks.scrollTop = j.propHooks.scrollLeft = {
        set: function(t) {
            t.elem.nodeType && t.elem.parentNode && (t.elem[t.prop] = t.now)
        }
    }, oe.easing = {
        linear: function(t) {
            return t
        },
        swing: function(t) {
            return .5 - Math.cos(t * Math.PI) / 2
        }
    }, oe.fx = j.prototype.init, oe.fx.step = {};
    var mn, gn, vn = /^(?:toggle|show|hide)$/,
        yn = new RegExp("^(?:([+-])=|)(" + Pe + ")([a-z%]*)$", "i"),
        _n = /queueHooks$/,
        xn = [R],
        bn = {
            "*": [function(t, e) {
                var n = this.createTween(t, e),
                    r = n.cur(),
                    i = yn.exec(e),
                    o = i && i[3] || (oe.cssNumber[t] ? "" : "px"),
                    s = (oe.cssNumber[t] || "px" !== o && +r) && yn.exec(oe.css(n.elem, t)),
                    a = 1,
                    l = 20;
                if (s && s[3] !== o) {
                    o = o || s[3], i = i || [], s = +r || 1;
                    do a = a || ".5", s /= a, oe.style(n.elem, t, s + o); while (a !== (a = n.cur() / r) && 1 !== a && --l)
                }
                return i && (s = n.start = +s || +r || 0, n.unit = o, n.end = i[1] ? s + (i[1] + 1) * i[2] : +i[2]), n
            }]
        };
    oe.Animation = oe.extend(q, {
            tweener: function(t, e) {
                oe.isFunction(t) ? (e = t, t = ["*"]) : t = t.split(" ");
                for (var n, r = 0, i = t.length; i > r; r++) n = t[r], bn[n] = bn[n] || [], bn[n].unshift(e)
            },
            prefilter: function(t, e) {
                e ? xn.unshift(t) : xn.push(t)
            }
        }), oe.speed = function(t, e, n) {
            var r = t && "object" == typeof t ? oe.extend({}, t) : {
                complete: n || !n && e || oe.isFunction(t) && t,
                duration: t,
                easing: n && e || e && !oe.isFunction(e) && e
            };
            return r.duration = oe.fx.off ? 0 : "number" == typeof r.duration ? r.duration : r.duration in oe.fx.speeds ? oe.fx.speeds[r.duration] : oe.fx.speeds._default, (null == r.queue || r.queue === !0) && (r.queue = "fx"), r.old = r.complete, r.complete = function() {
                oe.isFunction(r.old) && r.old.call(this), r.queue && oe.dequeue(this, r.queue)
            }, r
        }, oe.fn.extend({
            fadeTo: function(t, e, n, r) {
                return this.filter(Ae).css("opacity", 0).show().end().animate({
                    opacity: e
                }, t, n, r)
            },
            animate: function(t, e, n, r) {
                var i = oe.isEmptyObject(t),
                    o = oe.speed(e, n, r),
                    s = function() {
                        var e = q(this, oe.extend({}, t), o);
                        (i || oe._data(this, "finish")) && e.stop(!0)
                    };
                return s.finish = s, i || o.queue === !1 ? this.each(s) : this.queue(o.queue, s)
            },
            stop: function(t, e, n) {
                var r = function(t) {
                    var e = t.stop;
                    delete t.stop, e(n)
                };
                return "string" != typeof t && (n = e, e = t, t = void 0), e && t !== !1 && this.queue(t || "fx", []), this.each(function() {
                    var e = !0,
                        i = null != t && t + "queueHooks",
                        o = oe.timers,
                        s = oe._data(this);
                    if (i) s[i] && s[i].stop && r(s[i]);
                    else
                        for (i in s) s[i] && s[i].stop && _n.test(i) && r(s[i]);
                    for (i = o.length; i--;) o[i].elem !== this || null != t && o[i].queue !== t || (o[i].anim.stop(n), e = !1, o.splice(i, 1));
                    (e || !n) && oe.dequeue(this, t)
                })
            },
            finish: function(t) {
                return t !== !1 && (t = t || "fx"), this.each(function() {
                    var e, n = oe._data(this),
                        r = n[t + "queue"],
                        i = n[t + "queueHooks"],
                        o = oe.timers,
                        s = r ? r.length : 0;
                    for (n.finish = !0, oe.queue(this, t, []), i && i.stop && i.stop.call(this, !0), e = o.length; e--;) o[e].elem === this && o[e].queue === t && (o[e].anim.stop(!0), o.splice(e, 1));
                    for (e = 0; s > e; e++) r[e] && r[e].finish && r[e].finish.call(this);
                    delete n.finish
                })
            }
        }), oe.each(["toggle", "show", "hide"], function(t, e) {
            var n = oe.fn[e];
            oe.fn[e] = function(t, r, i) {
                return null == t || "boolean" == typeof t ? n.apply(this, arguments) : this.animate(M(e, !0), t, r, i)
            }
        }), oe.each({
            slideDown: M("show"),
            slideUp: M("hide"),
            slideToggle: M("toggle"),
            fadeIn: {
                opacity: "show"
            },
            fadeOut: {
                opacity: "hide"
            },
            fadeToggle: {
                opacity: "toggle"
            }
        }, function(t, e) {
            oe.fn[t] = function(t, n, r) {
                return this.animate(e, t, n, r)
            }
        }), oe.timers = [], oe.fx.tick = function() {
            var t, e = oe.timers,
                n = 0;
            for (mn = oe.now(); n < e.length; n++) t = e[n], t() || e[n] !== t || e.splice(n--, 1);
            e.length || oe.fx.stop(), mn = void 0
        }, oe.fx.timer = function(t) {
            oe.timers.push(t), t() ? oe.fx.start() : oe.timers.pop()
        }, oe.fx.interval = 13, oe.fx.start = function() {
            gn || (gn = setInterval(oe.fx.tick, oe.fx.interval))
        }, oe.fx.stop = function() {
            clearInterval(gn), gn = null
        }, oe.fx.speeds = {
            slow: 600,
            fast: 200,
            _default: 400
        }, oe.fn.delay = function(t, e) {
            return t = oe.fx ? oe.fx.speeds[t] || t : t, e = e || "fx", this.queue(e, function(e, n) {
                var r = setTimeout(e, t);
                n.stop = function() {
                    clearTimeout(r)
                }
            })
        },
        function() {
            var t, e, n, r, i = me.createElement("div");
            i.setAttribute("className", "t"), i.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", t = i.getElementsByTagName("a")[0], n = me.createElement("select"), r = n.appendChild(me.createElement("option")), e = i.getElementsByTagName("input")[0], t.style.cssText = "top:1px", re.getSetAttribute = "t" !== i.className, re.style = /top/.test(t.getAttribute("style")), re.hrefNormalized = "/a" === t.getAttribute("href"), re.checkOn = !!e.value, re.optSelected = r.selected, re.enctype = !!me.createElement("form").enctype, n.disabled = !0, re.optDisabled = !r.disabled, e = me.createElement("input"), e.setAttribute("value", ""), re.input = "" === e.getAttribute("value"), e.value = "t", e.setAttribute("type", "radio"), re.radioValue = "t" === e.value, t = e = n = r = i = null
        }();
    var wn = /\r/g;
    oe.fn.extend({
        val: function(t) {
            var e, n, r, i = this[0]; {
                if (arguments.length) return r = oe.isFunction(t), this.each(function(n) {
                    var i;
                    1 === this.nodeType && (i = r ? t.call(this, n, oe(this).val()) : t, null == i ? i = "" : "number" == typeof i ? i += "" : oe.isArray(i) && (i = oe.map(i, function(t) {
                        return null == t ? "" : t + ""
                    })), e = oe.valHooks[this.type] || oe.valHooks[this.nodeName.toLowerCase()], e && "set" in e && void 0 !== e.set(this, i, "value") || (this.value = i))
                });
                if (i) return e = oe.valHooks[i.type] || oe.valHooks[i.nodeName.toLowerCase()], e && "get" in e && void 0 !== (n = e.get(i, "value")) ? n : (n = i.value, "string" == typeof n ? n.replace(wn, "") : null == n ? "" : n)
            }
        }
    }), oe.extend({
        valHooks: {
            option: {
                get: function(t) {
                    var e = oe.find.attr(t, "value");
                    return null != e ? e : oe.text(t)
                }
            },
            select: {
                get: function(t) {
                    for (var e, n, r = t.options, i = t.selectedIndex, o = "select-one" === t.type || 0 > i, s = o ? null : [], a = o ? i + 1 : r.length, l = 0 > i ? a : o ? i : 0; a > l; l++)
                        if (n = r[l], !(!n.selected && l !== i || (re.optDisabled ? n.disabled : null !== n.getAttribute("disabled")) || n.parentNode.disabled && oe.nodeName(n.parentNode, "optgroup"))) {
                            if (e = oe(n).val(), o) return e;
                            s.push(e)
                        }
                    return s
                },
                set: function(t, e) {
                    for (var n, r, i = t.options, o = oe.makeArray(e), s = i.length; s--;)
                        if (r = i[s], oe.inArray(oe.valHooks.option.get(r), o) >= 0) try {
                            r.selected = n = !0
                        } catch (a) {
                            r.scrollHeight
                        } else r.selected = !1;
                    return n || (t.selectedIndex = -1), i
                }
            }
        }
    }), oe.each(["radio", "checkbox"], function() {
        oe.valHooks[this] = {
            set: function(t, e) {
                return oe.isArray(e) ? t.checked = oe.inArray(oe(t).val(), e) >= 0 : void 0
            }
        }, re.checkOn || (oe.valHooks[this].get = function(t) {
            return null === t.getAttribute("value") ? "on" : t.value
        })
    });
    var Tn, kn, Sn = oe.expr.attrHandle,
        Cn = /^(?:checked|selected)$/i,
        Pn = re.getSetAttribute,
        En = re.input;
    oe.fn.extend({
        attr: function(t, e) {
            return Ne(this, oe.attr, t, e, arguments.length > 1)
        },
        removeAttr: function(t) {
            return this.each(function() {
                oe.removeAttr(this, t)
            })
        }
    }), oe.extend({
        attr: function(t, e, n) {
            var r, i, o = t.nodeType;
            if (t && 3 !== o && 8 !== o && 2 !== o) return typeof t.getAttribute === ke ? oe.prop(t, e, n) : (1 === o && oe.isXMLDoc(t) || (e = e.toLowerCase(), r = oe.attrHooks[e] || (oe.expr.match.bool.test(e) ? kn : Tn)), void 0 === n ? r && "get" in r && null !== (i = r.get(t, e)) ? i : (i = oe.find.attr(t, e), null == i ? void 0 : i) : null !== n ? r && "set" in r && void 0 !== (i = r.set(t, n, e)) ? i : (t.setAttribute(e, n + ""), n) : void oe.removeAttr(t, e))
        },
        removeAttr: function(t, e) {
            var n, r, i = 0,
                o = e && e.match(xe);
            if (o && 1 === t.nodeType)
                for (; n = o[i++];) r = oe.propFix[n] || n, oe.expr.match.bool.test(n) ? En && Pn || !Cn.test(n) ? t[r] = !1 : t[oe.camelCase("default-" + n)] = t[r] = !1 : oe.attr(t, n, ""), t.removeAttribute(Pn ? n : r)
        },
        attrHooks: {
            type: {
                set: function(t, e) {
                    if (!re.radioValue && "radio" === e && oe.nodeName(t, "input")) {
                        var n = t.value;
                        return t.setAttribute("type", e), n && (t.value = n), e
                    }
                }
            }
        }
    }), kn = {
        set: function(t, e, n) {
            return e === !1 ? oe.removeAttr(t, n) : En && Pn || !Cn.test(n) ? t.setAttribute(!Pn && oe.propFix[n] || n, n) : t[oe.camelCase("default-" + n)] = t[n] = !0, n
        }
    }, oe.each(oe.expr.match.bool.source.match(/\w+/g), function(t, e) {
        var n = Sn[e] || oe.find.attr;
        Sn[e] = En && Pn || !Cn.test(e) ? function(t, e, r) {
            var i, o;
            return r || (o = Sn[e], Sn[e] = i, i = null != n(t, e, r) ? e.toLowerCase() : null, Sn[e] = o), i
        } : function(t, e, n) {
            return n ? void 0 : t[oe.camelCase("default-" + e)] ? e.toLowerCase() : null
        }
    }), En && Pn || (oe.attrHooks.value = {
        set: function(t, e, n) {
            return oe.nodeName(t, "input") ? void(t.defaultValue = e) : Tn && Tn.set(t, e, n)
        }
    }), Pn || (Tn = {
        set: function(t, e, n) {
            var r = t.getAttributeNode(n);
            return r || t.setAttributeNode(r = t.ownerDocument.createAttribute(n)), r.value = e += "", "value" === n || e === t.getAttribute(n) ? e : void 0
        }
    }, Sn.id = Sn.name = Sn.coords = function(t, e, n) {
        var r;
        return n ? void 0 : (r = t.getAttributeNode(e)) && "" !== r.value ? r.value : null
    }, oe.valHooks.button = {
        get: function(t, e) {
            var n = t.getAttributeNode(e);
            return n && n.specified ? n.value : void 0
        },
        set: Tn.set
    }, oe.attrHooks.contenteditable = {
        set: function(t, e, n) {
            Tn.set(t, "" === e ? !1 : e, n)
        }
    }, oe.each(["width", "height"], function(t, e) {
        oe.attrHooks[e] = {
            set: function(t, n) {
                return "" === n ? (t.setAttribute(e, "auto"), n) : void 0
            }
        }
    })), re.style || (oe.attrHooks.style = {
        get: function(t) {
            return t.style.cssText || void 0
        },
        set: function(t, e) {
            return t.style.cssText = e + ""
        }
    });
    var An = /^(?:input|select|textarea|button|object)$/i,
        Nn = /^(?:a|area)$/i;
    oe.fn.extend({
        prop: function(t, e) {
            return Ne(this, oe.prop, t, e, arguments.length > 1)
        },
        removeProp: function(t) {
            return t = oe.propFix[t] || t, this.each(function() {
                try {
                    this[t] = void 0, delete this[t]
                } catch (e) {}
            })
        }
    }), oe.extend({
        propFix: {
            "for": "htmlFor",
            "class": "className"
        },
        prop: function(t, e, n) {
            var r, i, o, s = t.nodeType;
            if (t && 3 !== s && 8 !== s && 2 !== s) return o = 1 !== s || !oe.isXMLDoc(t), o && (e = oe.propFix[e] || e, i = oe.propHooks[e]), void 0 !== n ? i && "set" in i && void 0 !== (r = i.set(t, n, e)) ? r : t[e] = n : i && "get" in i && null !== (r = i.get(t, e)) ? r : t[e]
        },
        propHooks: {
            tabIndex: {
                get: function(t) {
                    var e = oe.find.attr(t, "tabindex");
                    return e ? parseInt(e, 10) : An.test(t.nodeName) || Nn.test(t.nodeName) && t.href ? 0 : -1
                }
            }
        }
    }), re.hrefNormalized || oe.each(["href", "src"], function(t, e) {
        oe.propHooks[e] = {
            get: function(t) {
                return t.getAttribute(e, 4)
            }
        }
    }), re.optSelected || (oe.propHooks.selected = {
        get: function(t) {
            var e = t.parentNode;
            return e && (e.selectedIndex, e.parentNode && e.parentNode.selectedIndex), null
        }
    }), oe.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function() {
        oe.propFix[this.toLowerCase()] = this
    }), re.enctype || (oe.propFix.enctype = "encoding");
    var On = /[\t\r\n\f]/g;
    oe.fn.extend({
        addClass: function(t) {
            var e, n, r, i, o, s, a = 0,
                l = this.length,
                u = "string" == typeof t && t;
            if (oe.isFunction(t)) return this.each(function(e) {
                oe(this).addClass(t.call(this, e, this.className))
            });
            if (u)
                for (e = (t || "").match(xe) || []; l > a; a++)
                    if (n = this[a], r = 1 === n.nodeType && (n.className ? (" " + n.className + " ").replace(On, " ") : " ")) {
                        for (o = 0; i = e[o++];) r.indexOf(" " + i + " ") < 0 && (r += i + " ");
                        s = oe.trim(r), n.className !== s && (n.className = s)
                    }
            return this
        },
        removeClass: function(t) {
            var e, n, r, i, o, s, a = 0,
                l = this.length,
                u = 0 === arguments.length || "string" == typeof t && t;
            if (oe.isFunction(t)) return this.each(function(e) {
                oe(this).removeClass(t.call(this, e, this.className))
            });
            if (u)
                for (e = (t || "").match(xe) || []; l > a; a++)
                    if (n = this[a], r = 1 === n.nodeType && (n.className ? (" " + n.className + " ").replace(On, " ") : "")) {
                        for (o = 0; i = e[o++];)
                            for (; r.indexOf(" " + i + " ") >= 0;) r = r.replace(" " + i + " ", " ");
                        s = t ? oe.trim(r) : "", n.className !== s && (n.className = s)
                    }
            return this
        },
        toggleClass: function(t, e) {
            var n = typeof t;
            return "boolean" == typeof e && "string" === n ? e ? this.addClass(t) : this.removeClass(t) : this.each(oe.isFunction(t) ? function(n) {
                oe(this).toggleClass(t.call(this, n, this.className, e), e)
            } : function() {
                if ("string" === n)
                    for (var e, r = 0, i = oe(this), o = t.match(xe) || []; e = o[r++];) i.hasClass(e) ? i.removeClass(e) : i.addClass(e);
                else(n === ke || "boolean" === n) && (this.className && oe._data(this, "__className__", this.className), this.className = this.className || t === !1 ? "" : oe._data(this, "__className__") || "")
            })
        },
        hasClass: function(t) {
            for (var e = " " + t + " ", n = 0, r = this.length; r > n; n++)
                if (1 === this[n].nodeType && (" " + this[n].className + " ").replace(On, " ").indexOf(e) >= 0) return !0;
            return !1
        }
    }), oe.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), function(t, e) {
        oe.fn[e] = function(t, n) {
            return arguments.length > 0 ? this.on(e, null, t, n) : this.trigger(e)
        }
    }), oe.fn.extend({
        hover: function(t, e) {
            return this.mouseenter(t).mouseleave(e || t)
        },
        bind: function(t, e, n) {
            return this.on(t, null, e, n)
        },
        unbind: function(t, e) {
            return this.off(t, null, e)
        },
        delegate: function(t, e, n, r) {
            return this.on(e, t, n, r)
        },
        undelegate: function(t, e, n) {
            return 1 === arguments.length ? this.off(t, "**") : this.off(e, t || "**", n)
        }
    });
    var jn = oe.now(),
        Dn = /\?/,
        Mn = /(,)|(\[|{)|(}|])|"(?:[^"\\\r\n]|\\["\\\/bfnrt]|\\u[\da-fA-F]{4})*"\s*:?|true|false|null|-?(?!0\d)\d+(?:\.\d+|)(?:[eE][+-]?\d+|)/g;
    oe.parseJSON = function(e) {
        if (t.JSON && t.JSON.parse) return t.JSON.parse(e + "");
        var n, r = null,
            i = oe.trim(e + "");
        return i && !oe.trim(i.replace(Mn, function(t, e, i, o) {
            return n && e && (r = 0), 0 === r ? t : (n = i || e, r += !o - !i, "")
        })) ? Function("return " + i)() : oe.error("Invalid JSON: " + e)
    }, oe.parseXML = function(e) {
        var n, r;
        if (!e || "string" != typeof e) return null;
        try {
            t.DOMParser ? (r = new DOMParser, n = r.parseFromString(e, "text/xml")) : (n = new ActiveXObject("Microsoft.XMLDOM"), n.async = "false", n.loadXML(e))
        } catch (i) {
            n = void 0
        }
        return n && n.documentElement && !n.getElementsByTagName("parsererror").length || oe.error("Invalid XML: " + e), n
    };
    var Ln, Rn, Fn = /#.*$/,
        qn = /([?&])_=[^&]*/,
        Hn = /^(.*?):[ \t]*([^\r\n]*)\r?$/gm,
        In = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
        zn = /^(?:GET|HEAD)$/,
        Xn = /^\/\//,
        Bn = /^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/,
        $n = {},
        Wn = {},
        Yn = "*/".concat("*");
    try {
        Rn = location.href
    } catch (Un) {
        Rn = me.createElement("a"), Rn.href = "", Rn = Rn.href
    }
    Ln = Bn.exec(Rn.toLowerCase()) || [], oe.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: Rn,
            type: "GET",
            isLocal: In.test(Ln[1]),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": Yn,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /xml/,
                html: /html/,
                json: /json/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText",
                json: "responseJSON"
            },
            converters: {
                "* text": String,
                "text html": !0,
                "text json": oe.parseJSON,
                "text xml": oe.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function(t, e) {
            return e ? z(z(t, oe.ajaxSettings), e) : z(oe.ajaxSettings, t)
        },
        ajaxPrefilter: H($n),
        ajaxTransport: H(Wn),
        ajax: function(t, e) {
            function n(t, e, n, r) {
                var i, c, v, y, x, w = e;
                2 !== _ && (_ = 2, a && clearTimeout(a), u = void 0, s = r || "", b.readyState = t > 0 ? 4 : 0, i = t >= 200 && 300 > t || 304 === t, n && (y = X(f, b, n)), y = B(f, y, b, i), i ? (f.ifModified && (x = b.getResponseHeader("Last-Modified"), x && (oe.lastModified[o] = x), x = b.getResponseHeader("etag"), x && (oe.etag[o] = x)), 204 === t || "HEAD" === f.type ? w = "nocontent" : 304 === t ? w = "notmodified" : (w = y.state, c = y.data, v = y.error, i = !v)) : (v = w, (t || !w) && (w = "error", 0 > t && (t = 0))), b.status = t, b.statusText = (e || w) + "", i ? d.resolveWith(p, [c, w, b]) : d.rejectWith(p, [b, w, v]), b.statusCode(g), g = void 0, l && h.trigger(i ? "ajaxSuccess" : "ajaxError", [b, f, i ? c : v]), m.fireWith(p, [b, w]), l && (h.trigger("ajaxComplete", [b, f]), --oe.active || oe.event.trigger("ajaxStop")))
            }
            "object" == typeof t && (e = t, t = void 0), e = e || {};
            var r, i, o, s, a, l, u, c, f = oe.ajaxSetup({}, e),
                p = f.context || f,
                h = f.context && (p.nodeType || p.jquery) ? oe(p) : oe.event,
                d = oe.Deferred(),
                m = oe.Callbacks("once memory"),
                g = f.statusCode || {},
                v = {},
                y = {},
                _ = 0,
                x = "canceled",
                b = {
                    readyState: 0,
                    getResponseHeader: function(t) {
                        var e;
                        if (2 === _) {
                            if (!c)
                                for (c = {}; e = Hn.exec(s);) c[e[1].toLowerCase()] = e[2];
                            e = c[t.toLowerCase()]
                        }
                        return null == e ? null : e
                    },
                    getAllResponseHeaders: function() {
                        return 2 === _ ? s : null
                    },
                    setRequestHeader: function(t, e) {
                        var n = t.toLowerCase();
                        return _ || (t = y[n] = y[n] || t, v[t] = e), this
                    },
                    overrideMimeType: function(t) {
                        return _ || (f.mimeType = t), this
                    },
                    statusCode: function(t) {
                        var e;
                        if (t)
                            if (2 > _)
                                for (e in t) g[e] = [g[e], t[e]];
                            else b.always(t[b.status]);
                        return this
                    },
                    abort: function(t) {
                        var e = t || x;
                        return u && u.abort(e), n(0, e), this
                    }
                };
            if (d.promise(b).complete = m.add, b.success = b.done, b.error = b.fail, f.url = ((t || f.url || Rn) + "").replace(Fn, "").replace(Xn, Ln[1] + "//"), f.type = e.method || e.type || f.method || f.type, f.dataTypes = oe.trim(f.dataType || "*").toLowerCase().match(xe) || [""], null == f.crossDomain && (r = Bn.exec(f.url.toLowerCase()), f.crossDomain = !(!r || r[1] === Ln[1] && r[2] === Ln[2] && (r[3] || ("http:" === r[1] ? "80" : "443")) === (Ln[3] || ("http:" === Ln[1] ? "80" : "443")))), f.data && f.processData && "string" != typeof f.data && (f.data = oe.param(f.data, f.traditional)), I($n, f, e, b), 2 === _) return b;
            l = f.global, l && 0 === oe.active++ && oe.event.trigger("ajaxStart"), f.type = f.type.toUpperCase(), f.hasContent = !zn.test(f.type), o = f.url, f.hasContent || (f.data && (o = f.url += (Dn.test(o) ? "&" : "?") + f.data, delete f.data), f.cache === !1 && (f.url = qn.test(o) ? o.replace(qn, "$1_=" + jn++) : o + (Dn.test(o) ? "&" : "?") + "_=" + jn++)), f.ifModified && (oe.lastModified[o] && b.setRequestHeader("If-Modified-Since", oe.lastModified[o]), oe.etag[o] && b.setRequestHeader("If-None-Match", oe.etag[o])), (f.data && f.hasContent && f.contentType !== !1 || e.contentType) && b.setRequestHeader("Content-Type", f.contentType), b.setRequestHeader("Accept", f.dataTypes[0] && f.accepts[f.dataTypes[0]] ? f.accepts[f.dataTypes[0]] + ("*" !== f.dataTypes[0] ? ", " + Yn + "; q=0.01" : "") : f.accepts["*"]);
            for (i in f.headers) b.setRequestHeader(i, f.headers[i]);
            if (f.beforeSend && (f.beforeSend.call(p, b, f) === !1 || 2 === _)) return b.abort();
            x = "abort";
            for (i in {
                    success: 1,
                    error: 1,
                    complete: 1
                }) b[i](f[i]);
            if (u = I(Wn, f, e, b)) {
                b.readyState = 1, l && h.trigger("ajaxSend", [b, f]), f.async && f.timeout > 0 && (a = setTimeout(function() {
                    b.abort("timeout")
                }, f.timeout));
                try {
                    _ = 1, u.send(v, n)
                } catch (w) {
                    if (!(2 > _)) throw w;
                    n(-1, w)
                }
            } else n(-1, "No Transport");
            return b
        },
        getJSON: function(t, e, n) {
            return oe.get(t, e, n, "json")
        },
        getScript: function(t, e) {
            return oe.get(t, void 0, e, "script")
        }
    }), oe.each(["get", "post"], function(t, e) {
        oe[e] = function(t, n, r, i) {
            return oe.isFunction(n) && (i = i || r, r = n, n = void 0), oe.ajax({
                url: t,
                type: e,
                dataType: i,
                data: n,
                success: r
            })
        }
    }), oe.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function(t, e) {
        oe.fn[e] = function(t) {
            return this.on(e, t)
        }
    }), oe._evalUrl = function(t) {
        return oe.ajax({
            url: t,
            type: "GET",
            dataType: "script",
            async: !1,
            global: !1,
            "throws": !0
        })
    }, oe.fn.extend({
        wrapAll: function(t) {
            if (oe.isFunction(t)) return this.each(function(e) {
                oe(this).wrapAll(t.call(this, e))
            });
            if (this[0]) {
                var e = oe(t, this[0].ownerDocument).eq(0).clone(!0);
                this[0].parentNode && e.insertBefore(this[0]), e.map(function() {
                    for (var t = this; t.firstChild && 1 === t.firstChild.nodeType;) t = t.firstChild;
                    return t
                }).append(this)
            }
            return this
        },
        wrapInner: function(t) {
            return this.each(oe.isFunction(t) ? function(e) {
                oe(this).wrapInner(t.call(this, e))
            } : function() {
                var e = oe(this),
                    n = e.contents();
                n.length ? n.wrapAll(t) : e.append(t)
            })
        },
        wrap: function(t) {
            var e = oe.isFunction(t);
            return this.each(function(n) {
                oe(this).wrapAll(e ? t.call(this, n) : t)
            })
        },
        unwrap: function() {
            return this.parent().each(function() {
                oe.nodeName(this, "body") || oe(this).replaceWith(this.childNodes)
            }).end()
        }
    }), oe.expr.filters.hidden = function(t) {
        return t.offsetWidth <= 0 && t.offsetHeight <= 0 || !re.reliableHiddenOffsets() && "none" === (t.style && t.style.display || oe.css(t, "display"))
    }, oe.expr.filters.visible = function(t) {
        return !oe.expr.filters.hidden(t)
    };
    var Vn = /%20/g,
        Qn = /\[\]$/,
        Gn = /\r?\n/g,
        Zn = /^(?:submit|button|image|reset|file)$/i,
        Kn = /^(?:input|select|textarea|keygen)/i;
    oe.param = function(t, e) {
        var n, r = [],
            i = function(t, e) {
                e = oe.isFunction(e) ? e() : null == e ? "" : e, r[r.length] = encodeURIComponent(t) + "=" + encodeURIComponent(e)
            };
        if (void 0 === e && (e = oe.ajaxSettings && oe.ajaxSettings.traditional), oe.isArray(t) || t.jquery && !oe.isPlainObject(t)) oe.each(t, function() {
            i(this.name, this.value)
        });
        else
            for (n in t) $(n, t[n], e, i);
        return r.join("&").replace(Vn, "+")
    }, oe.fn.extend({
        serialize: function() {
            return oe.param(this.serializeArray())
        },
        serializeArray: function() {
            return this.map(function() {
                var t = oe.prop(this, "elements");
                return t ? oe.makeArray(t) : this
            }).filter(function() {
                var t = this.type;
                return this.name && !oe(this).is(":disabled") && Kn.test(this.nodeName) && !Zn.test(t) && (this.checked || !Oe.test(t))
            }).map(function(t, e) {
                var n = oe(this).val();
                return null == n ? null : oe.isArray(n) ? oe.map(n, function(t) {
                    return {
                        name: e.name,
                        value: t.replace(Gn, "\r\n")
                    }
                }) : {
                    name: e.name,
                    value: n.replace(Gn, "\r\n")
                }
            }).get()
        }
    }), oe.ajaxSettings.xhr = void 0 !== t.ActiveXObject ? function() {
        return !this.isLocal && /^(get|post|head|put|delete|options)$/i.test(this.type) && W() || Y()
    } : W;
    var Jn = 0,
        tr = {},
        er = oe.ajaxSettings.xhr();
    t.ActiveXObject && oe(t).on("unload", function() {
        for (var t in tr) tr[t](void 0, !0)
    }), re.cors = !!er && "withCredentials" in er, er = re.ajax = !!er, er && oe.ajaxTransport(function(t) {
        if (!t.crossDomain || re.cors) {
            var e;
            return {
                send: function(n, r) {
                    var i, o = t.xhr(),
                        s = ++Jn;
                    if (o.open(t.type, t.url, t.async, t.username, t.password), t.xhrFields)
                        for (i in t.xhrFields) o[i] = t.xhrFields[i];
                    t.mimeType && o.overrideMimeType && o.overrideMimeType(t.mimeType), t.crossDomain || n["X-Requested-With"] || (n["X-Requested-With"] = "XMLHttpRequest");
                    for (i in n) void 0 !== n[i] && o.setRequestHeader(i, n[i] + "");
                    o.send(t.hasContent && t.data || null), e = function(n, i) {
                        var a, l, u;
                        if (e && (i || 4 === o.readyState))
                            if (delete tr[s], e = void 0, o.onreadystatechange = oe.noop, i) 4 !== o.readyState && o.abort();
                            else {
                                u = {}, a = o.status, "string" == typeof o.responseText && (u.text = o.responseText);
                                try {
                                    l = o.statusText
                                } catch (c) {
                                    l = ""
                                }
                                a || !t.isLocal || t.crossDomain ? 1223 === a && (a = 204) : a = u.text ? 200 : 404
                            }
                        u && r(a, l, u, o.getAllResponseHeaders())
                    }, t.async ? 4 === o.readyState ? setTimeout(e) : o.onreadystatechange = tr[s] = e : e()
                },
                abort: function() {
                    e && e(void 0, !0)
                }
            }
        }
    }), oe.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /(?:java|ecma)script/
        },
        converters: {
            "text script": function(t) {
                return oe.globalEval(t), t
            }
        }
    }), oe.ajaxPrefilter("script", function(t) {
        void 0 === t.cache && (t.cache = !1), t.crossDomain && (t.type = "GET", t.global = !1)
    }), oe.ajaxTransport("script", function(t) {
        if (t.crossDomain) {
            var e, n = me.head || oe("head")[0] || me.documentElement;
            return {
                send: function(r, i) {
                    e = me.createElement("script"), e.async = !0, t.scriptCharset && (e.charset = t.scriptCharset), e.src = t.url, e.onload = e.onreadystatechange = function(t, n) {
                        (n || !e.readyState || /loaded|complete/.test(e.readyState)) && (e.onload = e.onreadystatechange = null, e.parentNode && e.parentNode.removeChild(e), e = null, n || i(200, "success"))
                    }, n.insertBefore(e, n.firstChild)
                },
                abort: function() {
                    e && e.onload(void 0, !0)
                }
            }
        }
    });
    var nr = [],
        rr = /(=)\?(?=&|$)|\?\?/;
    oe.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function() {
            var t = nr.pop() || oe.expando + "_" + jn++;
            return this[t] = !0, t
        }
    }), oe.ajaxPrefilter("json jsonp", function(e, n, r) {
        var i, o, s, a = e.jsonp !== !1 && (rr.test(e.url) ? "url" : "string" == typeof e.data && !(e.contentType || "").indexOf("application/x-www-form-urlencoded") && rr.test(e.data) && "data");
        return a || "jsonp" === e.dataTypes[0] ? (i = e.jsonpCallback = oe.isFunction(e.jsonpCallback) ? e.jsonpCallback() : e.jsonpCallback, a ? e[a] = e[a].replace(rr, "$1" + i) : e.jsonp !== !1 && (e.url += (Dn.test(e.url) ? "&" : "?") + e.jsonp + "=" + i), e.converters["script json"] = function() {
            return s || oe.error(i + " was not called"), s[0]
        }, e.dataTypes[0] = "json", o = t[i], t[i] = function() {
            s = arguments
        }, r.always(function() {
            t[i] = o, e[i] && (e.jsonpCallback = n.jsonpCallback, nr.push(i)), s && oe.isFunction(o) && o(s[0]), s = o = void 0
        }), "script") : void 0
    }), oe.parseHTML = function(t, e, n) {
        if (!t || "string" != typeof t) return null;
        "boolean" == typeof e && (n = e, e = !1), e = e || me;
        var r = pe.exec(t),
            i = !n && [];
        return r ? [e.createElement(r[1])] : (r = oe.buildFragment([t], e, i), i && i.length && oe(i).remove(), oe.merge([], r.childNodes))
    };
    var ir = oe.fn.load;
    oe.fn.load = function(t, e, n) {
        if ("string" != typeof t && ir) return ir.apply(this, arguments);
        var r, i, o, s = this,
            a = t.indexOf(" ");
        return a >= 0 && (r = t.slice(a, t.length), t = t.slice(0, a)), oe.isFunction(e) ? (n = e, e = void 0) : e && "object" == typeof e && (o = "POST"), s.length > 0 && oe.ajax({
            url: t,
            type: o,
            dataType: "html",
            data: e
        }).done(function(t) {
            i = arguments, s.html(r ? oe("<div>").append(oe.parseHTML(t)).find(r) : t)
        }).complete(n && function(t, e) {
            s.each(n, i || [t.responseText, e, t])
        }), this
    }, oe.expr.filters.animated = function(t) {
        return oe.grep(oe.timers, function(e) {
            return t === e.elem
        }).length
    };
    var or = t.document.documentElement;
    oe.offset = {
        setOffset: function(t, e, n) {
            var r, i, o, s, a, l, u, c = oe.css(t, "position"),
                f = oe(t),
                p = {};
            "static" === c && (t.style.position = "relative"), a = f.offset(), o = oe.css(t, "top"), l = oe.css(t, "left"), u = ("absolute" === c || "fixed" === c) && oe.inArray("auto", [o, l]) > -1, u ? (r = f.position(), s = r.top, i = r.left) : (s = parseFloat(o) || 0, i = parseFloat(l) || 0), oe.isFunction(e) && (e = e.call(t, n, a)), null != e.top && (p.top = e.top - a.top + s), null != e.left && (p.left = e.left - a.left + i), "using" in e ? e.using.call(t, p) : f.css(p)
        }
    }, oe.fn.extend({
        offset: function(t) {
            if (arguments.length) return void 0 === t ? this : this.each(function(e) {
                oe.offset.setOffset(this, t, e)
            });
            var e, n, r = {
                    top: 0,
                    left: 0
                },
                i = this[0],
                o = i && i.ownerDocument;
            if (o) return e = o.documentElement, oe.contains(e, i) ? (typeof i.getBoundingClientRect !== ke && (r = i.getBoundingClientRect()), n = U(o), {
                top: r.top + (n.pageYOffset || e.scrollTop) - (e.clientTop || 0),
                left: r.left + (n.pageXOffset || e.scrollLeft) - (e.clientLeft || 0)
            }) : r
        },
        position: function() {
            if (this[0]) {
                var t, e, n = {
                        top: 0,
                        left: 0
                    },
                    r = this[0];
                return "fixed" === oe.css(r, "position") ? e = r.getBoundingClientRect() : (t = this.offsetParent(), e = this.offset(), oe.nodeName(t[0], "html") || (n = t.offset()), n.top += oe.css(t[0], "borderTopWidth", !0), n.left += oe.css(t[0], "borderLeftWidth", !0)), {
                    top: e.top - n.top - oe.css(r, "marginTop", !0),
                    left: e.left - n.left - oe.css(r, "marginLeft", !0)
                }
            }
        },
        offsetParent: function() {
            return this.map(function() {
                for (var t = this.offsetParent || or; t && !oe.nodeName(t, "html") && "static" === oe.css(t, "position");) t = t.offsetParent;
                return t || or
            })
        }
    }), oe.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    }, function(t, e) {
        var n = /Y/.test(e);
        oe.fn[t] = function(r) {
            return Ne(this, function(t, r, i) {
                var o = U(t);
                return void 0 === i ? o ? e in o ? o[e] : o.document.documentElement[r] : t[r] : void(o ? o.scrollTo(n ? oe(o).scrollLeft() : i, n ? i : oe(o).scrollTop()) : t[r] = i)
            }, t, r, arguments.length, null)
        }
    }), oe.each(["top", "left"], function(t, e) {
        oe.cssHooks[e] = C(re.pixelPosition, function(t, n) {
            return n ? (n = nn(t, e), on.test(n) ? oe(t).position()[e] + "px" : n) : void 0
        })
    }), oe.each({
        Height: "height",
        Width: "width"
    }, function(t, e) {
        oe.each({
            padding: "inner" + t,
            content: e,
            "": "outer" + t
        }, function(n, r) {
            oe.fn[r] = function(r, i) {
                var o = arguments.length && (n || "boolean" != typeof r),
                    s = n || (r === !0 || i === !0 ? "margin" : "border");
                return Ne(this, function(e, n, r) {
                    var i;
                    return oe.isWindow(e) ? e.document.documentElement["client" + t] : 9 === e.nodeType ? (i = e.documentElement, Math.max(e.body["scroll" + t], i["scroll" + t], e.body["offset" + t], i["offset" + t], i["client" + t])) : void 0 === r ? oe.css(e, n, s) : oe.style(e, n, r, s)
                }, e, o ? r : void 0, o, null)
            }
        })
    }), oe.fn.size = function() {
        return this.length
    }, oe.fn.andSelf = oe.fn.addBack, "function" == typeof define && define.amd && define("jquery", [], function() {
        return oe
    });
    var sr = t.jQuery,
        ar = t.$;
    return oe.noConflict = function(e) {
        return t.$ === oe && (t.$ = ar), e && t.jQuery === oe && (t.jQuery = sr), oe
    }, typeof e === ke && (t.jQuery = t.$ = oe), oe
}),
function(t, e) {
    t.rails !== e && t.error("jquery-ujs has already been loaded!");
    var n, r = t(document);
    t.rails = n = {
        linkClickSelector: "a[data-confirm], a[data-method], a[data-remote], a[data-disable-with]",
        buttonClickSelector: "button[data-remote]",
        inputChangeSelector: "select[data-remote], input[data-remote], textarea[data-remote]",
        formSubmitSelector: "form",
        formInputClickSelector: "form input[type=submit], form input[type=image], form button[type=submit], form button:not([type])",
        disableSelector: "input[data-disable-with], button[data-disable-with], textarea[data-disable-with]",
        enableSelector: "input[data-disable-with]:disabled, button[data-disable-with]:disabled, textarea[data-disable-with]:disabled",
        requiredInputSelector: "input[name][required]:not([disabled]),textarea[name][required]:not([disabled])",
        fileInputSelector: "input[type=file]",
        linkDisableSelector: "a[data-disable-with]",
        CSRFProtection: function(e) {
            var n = t('meta[name="csrf-token"]').attr("content");
            n && e.setRequestHeader("X-CSRF-Token", n)
        },
        refreshCSRFTokens: function() {
            var e = t("meta[name=csrf-token]").attr("content"),
                n = t("meta[name=csrf-param]").attr("content");
            t('form input[name="' + n + '"]').val(e)
        },
        fire: function(e, n, r) {
            var i = t.Event(n);
            return e.trigger(i, r), i.result !== !1
        },
        confirm: function(t) {
            return confirm(t)
        },
        ajax: function(e) {
            return t.ajax(e)
        },
        href: function(t) {
            return t.attr("href")
        },
        handleRemote: function(r) {
            var i, o, s, a, l, u, c, f;
            if (n.fire(r, "ajax:before")) {
                if (a = r.data("cross-domain"), l = a === e ? null : a, u = r.data("with-credentials") || null, c = r.data("type") || t.ajaxSettings && t.ajaxSettings.dataType, r.is("form")) {
                    i = r.attr("method"), o = r.attr("action"), s = r.serializeArray();
                    var p = r.data("ujs:submit-button");
                    p && (s.push(p), r.data("ujs:submit-button", null))
                } else r.is(n.inputChangeSelector) ? (i = r.data("method"), o = r.data("url"), s = r.serialize(), r.data("params") && (s = s + "&" + r.data("params"))) : r.is(n.buttonClickSelector) ? (i = r.data("method") || "get", o = r.data("url"), s = r.serialize(), r.data("params") && (s = s + "&" + r.data("params"))) : (i = r.data("method"), o = n.href(r), s = r.data("params") || null);
                f = {
                    type: i || "GET",
                    data: s,
                    dataType: c,
                    beforeSend: function(t, i) {
                        return i.dataType === e && t.setRequestHeader("accept", "*/*;q=0.5, " + i.accepts.script), n.fire(r, "ajax:beforeSend", [t, i])
                    },
                    success: function(t, e, n) {
                        r.trigger("ajax:success", [t, e, n])
                    },
                    complete: function(t, e) {
                        r.trigger("ajax:complete", [t, e])
                    },
                    error: function(t, e, n) {
                        r.trigger("ajax:error", [t, e, n])
                    },
                    crossDomain: l
                }, u && (f.xhrFields = {
                    withCredentials: u
                }), o && (f.url = o);
                var h = n.ajax(f);
                return r.trigger("ajax:send", h), h
            }
            return !1
        },
        handleMethod: function(r) {
            var i = n.href(r),
                o = r.data("method"),
                s = r.attr("target"),
                a = t("meta[name=csrf-token]").attr("content"),
                l = t("meta[name=csrf-param]").attr("content"),
                u = t('<form method="post" action="' + i + '"></form>'),
                c = '<input name="_method" value="' + o + '" type="hidden" />';
            l !== e && a !== e && (c += '<input name="' + l + '" value="' + a + '" type="hidden" />'), s && u.attr("target", s), u.hide().append(c).appendTo("body"), u.submit()
        },
        disableFormElements: function(e) {
            e.find(n.disableSelector).each(function() {
                var e = t(this),
                    n = e.is("button") ? "html" : "val";
                e.data("ujs:enable-with", e[n]()), e[n](e.data("disable-with")), e.prop("disabled", !0)
            })
        },
        enableFormElements: function(e) {
            e.find(n.enableSelector).each(function() {
                var e = t(this),
                    n = e.is("button") ? "html" : "val";
                e.data("ujs:enable-with") && e[n](e.data("ujs:enable-with")), e.prop("disabled", !1)
            })
        },
        allowAction: function(t) {
            var e, r = t.data("confirm"),
                i = !1;
            return r ? (n.fire(t, "confirm") && (i = n.confirm(r), e = n.fire(t, "confirm:complete", [i])), i && e) : !0
        },
        blankInputs: function(e, n, r) {
            var i, o, s = t(),
                a = n || "input,textarea",
                l = e.find(a);
            return l.each(function() {
                if (i = t(this), o = i.is("input[type=checkbox],input[type=radio]") ? i.is(":checked") : i.val(), !o == !r) {
                    if (i.is("input[type=radio]") && l.filter('input[type=radio]:checked[name="' + i.attr("name") + '"]').length) return !0;
                    s = s.add(i)
                }
            }), s.length ? s : !1
        },
        nonBlankInputs: function(t, e) {
            return n.blankInputs(t, e, !0)
        },
        stopEverything: function(e) {
            return t(e.target).trigger("ujs:everythingStopped"), e.stopImmediatePropagation(), !1
        },
        disableElement: function(t) {
            t.data("ujs:enable-with", t.html()), t.html(t.data("disable-with")), t.bind("click.railsDisable", function(t) {
                return n.stopEverything(t)
            })
        },
        enableElement: function(t) {
            t.data("ujs:enable-with") !== e && (t.html(t.data("ujs:enable-with")), t.removeData("ujs:enable-with")), t.unbind("click.railsDisable")
        }
    }, n.fire(r, "rails:attachBindings") && (t.ajaxPrefilter(function(t, e, r) {
        t.crossDomain || n.CSRFProtection(r)
    }), r.delegate(n.linkDisableSelector, "ajax:complete", function() {
        n.enableElement(t(this))
    }), r.delegate(n.linkClickSelector, "click.rails", function(r) {
        var i = t(this),
            o = i.data("method"),
            s = i.data("params"),
            a = r.metaKey || r.ctrlKey;
        if (!n.allowAction(i)) return n.stopEverything(r);
        if (!a && i.is(n.linkDisableSelector) && n.disableElement(i), i.data("remote") !== e) {
            if (a && (!o || "GET" === o) && !s) return !0;
            var l = n.handleRemote(i);
            return l === !1 ? n.enableElement(i) : l.error(function() {
                n.enableElement(i)
            }), !1
        }
        return i.data("method") ? (n.handleMethod(i), !1) : void 0
    }), r.delegate(n.buttonClickSelector, "click.rails", function(e) {
        var r = t(this);
        return n.allowAction(r) ? (n.handleRemote(r), !1) : n.stopEverything(e)
    }), r.delegate(n.inputChangeSelector, "change.rails", function(e) {
        var r = t(this);
        return n.allowAction(r) ? (n.handleRemote(r), !1) : n.stopEverything(e)
    }), r.delegate(n.formSubmitSelector, "submit.rails", function(r) {
        var i = t(this),
            o = i.data("remote") !== e,
            s = n.blankInputs(i, n.requiredInputSelector),
            a = n.nonBlankInputs(i, n.fileInputSelector);
        if (!n.allowAction(i)) return n.stopEverything(r);
        if (s && i.attr("novalidate") == e && n.fire(i, "ajax:aborted:required", [s])) return n.stopEverything(r);
        if (o) {
            if (a) {
                setTimeout(function() {
                    n.disableFormElements(i)
                }, 13);
                var l = n.fire(i, "ajax:aborted:file", [a]);
                return l || setTimeout(function() {
                    n.enableFormElements(i)
                }, 13), l
            }
            return n.handleRemote(i), !1
        }
        setTimeout(function() {
            n.disableFormElements(i)
        }, 13)
    }), r.delegate(n.formInputClickSelector, "click.rails", function(e) {
        var r = t(this);
        if (!n.allowAction(r)) return n.stopEverything(e);
        var i = r.attr("name"),
            o = i ? {
                name: i,
                value: r.val()
            } : null;
        r.closest("form").data("ujs:submit-button", o)
    }), r.delegate(n.formSubmitSelector, "ajax:beforeSend.rails", function(e) {
        this == e.target && n.disableFormElements(t(this))
    }), r.delegate(n.formSubmitSelector, "ajax:complete.rails", function(e) {
        this == e.target && n.enableFormElements(t(this))
    }), t(function() {
        n.refreshCSRFTokens()
    }))
}(jQuery),
function() {
    var t, e = [].slice;
    t = "undefined" != typeof exports && null !== exports ? exports : this, t.on_page_load = function(t) {
        return $(function() {
            return t()
        }), $(document).on("page:load", t)
    }, t.debounce = function(t, n, r) {
        var i;
        return i = null,
            function() {
                var o, s, a;
                return o = 1 <= arguments.length ? e.call(arguments, 0) : [], a = this, s = function() {
                    return r || t.apply(a, o), i = null
                }, i ? clearTimeout(i) : r && t.apply(a, o), i = setTimeout(s, n || 100)
            }
    }, t.once = function(t) {
        return function(e) {
            return function() {
                return e ? void 0 : (e = !0, t.apply(this, arguments))
            }
        }(!1)
    }, $.fn.maxHeight = function() {
        return Math.max.apply(this, $.map(this, function(t) {
            return $(t).height()
        }))
    }
}.call(this),
    function() {
        var t, e, n, r, i, o, s, a, l, u, c, f, p, h, d, m, g, v, y, _, x, b, w, T, k, S, C, P, E, A, N, O, j, D, M, L, R, F, q, H, I, z, X, B, $, W, Y, U, V = [].slice,
            Q = {}.hasOwnProperty,
            G = function(t, e) {
                function n() {
                    this.constructor = t
                }
                for (var r in e) Q.call(e, r) && (t[r] = e[r]);
                return n.prototype = e.prototype, t.prototype = new n, t.__super__ = e.prototype, t
            },
            Z = [].indexOf || function(t) {
                for (var e = 0, n = this.length; n > e; e++)
                    if (e in this && this[e] === t) return e;
                return -1
            };
        for (_ = {
                catchupTime: 500,
                initialRate: .03,
                minTime: 500,
                ghostTime: 500,
                maxProgressPerFrame: 10,
                easeFactor: 1.25,
                startOnPageLoad: !0,
                restartOnPushState: !0,
                restartOnRequestAfter: 500,
                target: "body",
                elements: {
                    checkInterval: 100,
                    selectors: ["body"]
                },
                eventLag: {
                    minSamples: 10,
                    sampleCount: 3,
                    lagThreshold: 3
                },
                ajax: {
                    trackMethods: ["GET"],
                    trackWebSockets: !0,
                    ignoreURLs: []
                }
            }, P = function() {
                var t;
                return null != (t = "undefined" != typeof performance && null !== performance && "function" == typeof performance.now ? performance.now() : void 0) ? t : +new Date
            }, A = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || window.msRequestAnimationFrame, y = window.cancelAnimationFrame || window.mozCancelAnimationFrame, null == A && (A = function(t) {
                return setTimeout(t, 50)
            }, y = function(t) {
                return clearTimeout(t)
            }), O = function(t) {
                var e, n;
                return e = P(), (n = function() {
                    var r;
                    return r = P() - e, r >= 33 ? (e = P(), t(r, function() {
                        return A(n)
                    })) : setTimeout(n, 33 - r)
                })()
            }, N = function() {
                var t, e, n;
                return n = arguments[0], e = arguments[1], t = 3 <= arguments.length ? V.call(arguments, 2) : [], "function" == typeof n[e] ? n[e].apply(n, t) : n[e]
            }, x = function() {
                var t, e, n, r, i, o, s;
                for (e = arguments[0], r = 2 <= arguments.length ? V.call(arguments, 1) : [], o = 0, s = r.length; s > o; o++)
                    if (n = r[o])
                        for (t in n) Q.call(n, t) && (i = n[t], null != e[t] && "object" == typeof e[t] && null != i && "object" == typeof i ? x(e[t], i) : e[t] = i);
                return e
            }, m = function(t) {
                var e, n, r, i, o;
                for (n = e = 0, i = 0, o = t.length; o > i; i++) r = t[i], n += Math.abs(r), e++;
                return n / e
            }, w = function(t, e) {
                var n, r, i;
                if (null == t && (t = "options"), null == e && (e = !0), i = document.querySelector("[data-pace-" + t + "]")) {
                    if (n = i.getAttribute("data-pace-" + t), !e) return n;
                    try {
                        return JSON.parse(n)
                    } catch (o) {
                        return r = o, "undefined" != typeof console && null !== console ? void 0 : void 0
                    }
                }
            }, s = function() {
                function t() {}
                return t.prototype.on = function(t, e, n, r) {
                    var i;
                    return null == r && (r = !1), null == this.bindings && (this.bindings = {}), null == (i = this.bindings)[t] && (i[t] = []), this.bindings[t].push({
                        handler: e,
                        ctx: n,
                        once: r
                    })
                }, t.prototype.once = function(t, e, n) {
                    return this.on(t, e, n, !0)
                }, t.prototype.off = function(t, e) {
                    var n, r, i;
                    if (null != (null != (r = this.bindings) ? r[t] : void 0)) {
                        if (null == e) return delete this.bindings[t];
                        for (n = 0, i = []; n < this.bindings[t].length;) i.push(this.bindings[t][n].handler === e ? this.bindings[t].splice(n, 1) : n++);
                        return i
                    }
                }, t.prototype.trigger = function() {
                    var t, e, n, r, i, o, s, a, l;
                    if (n = arguments[0], t = 2 <= arguments.length ? V.call(arguments, 1) : [], null != (s = this.bindings) ? s[n] : void 0) {
                        for (i = 0, l = []; i < this.bindings[n].length;) a = this.bindings[n][i], r = a.handler, e = a.ctx, o = a.once, r.apply(null != e ? e : this, t), l.push(o ? this.bindings[n].splice(i, 1) : i++);
                        return l
                    }
                }, t
            }(), null == window.Pace && (window.Pace = {}), x(Pace, s.prototype), E = Pace.options = x({}, _, window.paceOptions, w()), W = ["ajax", "document", "eventLag", "elements"], z = 0, B = W.length; B > z; z++) L = W[z], E[L] === !0 && (E[L] = _[L]);
        l = function(t) {
            function e() {
                return Y = e.__super__.constructor.apply(this, arguments)
            }
            return G(e, t), e
        }(Error), e = function() {
            function t() {
                this.progress = 0
            }
            return t.prototype.getElement = function() {
                var t;
                if (null == this.el) {
                    if (t = document.querySelector(E.target), !t) throw new l;
                    this.el = document.createElement("div"), this.el.className = "pace pace-active", document.body.className = document.body.className.replace(/pace-done/g, ""), document.body.className += " pace-running", this.el.innerHTML = '<div class="pace-progress">\n  <div class="pace-progress-inner"></div>\n</div>\n<div class="pace-activity"></div>', null != t.firstChild ? t.insertBefore(this.el, t.firstChild) : t.appendChild(this.el)
                }
                return this.el
            }, t.prototype.finish = function() {
                var t;
                return t = this.getElement(), t.className = t.className.replace("pace-active", ""), t.className += " pace-inactive", document.body.className = document.body.className.replace("pace-running", ""), document.body.className += " pace-done"
            }, t.prototype.update = function(t) {
                return this.progress = t, this.render()
            }, t.prototype.destroy = function() {
                try {
                    this.getElement().parentNode.removeChild(this.getElement())
                } catch (t) {
                    l = t
                }
                return this.el = void 0
            }, t.prototype.render = function() {
                var t, e;
                return null == document.querySelector(E.target) ? !1 : (t = this.getElement(), t.children[0].style.width = "" + this.progress + "%", (!this.lastRenderedProgress || this.lastRenderedProgress | 0 !== this.progress | 0) && (t.children[0].setAttribute("data-progress-text", "" + (0 | this.progress) + "%"), this.progress >= 100 ? e = "99" : (e = this.progress < 10 ? "0" : "", e += 0 | this.progress), t.children[0].setAttribute("data-progress", "" + e)), this.lastRenderedProgress = this.progress)
            }, t.prototype.done = function() {
                return this.progress >= 100
            }, t
        }(), a = function() {
            function t() {
                this.bindings = {}
            }
            return t.prototype.trigger = function(t, e) {
                var n, r, i, o, s;
                if (null != this.bindings[t]) {
                    for (o = this.bindings[t], s = [], r = 0, i = o.length; i > r; r++) n = o[r], s.push(n.call(this, e));
                    return s
                }
            }, t.prototype.on = function(t, e) {
                var n;
                return null == (n = this.bindings)[t] && (n[t] = []), this.bindings[t].push(e)
            }, t
        }(), I = window.XMLHttpRequest, H = window.XDomainRequest, q = window.WebSocket, b = function(t, e) {
            var n, r, i, o;
            o = [];
            for (r in e.prototype) try {
                i = e.prototype[r], o.push(null == t[r] && "function" != typeof i ? t[r] = i : void 0)
            } catch (s) {
                n = s
            }
            return o
        }, S = [], Pace.ignore = function() {
            var t, e, n;
            return e = arguments[0], t = 2 <= arguments.length ? V.call(arguments, 1) : [], S.unshift("ignore"), n = e.apply(null, t), S.shift(), n
        }, Pace.track = function() {
            var t, e, n;
            return e = arguments[0], t = 2 <= arguments.length ? V.call(arguments, 1) : [], S.unshift("track"), n = e.apply(null, t), S.shift(), n
        }, M = function(t) {
            var e;
            if (null == t && (t = "GET"), "track" === S[0]) return "force";
            if (!S.length && E.ajax) {
                if ("socket" === t && E.ajax.trackWebSockets) return !0;
                if (e = t.toUpperCase(), Z.call(E.ajax.trackMethods, e) >= 0) return !0
            }
            return !1
        }, u = function(t) {
            function e() {
                var t, n = this;
                e.__super__.constructor.apply(this, arguments), t = function(t) {
                    var e;
                    return e = t.open, t.open = function(r, i) {
                        return M(r) && n.trigger("request", {
                            type: r,
                            url: i,
                            request: t
                        }), e.apply(t, arguments)
                    }
                }, window.XMLHttpRequest = function(e) {
                    var n;
                    return n = new I(e), t(n), n
                }, b(window.XMLHttpRequest, I), null != H && (window.XDomainRequest = function() {
                    var e;
                    return e = new H, t(e), e
                }, b(window.XDomainRequest, H)), null != q && E.ajax.trackWebSockets && (window.WebSocket = function(t, e) {
                    var r;
                    return r = null != e ? new q(t, e) : new q(t), M("socket") && n.trigger("request", {
                        type: "socket",
                        url: t,
                        protocols: e,
                        request: r
                    }), r
                }, b(window.WebSocket, q))
            }
            return G(e, t), e
        }(a), X = null, T = function() {
            return null == X && (X = new u), X
        }, D = function(t) {
            var e, n, r, i;
            for (i = E.ajax.ignoreURLs, n = 0, r = i.length; r > n; n++)
                if (e = i[n], "string" == typeof e) {
                    if (-1 !== t.indexOf(e)) return !0
                } else if (e.test(t)) return !0;
            return !1
        }, T().on("request", function(e) {
            var n, r, i, o, s;
            return o = e.type, i = e.request, s = e.url, D(s) ? void 0 : Pace.running || E.restartOnRequestAfter === !1 && "force" !== M(o) ? void 0 : (r = arguments, n = E.restartOnRequestAfter || 0, "boolean" == typeof n && (n = 0), setTimeout(function() {
                var e, n, s, a, l, u;
                if (e = "socket" === o ? i.readyState < 2 : 0 < (a = i.readyState) && 4 > a) {
                    for (Pace.restart(), l = Pace.sources, u = [], n = 0, s = l.length; s > n; n++) {
                        if (L = l[n], L instanceof t) {
                            L.watch.apply(L, r);
                            break
                        }
                        u.push(void 0)
                    }
                    return u
                }
            }, n))
        }), t = function() {
            function t() {
                var t = this;
                this.elements = [], T().on("request", function() {
                    return t.watch.apply(t, arguments)
                })
            }
            return t.prototype.watch = function(t) {
                var e, n, r, i;
                return r = t.type, e = t.request, i = t.url, D(i) ? void 0 : (n = "socket" === r ? new p(e) : new h(e), this.elements.push(n))
            }, t
        }(), h = function() {
            function t(t) {
                var e, n, r, i, o, s, a = this;
                if (this.progress = 0, null != window.ProgressEvent)
                    for (n = null, t.addEventListener("progress", function(t) {
                            return a.progress = t.lengthComputable ? 100 * t.loaded / t.total : a.progress + (100 - a.progress) / 2
                        }), s = ["load", "abort", "timeout", "error"], r = 0, i = s.length; i > r; r++) e = s[r], t.addEventListener(e, function() {
                        return a.progress = 100
                    });
                else o = t.onreadystatechange, t.onreadystatechange = function() {
                    var e;
                    return 0 === (e = t.readyState) || 4 === e ? a.progress = 100 : 3 === t.readyState && (a.progress = 50), "function" == typeof o ? o.apply(null, arguments) : void 0
                }
            }
            return t
        }(), p = function() {
            function t(t) {
                var e, n, r, i, o = this;
                for (this.progress = 0, i = ["error", "open"], n = 0, r = i.length; r > n; n++) e = i[n], t.addEventListener(e, function() {
                    return o.progress = 100
                })
            }
            return t
        }(), r = function() {
            function t(t) {
                var e, n, r, o;
                for (null == t && (t = {}), this.elements = [], null == t.selectors && (t.selectors = []), o = t.selectors, n = 0, r = o.length; r > n; n++) e = o[n], this.elements.push(new i(e))
            }
            return t
        }(), i = function() {
            function t(t) {
                this.selector = t, this.progress = 0, this.check()
            }
            return t.prototype.check = function() {
                var t = this;
                return document.querySelector(this.selector) ? this.done() : setTimeout(function() {
                    return t.check()
                }, E.elements.checkInterval)
            }, t.prototype.done = function() {
                return this.progress = 100
            }, t
        }(), n = function() {
            function t() {
                var t, e, n = this;
                this.progress = null != (e = this.states[document.readyState]) ? e : 100, t = document.onreadystatechange, document.onreadystatechange = function() {
                    return null != n.states[document.readyState] && (n.progress = n.states[document.readyState]), "function" == typeof t ? t.apply(null, arguments) : void 0
                }
            }
            return t.prototype.states = {
                loading: 0,
                interactive: 50,
                complete: 100
            }, t
        }(), o = function() {
            function t() {
                var t, e, n, r, i, o = this;
                this.progress = 0, t = 0, i = [], r = 0, n = P(), e = setInterval(function() {
                    var s;
                    return s = P() - n - 50, n = P(), i.push(s), i.length > E.eventLag.sampleCount && i.shift(), t = m(i), ++r >= E.eventLag.minSamples && t < E.eventLag.lagThreshold ? (o.progress = 100, clearInterval(e)) : o.progress = 100 * (3 / (t + 3))
                }, 50)
            }
            return t
        }(), f = function() {
            function t(t) {
                this.source = t, this.last = this.sinceLastUpdate = 0, this.rate = E.initialRate, this.catchup = 0, this.progress = this.lastProgress = 0, null != this.source && (this.progress = N(this.source, "progress"))
            }
            return t.prototype.tick = function(t, e) {
                var n;
                return null == e && (e = N(this.source, "progress")), e >= 100 && (this.done = !0), e === this.last ? this.sinceLastUpdate += t : (this.sinceLastUpdate && (this.rate = (e - this.last) / this.sinceLastUpdate), this.catchup = (e - this.progress) / E.catchupTime, this.sinceLastUpdate = 0, this.last = e), e > this.progress && (this.progress += this.catchup * t), n = 1 - Math.pow(this.progress / 100, E.easeFactor), this.progress += n * this.rate * t, this.progress = Math.min(this.lastProgress + E.maxProgressPerFrame, this.progress), this.progress = Math.max(0, this.progress), this.progress = Math.min(100, this.progress), this.lastProgress = this.progress, this.progress
            }, t
        }(), R = null, j = null, g = null, F = null, d = null, v = null, Pace.running = !1, k = function() {
            return E.restartOnPushState ? Pace.restart() : void 0
        }, null != window.history.pushState && ($ = window.history.pushState, window.history.pushState = function() {
            return k(), $.apply(window.history, arguments)
        }), null != window.history.replaceState && (U = window.history.replaceState, window.history.replaceState = function() {
            return k(), U.apply(window.history, arguments)
        }), c = {
            ajax: t,
            elements: r,
            document: n,
            eventLag: o
        }, (C = function() {
            var t, n, r, i, o, s, a, l;
            for (Pace.sources = R = [], s = ["ajax", "elements", "document", "eventLag"], n = 0, i = s.length; i > n; n++) t = s[n], E[t] !== !1 && R.push(new c[t](E[t]));
            for (l = null != (a = E.extraSources) ? a : [], r = 0, o = l.length; o > r; r++) L = l[r], R.push(new L(E));
            return Pace.bar = g = new e, j = [], F = new f
        })(), Pace.stop = function() {
            return Pace.trigger("stop"), Pace.running = !1, g.destroy(), v = !0, null != d && ("function" == typeof y && y(d), d = null), C()
        }, Pace.restart = function() {
            return Pace.trigger("restart"), Pace.stop(), Pace.start()
        }, Pace.go = function() {
            var t;
            return Pace.running = !0, g.render(), t = P(), v = !1, d = O(function(e, n) {
                var r, i, o, s, a, l, u, c, p, h, d, m, y, _, x, b;
                for (c = 100 - g.progress, i = d = 0, o = !0, l = m = 0, _ = R.length; _ > m; l = ++m)
                    for (L = R[l], h = null != j[l] ? j[l] : j[l] = [], a = null != (b = L.elements) ? b : [L], u = y = 0, x = a.length; x > y; u = ++y) s = a[u], p = null != h[u] ? h[u] : h[u] = new f(s), o &= p.done, p.done || (i++, d += p.tick(e));
                return r = d / i, g.update(F.tick(e, r)), g.done() || o || v ? (g.update(100), Pace.trigger("done"), setTimeout(function() {
                    return g.finish(), Pace.running = !1, Pace.trigger("hide")
                }, Math.max(E.ghostTime, Math.max(E.minTime - (P() - t), 0)))) : n()
            })
        }, Pace.start = function(t) {
            x(E, t), Pace.running = !0;
            try {
                g.render()
            } catch (e) {
                l = e
            }
            return document.querySelector(".pace") ? (Pace.trigger("start"), Pace.go()) : setTimeout(Pace.start, 50)
        }, "function" == typeof define && define.amd ? define(function() {
            return Pace
        }) : "object" == typeof exports ? module.exports = Pace : E.startOnPageLoad && Pace.start()
    }.call(this),
    function(t, e, n) {
        var r = window.matchMedia;
        "undefined" != typeof module && module.exports ? module.exports = n(r) : "function" == typeof define && define.amd ? define(function() {
            return e[t] = n(r)
        }) : e[t] = n(r)
    }("enquire", this, function(t) {
        "use strict";

        function e(t, e) {
            var n, r = 0,
                i = t.length;
            for (r; i > r && (n = e(t[r], r), n !== !1); r++);
        }

        function n(t) {
            return "[object Array]" === Object.prototype.toString.apply(t)
        }

        function r(t) {
            return "function" == typeof t
        }

        function i(t) {
            this.options = t, !t.deferSetup && this.setup()
        }

        function o(e, n) {
            this.query = e, this.isUnconditional = n, this.handlers = [], this.mql = t(e);
            var r = this;
            this.listener = function(t) {
                r.mql = t, r.assess()
            }, this.mql.addListener(this.listener)
        }

        function s() {
            if (!t) throw new Error("matchMedia not present, legacy browsers require a polyfill");
            this.queries = {}, this.browserIsIncapable = !t("only all").matches
        }
        return i.prototype = {
            setup: function() {
                this.options.setup && this.options.setup(), this.initialised = !0
            },
            on: function() {
                !this.initialised && this.setup(), this.options.match && this.options.match()
            },
            off: function() {
                this.options.unmatch && this.options.unmatch()
            },
            destroy: function() {
                this.options.destroy ? this.options.destroy() : this.off()
            },
            equals: function(t) {
                return this.options === t || this.options.match === t
            }
        }, o.prototype = {
            addHandler: function(t) {
                var e = new i(t);
                this.handlers.push(e), this.matches() && e.on()
            },
            removeHandler: function(t) {
                var n = this.handlers;
                e(n, function(e, r) {
                    return e.equals(t) ? (e.destroy(), !n.splice(r, 1)) : void 0
                })
            },
            matches: function() {
                return this.mql.matches || this.isUnconditional
            },
            clear: function() {
                e(this.handlers, function(t) {
                    t.destroy()
                }), this.mql.removeListener(this.listener), this.handlers.length = 0
            },
            assess: function() {
                var t = this.matches() ? "on" : "off";
                e(this.handlers, function(e) {
                    e[t]()
                })
            }
        }, s.prototype = {
            register: function(t, i, s) {
                var a = this.queries,
                    l = s && this.browserIsIncapable;
                return a[t] || (a[t] = new o(t, l)), r(i) && (i = {
                    match: i
                }), n(i) || (i = [i]), e(i, function(e) {
                    r(e) && (e = {
                        match: e
                    }), a[t].addHandler(e)
                }), this
            },
            unregister: function(t, e) {
                var n = this.queries[t];
                return n && (e ? n.removeHandler(e) : (n.clear(), delete this.queries[t])), this
            }
        }, new s
    });
/*!
 * VERSION: beta 1.9.4
 * DATE: 2014-07-17
 * UPDATES AND DOCS AT: http://greensock.com
 *
 * @license Copyright (c) 2008-2015, GreenSock. All rights reserved.
 * This work is subject to the terms at http://greensock.com/standard-license or for
 * Club GreenSock members, the software agreement that was issued with your membership.
 * 
 * @author: Jack Doyle, jack@greensock.com
 **/
var _gsScope = "undefined" != typeof module && module.exports && "undefined" != typeof global ? global : this || window;
(_gsScope._gsQueue || (_gsScope._gsQueue = [])).push(function() {
    "use strict";
    _gsScope._gsDefine("easing.Back", ["easing.Ease"], function(t) {
        var e, n, r, i = _gsScope.GreenSockGlobals || _gsScope,
            o = i.com.greensock,
            s = 2 * Math.PI,
            a = Math.PI / 2,
            l = o._class,
            u = function(e, n) {
                var r = l("easing." + e, function() {}, !0),
                    i = r.prototype = new t;
                return i.constructor = r, i.getRatio = n, r
            },
            c = t.register || function() {},
            f = function(t, e, n, r) {
                var i = l("easing." + t, {
                    easeOut: new e,
                    easeIn: new n,
                    easeInOut: new r
                }, !0);
                return c(i, t), i
            },
            p = function(t, e, n) {
                this.t = t, this.v = e, n && (this.next = n, n.prev = this, this.c = n.v - e, this.gap = n.t - t)
            },
            h = function(e, n) {
                var r = l("easing." + e, function(t) {
                        this._p1 = t || 0 === t ? t : 1.70158, this._p2 = 1.525 * this._p1
                    }, !0),
                    i = r.prototype = new t;
                return i.constructor = r, i.getRatio = n, i.config = function(t) {
                    return new r(t)
                }, r
            },
            d = f("Back", h("BackOut", function(t) {
                return (t -= 1) * t * ((this._p1 + 1) * t + this._p1) + 1
            }), h("BackIn", function(t) {
                return t * t * ((this._p1 + 1) * t - this._p1)
            }), h("BackInOut", function(t) {
                return (t *= 2) < 1 ? .5 * t * t * ((this._p2 + 1) * t - this._p2) : .5 * ((t -= 2) * t * ((this._p2 + 1) * t + this._p2) + 2)
            })),
            m = l("easing.SlowMo", function(t, e, n) {
                e = e || 0 === e ? e : .7, null == t ? t = .7 : t > 1 && (t = 1), this._p = 1 !== t ? e : 0, this._p1 = (1 - t) / 2, this._p2 = t, this._p3 = this._p1 + this._p2, this._calcEnd = n === !0
            }, !0),
            g = m.prototype = new t;
        return g.constructor = m, g.getRatio = function(t) {
            var e = t + (.5 - t) * this._p;
            return t < this._p1 ? this._calcEnd ? 1 - (t = 1 - t / this._p1) * t : e - (t = 1 - t / this._p1) * t * t * t * e : t > this._p3 ? this._calcEnd ? 1 - (t = (t - this._p3) / this._p1) * t : e + (t - e) * (t = (t - this._p3) / this._p1) * t * t * t : this._calcEnd ? 1 : e
        }, m.ease = new m(.7, .7), g.config = m.config = function(t, e, n) {
            return new m(t, e, n)
        }, e = l("easing.SteppedEase", function(t) {
            t = t || 1, this._p1 = 1 / t, this._p2 = t + 1
        }, !0), g = e.prototype = new t, g.constructor = e, g.getRatio = function(t) {
            return 0 > t ? t = 0 : t >= 1 && (t = .999999999), (this._p2 * t >> 0) * this._p1
        }, g.config = e.config = function(t) {
            return new e(t)
        }, n = l("easing.RoughEase", function(e) {
            e = e || {};
            for (var n, r, i, o, s, a, l = e.taper || "none", u = [], c = 0, f = 0 | (e.points || 20), h = f, d = e.randomize !== !1, m = e.clamp === !0, g = e.template instanceof t ? e.template : null, v = "number" == typeof e.strength ? .4 * e.strength : .4; --h > -1;) n = d ? Math.random() : 1 / f * h, r = g ? g.getRatio(n) : n, "none" === l ? i = v : "out" === l ? (o = 1 - n, i = o * o * v) : "in" === l ? i = n * n * v : .5 > n ? (o = 2 * n, i = o * o * .5 * v) : (o = 2 * (1 - n), i = o * o * .5 * v), d ? r += Math.random() * i - .5 * i : h % 2 ? r += .5 * i : r -= .5 * i, m && (r > 1 ? r = 1 : 0 > r && (r = 0)), u[c++] = {
                x: n,
                y: r
            };
            for (u.sort(function(t, e) {
                    return t.x - e.x
                }), a = new p(1, 1, null), h = f; --h > -1;) s = u[h], a = new p(s.x, s.y, a);
            this._prev = new p(0, 0, 0 !== a.t ? a : a.next)
        }, !0), g = n.prototype = new t, g.constructor = n, g.getRatio = function(t) {
            var e = this._prev;
            if (t > e.t) {
                for (; e.next && t >= e.t;) e = e.next;
                e = e.prev
            } else
                for (; e.prev && t <= e.t;) e = e.prev;
            return this._prev = e, e.v + (t - e.t) / e.gap * e.c
        }, g.config = function(t) {
            return new n(t)
        }, n.ease = new n, f("Bounce", u("BounceOut", function(t) {
            return 1 / 2.75 > t ? 7.5625 * t * t : 2 / 2.75 > t ? 7.5625 * (t -= 1.5 / 2.75) * t + .75 : 2.5 / 2.75 > t ? 7.5625 * (t -= 2.25 / 2.75) * t + .9375 : 7.5625 * (t -= 2.625 / 2.75) * t + .984375
        }), u("BounceIn", function(t) {
            return (t = 1 - t) < 1 / 2.75 ? 1 - 7.5625 * t * t : 2 / 2.75 > t ? 1 - (7.5625 * (t -= 1.5 / 2.75) * t + .75) : 2.5 / 2.75 > t ? 1 - (7.5625 * (t -= 2.25 / 2.75) * t + .9375) : 1 - (7.5625 * (t -= 2.625 / 2.75) * t + .984375)
        }), u("BounceInOut", function(t) {
            var e = .5 > t;
            return t = e ? 1 - 2 * t : 2 * t - 1, t = 1 / 2.75 > t ? 7.5625 * t * t : 2 / 2.75 > t ? 7.5625 * (t -= 1.5 / 2.75) * t + .75 : 2.5 / 2.75 > t ? 7.5625 * (t -= 2.25 / 2.75) * t + .9375 : 7.5625 * (t -= 2.625 / 2.75) * t + .984375, e ? .5 * (1 - t) : .5 * t + .5
        })), f("Circ", u("CircOut", function(t) {
            return Math.sqrt(1 - (t -= 1) * t)
        }), u("CircIn", function(t) {
            return -(Math.sqrt(1 - t * t) - 1)
        }), u("CircInOut", function(t) {
            return (t *= 2) < 1 ? -.5 * (Math.sqrt(1 - t * t) - 1) : .5 * (Math.sqrt(1 - (t -= 2) * t) + 1)
        })), r = function(e, n, r) {
            var i = l("easing." + e, function(t, e) {
                    this._p1 = t || 1, this._p2 = e || r, this._p3 = this._p2 / s * (Math.asin(1 / this._p1) || 0)
                }, !0),
                o = i.prototype = new t;
            return o.constructor = i, o.getRatio = n, o.config = function(t, e) {
                return new i(t, e)
            }, i
        }, f("Elastic", r("ElasticOut", function(t) {
            return this._p1 * Math.pow(2, -10 * t) * Math.sin((t - this._p3) * s / this._p2) + 1
        }, .3), r("ElasticIn", function(t) {
            return -(this._p1 * Math.pow(2, 10 * (t -= 1)) * Math.sin((t - this._p3) * s / this._p2))
        }, .3), r("ElasticInOut", function(t) {
            return (t *= 2) < 1 ? -.5 * this._p1 * Math.pow(2, 10 * (t -= 1)) * Math.sin((t - this._p3) * s / this._p2) : this._p1 * Math.pow(2, -10 * (t -= 1)) * Math.sin((t - this._p3) * s / this._p2) * .5 + 1
        }, .45)), f("Expo", u("ExpoOut", function(t) {
            return 1 - Math.pow(2, -10 * t)
        }), u("ExpoIn", function(t) {
            return Math.pow(2, 10 * (t - 1)) - .001
        }), u("ExpoInOut", function(t) {
            return (t *= 2) < 1 ? .5 * Math.pow(2, 10 * (t - 1)) : .5 * (2 - Math.pow(2, -10 * (t - 1)))
        })), f("Sine", u("SineOut", function(t) {
            return Math.sin(t * a)
        }), u("SineIn", function(t) {
            return -Math.cos(t * a) + 1
        }), u("SineInOut", function(t) {
            return -.5 * (Math.cos(Math.PI * t) - 1)
        })), l("easing.EaseLookup", {
            find: function(e) {
                return t.map[e]
            }
        }, !0), c(i.SlowMo, "SlowMo", "ease,"), c(n, "RoughEase", "ease,"), c(e, "SteppedEase", "ease,"), d
    }, !0)
}), _gsScope._gsDefine && _gsScope._gsQueue.pop()();
/*!
 * VERSION: 1.15.1
 * DATE: 2015-01-20
 * UPDATES AND DOCS AT: http://www.greensock.com
 *
 * @license Copyright (c) 2008-2015, GreenSock. All rights reserved.
 * This work is subject to the terms at http://greensock.com/standard-license or for
 * Club GreenSock members, the software agreement that was issued with your membership.
 * 
 * @author: Jack Doyle, jack@greensock.com
 */
var _gsScope = "undefined" != typeof module && module.exports && "undefined" != typeof global ? global : this || window;
(_gsScope._gsQueue || (_gsScope._gsQueue = [])).push(function() {
        "use strict";
        _gsScope._gsDefine("plugins.CSSPlugin", ["plugins.TweenPlugin", "TweenLite"], function(t, e) {
            var n, r, i, o, s = function() {
                    t.call(this, "css"), this._overwriteProps.length = 0, this.setRatio = s.prototype.setRatio
                },
                a = _gsScope._gsDefine.globals,
                l = {},
                u = s.prototype = new t("css");
            u.constructor = s, s.version = "1.15.1", s.API = 2, s.defaultTransformPerspective = 0, s.defaultSkewType = "compensated", u = "px", s.suffixMap = {
                top: u,
                right: u,
                bottom: u,
                left: u,
                width: u,
                height: u,
                fontSize: u,
                padding: u,
                margin: u,
                perspective: u,
                lineHeight: ""
            };
            var c, f, p, h, d, m, g = /(?:\d|\-\d|\.\d|\-\.\d)+/g,
                v = /(?:\d|\-\d|\.\d|\-\.\d|\+=\d|\-=\d|\+=.\d|\-=\.\d)+/g,
                y = /(?:\+=|\-=|\-|\b)[\d\-\.]+[a-zA-Z0-9]*(?:%|\b)/gi,
                _ = /(?![+-]?\d*\.?\d+|[+-]|e[+-]\d+)[^0-9]/g,
                x = /(?:\d|\-|\+|=|#|\.)*/g,
                b = /opacity *= *([^)]*)/i,
                w = /opacity:([^;]*)/i,
                T = /alpha\(opacity *=.+?\)/i,
                k = /^(rgb|hsl)/,
                S = /([A-Z])/g,
                C = /-([a-z])/gi,
                P = /(^(?:url\(\"|url\())|(?:(\"\))$|\)$)/gi,
                E = function(t, e) {
                    return e.toUpperCase()
                },
                A = /(?:Left|Right|Width)/i,
                N = /(M11|M12|M21|M22)=[\d\-\.e]+/gi,
                O = /progid\:DXImageTransform\.Microsoft\.Matrix\(.+?\)/i,
                j = /,(?=[^\)]*(?:\(|$))/gi,
                D = Math.PI / 180,
                M = 180 / Math.PI,
                L = {},
                R = document,
                F = function(t) {
                    return R.createElementNS ? R.createElementNS("http://www.w3.org/1999/xhtml", t) : R.createElement(t)
                },
                q = F("div"),
                H = F("img"),
                I = s._internals = {
                    _specialProps: l
                },
                z = navigator.userAgent,
                X = function() {
                    var t = z.indexOf("Android"),
                        e = F("a");
                    return p = -1 !== z.indexOf("Safari") && -1 === z.indexOf("Chrome") && (-1 === t || Number(z.substr(t + 8, 1)) > 3), d = p && Number(z.substr(z.indexOf("Version/") + 8, 1)) < 6, h = -1 !== z.indexOf("Firefox"), (/MSIE ([0-9]{1,}[\.0-9]{0,})/.exec(z) || /Trident\/.*rv:([0-9]{1,}[\.0-9]{0,})/.exec(z)) && (m = parseFloat(RegExp.$1)), e ? (e.style.cssText = "top:1px;opacity:.55;", /^0.55/.test(e.style.opacity)) : !1
                }(),
                B = function(t) {
                    return b.test("string" == typeof t ? t : (t.currentStyle ? t.currentStyle.filter : t.style.filter) || "") ? parseFloat(RegExp.$1) / 100 : 1
                },
                $ = function(t) {
                    window.console
                },
                W = "",
                Y = "",
                U = function(t, e) {
                    e = e || q;
                    var n, r, i = e.style;
                    if (void 0 !== i[t]) return t;
                    for (t = t.charAt(0).toUpperCase() + t.substr(1), n = ["O", "Moz", "ms", "Ms", "Webkit"], r = 5; --r > -1 && void 0 === i[n[r] + t];);
                    return r >= 0 ? (Y = 3 === r ? "ms" : n[r], W = "-" + Y.toLowerCase() + "-", Y + t) : null
                },
                V = R.defaultView ? R.defaultView.getComputedStyle : function() {},
                Q = s.getStyle = function(t, e, n, r, i) {
                    var o;
                    return X || "opacity" !== e ? (!r && t.style[e] ? o = t.style[e] : (n = n || V(t)) ? o = n[e] || n.getPropertyValue(e) || n.getPropertyValue(e.replace(S, "-$1").toLowerCase()) : t.currentStyle && (o = t.currentStyle[e]), null == i || o && "none" !== o && "auto" !== o && "auto auto" !== o ? o : i) : B(t)
                },
                G = I.convertToPixels = function(t, n, r, i, o) {
                    if ("px" === i || !i) return r;
                    if ("auto" === i || !r) return 0;
                    var a, l, u, c = A.test(n),
                        f = t,
                        p = q.style,
                        h = 0 > r;
                    if (h && (r = -r), "%" === i && -1 !== n.indexOf("border")) a = r / 100 * (c ? t.clientWidth : t.clientHeight);
                    else {
                        if (p.cssText = "border:0 solid red;position:" + Q(t, "position") + ";line-height:0;", "%" !== i && f.appendChild) p[c ? "borderLeftWidth" : "borderTopWidth"] = r + i;
                        else {
                            if (f = t.parentNode || R.body, l = f._gsCache, u = e.ticker.frame, l && c && l.time === u) return l.width * r / 100;
                            p[c ? "width" : "height"] = r + i
                        }
                        f.appendChild(q), a = parseFloat(q[c ? "offsetWidth" : "offsetHeight"]), f.removeChild(q), c && "%" === i && s.cacheWidths !== !1 && (l = f._gsCache = f._gsCache || {}, l.time = u, l.width = a / r * 100), 0 !== a || o || (a = G(t, n, r, i, !0))
                    }
                    return h ? -a : a
                },
                Z = I.calculateOffset = function(t, e, n) {
                    if ("absolute" !== Q(t, "position", n)) return 0;
                    var r = "left" === e ? "Left" : "Top",
                        i = Q(t, "margin" + r, n);
                    return t["offset" + r] - (G(t, e, parseFloat(i), i.replace(x, "")) || 0)
                },
                K = function(t, e) {
                    var n, r, i = {};
                    if (e = e || V(t, null))
                        for (n in e)(-1 === n.indexOf("Transform") || we === n) && (i[n] = e[n]);
                    else if (e = t.currentStyle || t.style)
                        for (n in e) "string" == typeof n && void 0 === i[n] && (i[n.replace(C, E)] = e[n]);
                    return X || (i.opacity = B(t)), r = je(t, e, !1), i.rotation = r.rotation, i.skewX = r.skewX, i.scaleX = r.scaleX, i.scaleY = r.scaleY, i.x = r.x, i.y = r.y, Se && (i.z = r.z, i.rotationX = r.rotationX, i.rotationY = r.rotationY, i.scaleZ = r.scaleZ), i.filters && delete i.filters, i
                },
                J = function(t, e, n, r, i) {
                    var o, s, a, l = {},
                        u = t.style;
                    for (s in n) "cssText" !== s && "length" !== s && isNaN(s) && (e[s] !== (o = n[s]) || i && i[s]) && -1 === s.indexOf("Origin") && ("number" == typeof o || "string" == typeof o) && (l[s] = "auto" !== o || "left" !== s && "top" !== s ? "" !== o && "auto" !== o && "none" !== o || "string" != typeof e[s] || "" === e[s].replace(_, "") ? o : 0 : Z(t, s), void 0 !== u[s] && (a = new he(u, s, u[s], a)));
                    if (r)
                        for (s in r) "className" !== s && (l[s] = r[s]);
                    return {
                        difs: l,
                        firstMPT: a
                    }
                },
                te = {
                    width: ["Left", "Right"],
                    height: ["Top", "Bottom"]
                },
                ee = ["marginLeft", "marginRight", "marginTop", "marginBottom"],
                ne = function(t, e, n) {
                    var r = parseFloat("width" === e ? t.offsetWidth : t.offsetHeight),
                        i = te[e],
                        o = i.length;
                    for (n = n || V(t, null); --o > -1;) r -= parseFloat(Q(t, "padding" + i[o], n, !0)) || 0, r -= parseFloat(Q(t, "border" + i[o] + "Width", n, !0)) || 0;
                    return r
                },
                re = function(t, e) {
                    (null == t || "" === t || "auto" === t || "auto auto" === t) && (t = "0 0");
                    var n = t.split(" "),
                        r = -1 !== t.indexOf("left") ? "0%" : -1 !== t.indexOf("right") ? "100%" : n[0],
                        i = -1 !== t.indexOf("top") ? "0%" : -1 !== t.indexOf("bottom") ? "100%" : n[1];
                    return null == i ? i = "center" === r ? "50%" : "0" : "center" === i && (i = "50%"), ("center" === r || isNaN(parseFloat(r)) && -1 === (r + "").indexOf("=")) && (r = "50%"), e && (e.oxp = -1 !== r.indexOf("%"), e.oyp = -1 !== i.indexOf("%"), e.oxr = "=" === r.charAt(1), e.oyr = "=" === i.charAt(1), e.ox = parseFloat(r.replace(_, "")), e.oy = parseFloat(i.replace(_, ""))), r + " " + i + (n.length > 2 ? " " + n[2] : "")
                },
                ie = function(t, e) {
                    return "string" == typeof t && "=" === t.charAt(1) ? parseInt(t.charAt(0) + "1", 10) * parseFloat(t.substr(2)) : parseFloat(t) - parseFloat(e)
                },
                oe = function(t, e) {
                    return null == t ? e : "string" == typeof t && "=" === t.charAt(1) ? parseInt(t.charAt(0) + "1", 10) * parseFloat(t.substr(2)) + e : parseFloat(t)
                },
                se = function(t, e, n, r) {
                    var i, o, s, a, l, u = 1e-6;
                    return null == t ? a = e : "number" == typeof t ? a = t : (i = 360, o = t.split("_"), l = "=" === t.charAt(1), s = (l ? parseInt(t.charAt(0) + "1", 10) * parseFloat(o[0].substr(2)) : parseFloat(o[0])) * (-1 === t.indexOf("rad") ? 1 : M) - (l ? 0 : e), o.length && (r && (r[n] = e + s), -1 !== t.indexOf("short") && (s %= i, s !== s % (i / 2) && (s = 0 > s ? s + i : s - i)), -1 !== t.indexOf("_cw") && 0 > s ? s = (s + 9999999999 * i) % i - (s / i | 0) * i : -1 !== t.indexOf("ccw") && s > 0 && (s = (s - 9999999999 * i) % i - (s / i | 0) * i)), a = e + s), u > a && a > -u && (a = 0), a
                },
                ae = {
                    aqua: [0, 255, 255],
                    lime: [0, 255, 0],
                    silver: [192, 192, 192],
                    black: [0, 0, 0],
                    maroon: [128, 0, 0],
                    teal: [0, 128, 128],
                    blue: [0, 0, 255],
                    navy: [0, 0, 128],
                    white: [255, 255, 255],
                    fuchsia: [255, 0, 255],
                    olive: [128, 128, 0],
                    yellow: [255, 255, 0],
                    orange: [255, 165, 0],
                    gray: [128, 128, 128],
                    purple: [128, 0, 128],
                    green: [0, 128, 0],
                    red: [255, 0, 0],
                    pink: [255, 192, 203],
                    cyan: [0, 255, 255],
                    transparent: [255, 255, 255, 0]
                },
                le = function(t, e, n) {
                    return t = 0 > t ? t + 1 : t > 1 ? t - 1 : t, 255 * (1 > 6 * t ? e + (n - e) * t * 6 : .5 > t ? n : 2 > 3 * t ? e + (n - e) * (2 / 3 - t) * 6 : e) + .5 | 0
                },
                ue = s.parseColor = function(t) {
                    var e, n, r, i, o, s;
                    return t && "" !== t ? "number" == typeof t ? [t >> 16, t >> 8 & 255, 255 & t] : ("," === t.charAt(t.length - 1) && (t = t.substr(0, t.length - 1)), ae[t] ? ae[t] : "#" === t.charAt(0) ? (4 === t.length && (e = t.charAt(1), n = t.charAt(2), r = t.charAt(3), t = "#" + e + e + n + n + r + r), t = parseInt(t.substr(1), 16), [t >> 16, t >> 8 & 255, 255 & t]) : "hsl" === t.substr(0, 3) ? (t = t.match(g), i = Number(t[0]) % 360 / 360, o = Number(t[1]) / 100, s = Number(t[2]) / 100, n = .5 >= s ? s * (o + 1) : s + o - s * o, e = 2 * s - n, t.length > 3 && (t[3] = Number(t[3])), t[0] = le(i + 1 / 3, e, n), t[1] = le(i, e, n), t[2] = le(i - 1 / 3, e, n), t) : (t = t.match(g) || ae.transparent, t[0] = Number(t[0]), t[1] = Number(t[1]), t[2] = Number(t[2]), t.length > 3 && (t[3] = Number(t[3])), t)) : ae.black
                },
                ce = "(?:\\b(?:(?:rgb|rgba|hsl|hsla)\\(.+?\\))|\\B#.+?\\b";
            for (u in ae) ce += "|" + u + "\\b";
            ce = new RegExp(ce + ")", "gi");
            var fe = function(t, e, n, r) {
                    if (null == t) return function(t) {
                        return t
                    };
                    var i, o = e ? (t.match(ce) || [""])[0] : "",
                        s = t.split(o).join("").match(y) || [],
                        a = t.substr(0, t.indexOf(s[0])),
                        l = ")" === t.charAt(t.length - 1) ? ")" : "",
                        u = -1 !== t.indexOf(" ") ? " " : ",",
                        c = s.length,
                        f = c > 0 ? s[0].replace(g, "") : "";
                    return c ? i = e ? function(t) {
                        var e, p, h, d;
                        if ("number" == typeof t) t += f;
                        else if (r && j.test(t)) {
                            for (d = t.replace(j, "|").split("|"), h = 0; h < d.length; h++) d[h] = i(d[h]);
                            return d.join(",")
                        }
                        if (e = (t.match(ce) || [o])[0], p = t.split(e).join("").match(y) || [], h = p.length, c > h--)
                            for (; ++h < c;) p[h] = n ? p[(h - 1) / 2 | 0] : s[h];
                        return a + p.join(u) + u + e + l + (-1 !== t.indexOf("inset") ? " inset" : "")
                    } : function(t) {
                        var e, o, p;
                        if ("number" == typeof t) t += f;
                        else if (r && j.test(t)) {
                            for (o = t.replace(j, "|").split("|"), p = 0; p < o.length; p++) o[p] = i(o[p]);
                            return o.join(",")
                        }
                        if (e = t.match(y) || [], p = e.length, c > p--)
                            for (; ++p < c;) e[p] = n ? e[(p - 1) / 2 | 0] : s[p];
                        return a + e.join(u) + l
                    } : function(t) {
                        return t
                    }
                },
                pe = function(t) {
                    return t = t.split(","),
                        function(e, n, r, i, o, s, a) {
                            var l, u = (n + "").split(" ");
                            for (a = {}, l = 0; 4 > l; l++) a[t[l]] = u[l] = u[l] || u[(l - 1) / 2 >> 0];
                            return i.parse(e, a, o, s)
                        }
                },
                he = (I._setPluginRatio = function(t) {
                    this.plugin.setRatio(t);
                    for (var e, n, r, i, o = this.data, s = o.proxy, a = o.firstMPT, l = 1e-6; a;) e = s[a.v], a.r ? e = Math.round(e) : l > e && e > -l && (e = 0), a.t[a.p] = e, a = a._next;
                    if (o.autoRotate && (o.autoRotate.rotation = s.rotation), 1 === t)
                        for (a = o.firstMPT; a;) {
                            if (n = a.t, n.type) {
                                if (1 === n.type) {
                                    for (i = n.xs0 + n.s + n.xs1, r = 1; r < n.l; r++) i += n["xn" + r] + n["xs" + (r + 1)];
                                    n.e = i
                                }
                            } else n.e = n.s + n.xs0;
                            a = a._next
                        }
                }, function(t, e, n, r, i) {
                    this.t = t, this.p = e, this.v = n, this.r = i, r && (r._prev = this, this._next = r)
                }),
                de = (I._parseToProxy = function(t, e, n, r, i, o) {
                    var s, a, l, u, c, f = r,
                        p = {},
                        h = {},
                        d = n._transform,
                        m = L;
                    for (n._transform = null, L = e, r = c = n.parse(t, e, r, i), L = m, o && (n._transform = d, f && (f._prev = null, f._prev && (f._prev._next = null))); r && r !== f;) {
                        if (r.type <= 1 && (a = r.p, h[a] = r.s + r.c, p[a] = r.s, o || (u = new he(r, "s", a, u, r.r), r.c = 0), 1 === r.type))
                            for (s = r.l; --s > 0;) l = "xn" + s, a = r.p + "_" + l, h[a] = r.data[l], p[a] = r[l], o || (u = new he(r, l, a, u, r.rxp[l]));
                        r = r._next
                    }
                    return {
                        proxy: p,
                        end: h,
                        firstMPT: u,
                        pt: c
                    }
                }, I.CSSPropTween = function(t, e, r, i, s, a, l, u, c, f, p) {
                    this.t = t, this.p = e, this.s = r, this.c = i, this.n = l || e, t instanceof de || o.push(this.n), this.r = u, this.type = a || 0, c && (this.pr = c, n = !0), this.b = void 0 === f ? r : f, this.e = void 0 === p ? r + i : p, s && (this._next = s, s._prev = this)
                }),
                me = s.parseComplex = function(t, e, n, r, i, o, s, a, l, u) {
                    n = n || o || "", s = new de(t, e, 0, 0, s, u ? 2 : 1, null, !1, a, n, r), r += "";
                    var f, p, h, d, m, y, _, x, b, w, T, S, C = n.split(", ").join(",").split(" "),
                        P = r.split(", ").join(",").split(" "),
                        E = C.length,
                        A = c !== !1;
                    for ((-1 !== r.indexOf(",") || -1 !== n.indexOf(",")) && (C = C.join(" ").replace(j, ", ").split(" "), P = P.join(" ").replace(j, ", ").split(" "), E = C.length), E !== P.length && (C = (o || "").split(" "), E = C.length), s.plugin = l, s.setRatio = u, f = 0; E > f; f++)
                        if (d = C[f], m = P[f], x = parseFloat(d), x || 0 === x) s.appendXtra("", x, ie(m, x), m.replace(v, ""), A && -1 !== m.indexOf("px"), !0);
                        else if (i && ("#" === d.charAt(0) || ae[d] || k.test(d))) S = "," === m.charAt(m.length - 1) ? ")," : ")", d = ue(d), m = ue(m), b = d.length + m.length > 6, b && !X && 0 === m[3] ? (s["xs" + s.l] += s.l ? " transparent" : "transparent", s.e = s.e.split(P[f]).join("transparent")) : (X || (b = !1), s.appendXtra(b ? "rgba(" : "rgb(", d[0], m[0] - d[0], ",", !0, !0).appendXtra("", d[1], m[1] - d[1], ",", !0).appendXtra("", d[2], m[2] - d[2], b ? "," : S, !0), b && (d = d.length < 4 ? 1 : d[3], s.appendXtra("", d, (m.length < 4 ? 1 : m[3]) - d, S, !1)));
                    else if (y = d.match(g)) {
                        if (_ = m.match(v), !_ || _.length !== y.length) return s;
                        for (h = 0, p = 0; p < y.length; p++) T = y[p], w = d.indexOf(T, h), s.appendXtra(d.substr(h, w - h), Number(T), ie(_[p], T), "", A && "px" === d.substr(w + T.length, 2), 0 === p), h = w + T.length;
                        s["xs" + s.l] += d.substr(h)
                    } else s["xs" + s.l] += s.l ? " " + d : d;
                    if (-1 !== r.indexOf("=") && s.data) {
                        for (S = s.xs0 + s.data.s, f = 1; f < s.l; f++) S += s["xs" + f] + s.data["xn" + f];
                        s.e = S + s["xs" + f]
                    }
                    return s.l || (s.type = -1, s.xs0 = s.e), s.xfirst || s
                },
                ge = 9;
            for (u = de.prototype, u.l = u.pr = 0; --ge > 0;) u["xn" + ge] = 0, u["xs" + ge] = "";
            u.xs0 = "", u._next = u._prev = u.xfirst = u.data = u.plugin = u.setRatio = u.rxp = null, u.appendXtra = function(t, e, n, r, i, o) {
                var s = this,
                    a = s.l;
                return s["xs" + a] += o && a ? " " + t : t || "", n || 0 === a || s.plugin ? (s.l++, s.type = s.setRatio ? 2 : 1, s["xs" + s.l] = r || "", a > 0 ? (s.data["xn" + a] = e + n, s.rxp["xn" + a] = i, s["xn" + a] = e, s.plugin || (s.xfirst = new de(s, "xn" + a, e, n, s.xfirst || s, 0, s.n, i, s.pr), s.xfirst.xs0 = 0), s) : (s.data = {
                    s: e + n
                }, s.rxp = {}, s.s = e, s.c = n, s.r = i, s)) : (s["xs" + a] += e + (r || ""), s)
            };
            var ve = function(t, e) {
                    e = e || {}, this.p = e.prefix ? U(t) || t : t, l[t] = l[this.p] = this, this.format = e.formatter || fe(e.defaultValue, e.color, e.collapsible, e.multi), e.parser && (this.parse = e.parser), this.clrs = e.color, this.multi = e.multi, this.keyword = e.keyword, this.dflt = e.defaultValue, this.pr = e.priority || 0
                },
                ye = I._registerComplexSpecialProp = function(t, e, n) {
                    "object" != typeof e && (e = {
                        parser: n
                    });
                    var r, i, o = t.split(","),
                        s = e.defaultValue;
                    for (n = n || [s], r = 0; r < o.length; r++) e.prefix = 0 === r && e.prefix, e.defaultValue = n[r] || s, i = new ve(o[r], e)
                },
                _e = function(t) {
                    if (!l[t]) {
                        var e = t.charAt(0).toUpperCase() + t.substr(1) + "Plugin";
                        ye(t, {
                            parser: function(t, n, r, i, o, s, u) {
                                var c = a.com.greensock.plugins[e];
                                return c ? (c._cssRegister(), l[r].parse(t, n, r, i, o, s, u)) : ($("Error: " + e + " js file not loaded."), o)
                            }
                        })
                    }
                };
            u = ve.prototype, u.parseComplex = function(t, e, n, r, i, o) {
                var s, a, l, u, c, f, p = this.keyword;
                if (this.multi && (j.test(n) || j.test(e) ? (a = e.replace(j, "|").split("|"), l = n.replace(j, "|").split("|")) : p && (a = [e], l = [n])), l) {
                    for (u = l.length > a.length ? l.length : a.length, s = 0; u > s; s++) e = a[s] = a[s] || this.dflt, n = l[s] = l[s] || this.dflt, p && (c = e.indexOf(p), f = n.indexOf(p), c !== f && (n = -1 === f ? l : a, n[s] += " " + p));
                    e = a.join(", "), n = l.join(", ")
                }
                return me(t, this.p, e, n, this.clrs, this.dflt, r, this.pr, i, o)
            }, u.parse = function(t, e, n, r, o, s) {
                return this.parseComplex(t.style, this.format(Q(t, this.p, i, !1, this.dflt)), this.format(e), o, s)
            }, s.registerSpecialProp = function(t, e, n) {
                ye(t, {
                    parser: function(t, r, i, o, s, a) {
                        var l = new de(t, i, 0, 0, s, 2, i, !1, n);
                        return l.plugin = a, l.setRatio = e(t, r, o._tween, i), l
                    },
                    priority: n
                })
            };
            var xe, be = "scaleX,scaleY,scaleZ,x,y,z,skewX,skewY,rotation,rotationX,rotationY,perspective,xPercent,yPercent".split(","),
                we = U("transform"),
                Te = W + "transform",
                ke = U("transformOrigin"),
                Se = null !== U("perspective"),
                Ce = I.Transform = function() {
                    this.perspective = parseFloat(s.defaultTransformPerspective) || 0, this.force3D = s.defaultForce3D !== !1 && Se ? s.defaultForce3D || "auto" : !1
                },
                Pe = window.SVGElement,
                Ee = function(t, e, n) {
                    var r, i = R.createElementNS("http://www.w3.org/2000/svg", t),
                        o = /([a-z])([A-Z])/g;
                    for (r in n) i.setAttributeNS(null, r.replace(o, "$1-$2").toLowerCase(), n[r]);
                    return e.appendChild(i), i
                },
                Ae = document.documentElement,
                Ne = function() {
                    var t, e, n, r = m || /Android/i.test(z) && !window.chrome;
                    return R.createElementNS && !r && (t = Ee("svg", Ae), e = Ee("rect", t, {
                        width: 100,
                        height: 50,
                        x: 100
                    }), n = e.getBoundingClientRect().width, e.style[ke] = "50% 50%", e.style[we] = "scaleX(0.5)", r = n === e.getBoundingClientRect().width && !(h && Se), Ae.removeChild(t)), r
                }(),
                Oe = function(t, e, n) {
                    var r = t.getBBox();
                    e = re(e).split(" "), n.xOrigin = (-1 !== e[0].indexOf("%") ? parseFloat(e[0]) / 100 * r.width : parseFloat(e[0])) + r.x, n.yOrigin = (-1 !== e[1].indexOf("%") ? parseFloat(e[1]) / 100 * r.height : parseFloat(e[1])) + r.y
                },
                je = I.getTransform = function(t, e, n, r) {
                    if (t._gsTransform && n && !r) return t._gsTransform;
                    var o, a, l, u, c, f, p, h, d, m, g = n ? t._gsTransform || new Ce : new Ce,
                        v = g.scaleX < 0,
                        y = 2e-5,
                        _ = 1e5,
                        x = Se ? parseFloat(Q(t, ke, e, !1, "0 0 0").split(" ")[2]) || g.zOrigin || 0 : 0,
                        b = parseFloat(s.defaultTransformPerspective) || 0;
                    if (we ? a = Q(t, Te, e, !0) : t.currentStyle && (a = t.currentStyle.filter.match(N), a = a && 4 === a.length ? [a[0].substr(4), Number(a[2].substr(4)), Number(a[1].substr(4)), a[3].substr(4), g.x || 0, g.y || 0].join(",") : ""), o = !a || "none" === a || "matrix(1, 0, 0, 1, 0, 0)" === a, g.svg = !!(Pe && "function" == typeof t.getBBox && t.getCTM && (!t.parentNode || t.parentNode.getBBox && t.parentNode.getCTM)), g.svg && (Oe(t, Q(t, ke, i, !1, "50% 50%") + "", g), xe = s.useSVGTransformAttr || Ne, l = t.getAttribute("transform"), o && l && -1 !== l.indexOf("matrix") && (a = l, o = 0)), !o) {
                        for (l = (a || "").match(/(?:\-|\b)[\d\-\.e]+\b/gi) || [], u = l.length; --u > -1;) c = Number(l[u]), l[u] = (f = c - (c |= 0)) ? (f * _ + (0 > f ? -.5 : .5) | 0) / _ + c : c;
                        if (16 === l.length) {
                            var w, T, k, S, C, P = l[0],
                                E = l[1],
                                A = l[2],
                                O = l[3],
                                j = l[4],
                                D = l[5],
                                L = l[6],
                                R = l[7],
                                F = l[8],
                                q = l[9],
                                H = l[10],
                                I = l[12],
                                z = l[13],
                                X = l[14],
                                B = l[11],
                                $ = Math.atan2(L, H);
                            g.zOrigin && (X = -g.zOrigin, I = F * X - l[12], z = q * X - l[13], X = H * X + g.zOrigin - l[14]), g.rotationX = $ * M, $ && (S = Math.cos(-$), C = Math.sin(-$), w = j * S + F * C, T = D * S + q * C, k = L * S + H * C, F = j * -C + F * S, q = D * -C + q * S, H = L * -C + H * S, B = R * -C + B * S, j = w, D = T, L = k), $ = Math.atan2(F, H), g.rotationY = $ * M, $ && (S = Math.cos(-$), C = Math.sin(-$), w = P * S - F * C, T = E * S - q * C, k = A * S - H * C, q = E * C + q * S, H = A * C + H * S, B = O * C + B * S, P = w, E = T, A = k), $ = Math.atan2(E, P), g.rotation = $ * M, $ && (S = Math.cos(-$), C = Math.sin(-$), P = P * S + j * C, T = E * S + D * C, D = E * -C + D * S, L = A * -C + L * S, E = T), g.rotationX && Math.abs(g.rotationX) + Math.abs(g.rotation) > 359.9 && (g.rotationX = g.rotation = 0, g.rotationY += 180), g.scaleX = (Math.sqrt(P * P + E * E) * _ + .5 | 0) / _, g.scaleY = (Math.sqrt(D * D + q * q) * _ + .5 | 0) / _, g.scaleZ = (Math.sqrt(L * L + H * H) * _ + .5 | 0) / _, g.skewX = 0, g.perspective = B ? 1 / (0 > B ? -B : B) : 0, g.x = I, g.y = z, g.z = X
                        } else if (!(Se && !r && l.length && g.x === l[4] && g.y === l[5] && (g.rotationX || g.rotationY) || void 0 !== g.x && "none" === Q(t, "display", e))) {
                            var W = l.length >= 6,
                                Y = W ? l[0] : 1,
                                U = l[1] || 0,
                                V = l[2] || 0,
                                G = W ? l[3] : 1;
                            g.x = l[4] || 0, g.y = l[5] || 0, p = Math.sqrt(Y * Y + U * U), h = Math.sqrt(G * G + V * V), d = Y || U ? Math.atan2(U, Y) * M : g.rotation || 0, m = V || G ? Math.atan2(V, G) * M + d : g.skewX || 0, Math.abs(m) > 90 && Math.abs(m) < 270 && (v ? (p *= -1, m += 0 >= d ? 180 : -180, d += 0 >= d ? 180 : -180) : (h *= -1, m += 0 >= m ? 180 : -180)), g.scaleX = p, g.scaleY = h, g.rotation = d, g.skewX = m, Se && (g.rotationX = g.rotationY = g.z = 0, g.perspective = b, g.scaleZ = 1)
                        }
                        g.zOrigin = x;
                        for (u in g) g[u] < y && g[u] > -y && (g[u] = 0)
                    }
                    return n && (t._gsTransform = g), g
                },
                De = function(t) {
                    var e, n, r = this.data,
                        i = -r.rotation * D,
                        o = i + r.skewX * D,
                        s = 1e5,
                        a = (Math.cos(i) * r.scaleX * s | 0) / s,
                        l = (Math.sin(i) * r.scaleX * s | 0) / s,
                        u = (Math.sin(o) * -r.scaleY * s | 0) / s,
                        c = (Math.cos(o) * r.scaleY * s | 0) / s,
                        f = this.t.style,
                        p = this.t.currentStyle;
                    if (p) {
                        n = l, l = -u, u = -n, e = p.filter, f.filter = "";
                        var h, d, g = this.t.offsetWidth,
                            v = this.t.offsetHeight,
                            y = "absolute" !== p.position,
                            _ = "progid:DXImageTransform.Microsoft.Matrix(M11=" + a + ", M12=" + l + ", M21=" + u + ", M22=" + c,
                            w = r.x + g * r.xPercent / 100,
                            T = r.y + v * r.yPercent / 100;
                        if (null != r.ox && (h = (r.oxp ? g * r.ox * .01 : r.ox) - g / 2, d = (r.oyp ? v * r.oy * .01 : r.oy) - v / 2, w += h - (h * a + d * l), T += d - (h * u + d * c)), y ? (h = g / 2, d = v / 2, _ += ", Dx=" + (h - (h * a + d * l) + w) + ", Dy=" + (d - (h * u + d * c) + T) + ")") : _ += ", sizingMethod='auto expand')", f.filter = -1 !== e.indexOf("DXImageTransform.Microsoft.Matrix(") ? e.replace(O, _) : _ + " " + e, (0 === t || 1 === t) && 1 === a && 0 === l && 0 === u && 1 === c && (y && -1 === _.indexOf("Dx=0, Dy=0") || b.test(e) && 100 !== parseFloat(RegExp.$1) || -1 === e.indexOf("gradient(" && e.indexOf("Alpha")) && f.removeAttribute("filter")), !y) {
                            var k, S, C, P = 8 > m ? 1 : -1;
                            for (h = r.ieOffsetX || 0, d = r.ieOffsetY || 0, r.ieOffsetX = Math.round((g - ((0 > a ? -a : a) * g + (0 > l ? -l : l) * v)) / 2 + w), r.ieOffsetY = Math.round((v - ((0 > c ? -c : c) * v + (0 > u ? -u : u) * g)) / 2 + T), ge = 0; 4 > ge; ge++) S = ee[ge], k = p[S], n = -1 !== k.indexOf("px") ? parseFloat(k) : G(this.t, S, parseFloat(k), k.replace(x, "")) || 0, C = n !== r[S] ? 2 > ge ? -r.ieOffsetX : -r.ieOffsetY : 2 > ge ? h - r.ieOffsetX : d - r.ieOffsetY, f[S] = (r[S] = Math.round(n - C * (0 === ge || 2 === ge ? 1 : P))) + "px"
                        }
                    }
                },
                Me = I.set3DTransformRatio = function(t) {
                    var e, n, r, i, o, s, a, l, u, c, f, p, d, m, g, v, y, _, x, b, w, T = this.data,
                        k = this.t.style,
                        S = T.rotation * D,
                        C = T.scaleX,
                        P = T.scaleY,
                        E = T.scaleZ,
                        A = T.x,
                        N = T.y,
                        O = T.z,
                        j = T.perspective;
                    if (!(1 !== t && 0 !== t && T.force3D || T.force3D === !0 || T.rotationY || T.rotationX || 1 !== E || j || O)) return void Le.call(this, t);
                    if (h && (m = 1e-4, m > C && C > -m && (C = E = 2e-5), m > P && P > -m && (P = E = 2e-5), !j || T.z || T.rotationX || T.rotationY || (j = 0)), S || T.skewX) g = e = Math.cos(S), v = i = Math.sin(S), T.skewX && (S -= T.skewX * D, g = Math.cos(S), v = Math.sin(S), "simple" === T.skewType && (y = Math.tan(T.skewX * D), y = Math.sqrt(1 + y * y), g *= y, v *= y)), n = -v, o = g;
                    else {
                        if (!(T.rotationY || T.rotationX || 1 !== E || j || T.svg)) return void(k[we] = (T.xPercent || T.yPercent ? "translate(" + T.xPercent + "%," + T.yPercent + "%) translate3d(" : "translate3d(") + A + "px," + N + "px," + O + "px)" + (1 !== C || 1 !== P ? " scale(" + C + "," + P + ")" : ""));
                        e = o = 1, n = i = 0
                    }
                    u = 1, r = s = a = l = c = f = 0, p = j ? -1 / j : 0, d = T.zOrigin, m = 1e-6, b = ",", w = "0", S = T.rotationY * D, S && (g = Math.cos(S), v = Math.sin(S), a = -v, c = p * -v, r = e * v, s = i * v, u = g, p *= g, e *= g, i *= g), S = T.rotationX * D, S && (g = Math.cos(S), v = Math.sin(S), y = n * g + r * v, _ = o * g + s * v, l = u * v, f = p * v, r = n * -v + r * g, s = o * -v + s * g, u *= g, p *= g, n = y, o = _), 1 !== E && (r *= E, s *= E, u *= E, p *= E), 1 !== P && (n *= P, o *= P, l *= P, f *= P), 1 !== C && (e *= C, i *= C, a *= C, c *= C), (d || T.svg) && (d && (A += r * -d, N += s * -d, O += u * -d + d), T.svg && (A += T.xOrigin - (T.xOrigin * e + T.yOrigin * n), N += T.yOrigin - (T.xOrigin * i + T.yOrigin * o)), m > A && A > -m && (A = w), m > N && N > -m && (N = w), m > O && O > -m && (O = 0)), x = T.xPercent || T.yPercent ? "translate(" + T.xPercent + "%," + T.yPercent + "%) matrix3d(" : "matrix3d(", x += (m > e && e > -m ? w : e) + b + (m > i && i > -m ? w : i) + b + (m > a && a > -m ? w : a), x += b + (m > c && c > -m ? w : c) + b + (m > n && n > -m ? w : n) + b + (m > o && o > -m ? w : o), T.rotationX || T.rotationY ? (x += b + (m > l && l > -m ? w : l) + b + (m > f && f > -m ? w : f) + b + (m > r && r > -m ? w : r), x += b + (m > s && s > -m ? w : s) + b + (m > u && u > -m ? w : u) + b + (m > p && p > -m ? w : p) + b) : x += ",0,0,0,0,1,0,", x += A + b + N + b + O + b + (j ? 1 + -O / j : 1) + ")", k[we] = x
                },
                Le = I.set2DTransformRatio = function(t) {
                    var e, n, r, i, o, s, a, l, u, c, f, p = this.data,
                        h = this.t,
                        d = h.style,
                        m = p.x,
                        g = p.y;
                    return !(p.rotationX || p.rotationY || p.z || p.force3D === !0 || "auto" === p.force3D && 1 !== t && 0 !== t) || p.svg && xe || !Se ? (i = p.scaleX, o = p.scaleY, void(p.rotation || p.skewX || p.svg ? (e = p.rotation * D, n = e - p.skewX * D, r = 1e5, s = Math.cos(e) * i, a = Math.sin(e) * i, l = Math.sin(n) * -o, u = Math.cos(n) * o, p.svg && (m += p.xOrigin - (p.xOrigin * s + p.yOrigin * l), g += p.yOrigin - (p.xOrigin * a + p.yOrigin * u), f = 1e-6, f > m && m > -f && (m = 0), f > g && g > -f && (g = 0)), c = (s * r | 0) / r + "," + (a * r | 0) / r + "," + (l * r | 0) / r + "," + (u * r | 0) / r + "," + m + "," + g + ")", p.svg && xe ? h.setAttribute("transform", "matrix(" + c) : d[we] = (p.xPercent || p.yPercent ? "translate(" + p.xPercent + "%," + p.yPercent + "%) matrix(" : "matrix(") + c) : d[we] = (p.xPercent || p.yPercent ? "translate(" + p.xPercent + "%," + p.yPercent + "%) matrix(" : "matrix(") + i + ",0,0," + o + "," + m + "," + g + ")")) : (this.setRatio = Me, void Me.call(this, t))
                };
            u = Ce.prototype, u.x = u.y = u.z = u.skewX = u.skewY = u.rotation = u.rotationX = u.rotationY = u.zOrigin = u.xPercent = u.yPercent = 0, u.scaleX = u.scaleY = u.scaleZ = 1, ye("transform,scale,scaleX,scaleY,scaleZ,x,y,z,rotation,rotationX,rotationY,rotationZ,skewX,skewY,shortRotation,shortRotationX,shortRotationY,shortRotationZ,transformOrigin,transformPerspective,directionalRotation,parseTransform,force3D,skewType,xPercent,yPercent", {
                parser: function(t, e, n, r, o, a, l) {
                    if (r._lastParsedTransform === l) return o;
                    r._lastParsedTransform = l;
                    var u, c, f, p, h, d, m, g = r._transform = je(t, i, !0, l.parseTransform),
                        v = t.style,
                        y = 1e-6,
                        _ = be.length,
                        x = l,
                        b = {};
                    if ("string" == typeof x.transform && we) f = q.style, f[we] = x.transform, f.display = "block", f.position = "absolute", R.body.appendChild(q), u = je(q, null, !1), R.body.removeChild(q);
                    else if ("object" == typeof x) {
                        if (u = {
                                scaleX: oe(null != x.scaleX ? x.scaleX : x.scale, g.scaleX),
                                scaleY: oe(null != x.scaleY ? x.scaleY : x.scale, g.scaleY),
                                scaleZ: oe(x.scaleZ, g.scaleZ),
                                x: oe(x.x, g.x),
                                y: oe(x.y, g.y),
                                z: oe(x.z, g.z),
                                xPercent: oe(x.xPercent, g.xPercent),
                                yPercent: oe(x.yPercent, g.yPercent),
                                perspective: oe(x.transformPerspective, g.perspective)
                            }, m = x.directionalRotation, null != m)
                            if ("object" == typeof m)
                                for (f in m) x[f] = m[f];
                            else x.rotation = m;
                            "string" == typeof x.x && -1 !== x.x.indexOf("%") && (u.x = 0, u.xPercent = oe(x.x, g.xPercent)), "string" == typeof x.y && -1 !== x.y.indexOf("%") && (u.y = 0, u.yPercent = oe(x.y, g.yPercent)), u.rotation = se("rotation" in x ? x.rotation : "shortRotation" in x ? x.shortRotation + "_short" : "rotationZ" in x ? x.rotationZ : g.rotation, g.rotation, "rotation", b), Se && (u.rotationX = se("rotationX" in x ? x.rotationX : "shortRotationX" in x ? x.shortRotationX + "_short" : g.rotationX || 0, g.rotationX, "rotationX", b), u.rotationY = se("rotationY" in x ? x.rotationY : "shortRotationY" in x ? x.shortRotationY + "_short" : g.rotationY || 0, g.rotationY, "rotationY", b)), u.skewX = null == x.skewX ? g.skewX : se(x.skewX, g.skewX), u.skewY = null == x.skewY ? g.skewY : se(x.skewY, g.skewY), (c = u.skewY - g.skewY) && (u.skewX += c, u.rotation += c)
                    }
                    for (Se && null != x.force3D && (g.force3D = x.force3D, d = !0), g.skewType = x.skewType || g.skewType || s.defaultSkewType, h = g.force3D || g.z || g.rotationX || g.rotationY || u.z || u.rotationX || u.rotationY || u.perspective, h || null == x.scale || (u.scaleZ = 1); --_ > -1;) n = be[_], p = u[n] - g[n], (p > y || -y > p || null != x[n] || null != L[n]) && (d = !0, o = new de(g, n, g[n], p, o), n in b && (o.e = b[n]), o.xs0 = 0, o.plugin = a, r._overwriteProps.push(o.n));
                    return p = x.transformOrigin, p && g.svg && (Oe(t, re(p), u), o = new de(g, "xOrigin", g.xOrigin, u.xOrigin - g.xOrigin, o, -1, "transformOrigin"), o.b = g.xOrigin, o.e = o.xs0 = u.xOrigin, o = new de(g, "yOrigin", g.yOrigin, u.yOrigin - g.yOrigin, o, -1, "transformOrigin"), o.b = g.yOrigin, o.e = o.xs0 = u.yOrigin, p = "0px 0px"), (p || Se && h && g.zOrigin) && (we ? (d = !0, n = ke, p = (p || Q(t, n, i, !1, "50% 50%")) + "", o = new de(v, n, 0, 0, o, -1, "transformOrigin"), o.b = v[n], o.plugin = a, Se ? (f = g.zOrigin, p = p.split(" "), g.zOrigin = (p.length > 2 && (0 === f || "0px" !== p[2]) ? parseFloat(p[2]) : f) || 0, o.xs0 = o.e = p[0] + " " + (p[1] || "50%") + " 0px", o = new de(g, "zOrigin", 0, 0, o, -1, o.n), o.b = f, o.xs0 = o.e = g.zOrigin) : o.xs0 = o.e = p) : re(p + "", g)), d && (r._transformType = g.svg && xe || !h && 3 !== this._transformType ? 2 : 3), o
                },
                prefix: !0
            }), ye("boxShadow", {
                defaultValue: "0px 0px 0px 0px #999",
                prefix: !0,
                color: !0,
                multi: !0,
                keyword: "inset"
            }), ye("borderRadius", {
                defaultValue: "0px",
                parser: function(t, e, n, o, s) {
                    e = this.format(e);
                    var a, l, u, c, f, p, h, d, m, g, v, y, _, x, b, w, T = ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomRightRadius", "borderBottomLeftRadius"],
                        k = t.style;
                    for (m = parseFloat(t.offsetWidth), g = parseFloat(t.offsetHeight), a = e.split(" "), l = 0; l < T.length; l++) this.p.indexOf("border") && (T[l] = U(T[l])), f = c = Q(t, T[l], i, !1, "0px"), -1 !== f.indexOf(" ") && (c = f.split(" "), f = c[0], c = c[1]), p = u = a[l], h = parseFloat(f), y = f.substr((h + "").length), _ = "=" === p.charAt(1), _ ? (d = parseInt(p.charAt(0) + "1", 10), p = p.substr(2), d *= parseFloat(p), v = p.substr((d + "").length - (0 > d ? 1 : 0)) || "") : (d = parseFloat(p), v = p.substr((d + "").length)), "" === v && (v = r[n] || y), v !== y && (x = G(t, "borderLeft", h, y), b = G(t, "borderTop", h, y), "%" === v ? (f = x / m * 100 + "%", c = b / g * 100 + "%") : "em" === v ? (w = G(t, "borderLeft", 1, "em"), f = x / w + "em", c = b / w + "em") : (f = x + "px", c = b + "px"), _ && (p = parseFloat(f) + d + v, u = parseFloat(c) + d + v)), s = me(k, T[l], f + " " + c, p + " " + u, !1, "0px", s);
                    return s
                },
                prefix: !0,
                formatter: fe("0px 0px 0px 0px", !1, !0)
            }), ye("backgroundPosition", {
                defaultValue: "0 0",
                parser: function(t, e, n, r, o, s) {
                    var a, l, u, c, f, p, h = "background-position",
                        d = i || V(t, null),
                        g = this.format((d ? m ? d.getPropertyValue(h + "-x") + " " + d.getPropertyValue(h + "-y") : d.getPropertyValue(h) : t.currentStyle.backgroundPositionX + " " + t.currentStyle.backgroundPositionY) || "0 0"),
                        v = this.format(e);
                    if (-1 !== g.indexOf("%") != (-1 !== v.indexOf("%")) && (p = Q(t, "backgroundImage").replace(P, ""), p && "none" !== p)) {
                        for (a = g.split(" "), l = v.split(" "), H.setAttribute("src", p), u = 2; --u > -1;) g = a[u], c = -1 !== g.indexOf("%"), c !== (-1 !== l[u].indexOf("%")) && (f = 0 === u ? t.offsetWidth - H.width : t.offsetHeight - H.height, a[u] = c ? parseFloat(g) / 100 * f + "px" : parseFloat(g) / f * 100 + "%");
                        g = a.join(" ")
                    }
                    return this.parseComplex(t.style, g, v, o, s)
                },
                formatter: re
            }), ye("backgroundSize", {
                defaultValue: "0 0",
                formatter: re
            }), ye("perspective", {
                defaultValue: "0px",
                prefix: !0
            }), ye("perspectiveOrigin", {
                defaultValue: "50% 50%",
                prefix: !0
            }), ye("transformStyle", {
                prefix: !0
            }), ye("backfaceVisibility", {
                prefix: !0
            }), ye("userSelect", {
                prefix: !0
            }), ye("margin", {
                parser: pe("marginTop,marginRight,marginBottom,marginLeft")
            }), ye("padding", {
                parser: pe("paddingTop,paddingRight,paddingBottom,paddingLeft")
            }), ye("clip", {
                defaultValue: "rect(0px,0px,0px,0px)",
                parser: function(t, e, n, r, o, s) {
                    var a, l, u;
                    return 9 > m ? (l = t.currentStyle, u = 8 > m ? " " : ",", a = "rect(" + l.clipTop + u + l.clipRight + u + l.clipBottom + u + l.clipLeft + ")", e = this.format(e).split(",").join(u)) : (a = this.format(Q(t, this.p, i, !1, this.dflt)), e = this.format(e)), this.parseComplex(t.style, a, e, o, s)
                }
            }), ye("textShadow", {
                defaultValue: "0px 0px 0px #999",
                color: !0,
                multi: !0
            }), ye("autoRound,strictUnits", {
                parser: function(t, e, n, r, i) {
                    return i
                }
            }), ye("border", {
                defaultValue: "0px solid #000",
                parser: function(t, e, n, r, o, s) {
                    return this.parseComplex(t.style, this.format(Q(t, "borderTopWidth", i, !1, "0px") + " " + Q(t, "borderTopStyle", i, !1, "solid") + " " + Q(t, "borderTopColor", i, !1, "#000")), this.format(e), o, s)
                },
                color: !0,
                formatter: function(t) {
                    var e = t.split(" ");
                    return e[0] + " " + (e[1] || "solid") + " " + (t.match(ce) || ["#000"])[0]
                }
            }), ye("borderWidth", {
                parser: pe("borderTopWidth,borderRightWidth,borderBottomWidth,borderLeftWidth")
            }), ye("float,cssFloat,styleFloat", {
                parser: function(t, e, n, r, i) {
                    var o = t.style,
                        s = "cssFloat" in o ? "cssFloat" : "styleFloat";
                    return new de(o, s, 0, 0, i, -1, n, !1, 0, o[s], e)
                }
            });
            var Re = function(t) {
                var e, n = this.t,
                    r = n.filter || Q(this.data, "filter") || "",
                    i = this.s + this.c * t | 0;
                100 === i && (-1 === r.indexOf("atrix(") && -1 === r.indexOf("radient(") && -1 === r.indexOf("oader(") ? (n.removeAttribute("filter"), e = !Q(this.data, "filter")) : (n.filter = r.replace(T, ""), e = !0)), e || (this.xn1 && (n.filter = r = r || "alpha(opacity=" + i + ")"), -1 === r.indexOf("pacity") ? 0 === i && this.xn1 || (n.filter = r + " alpha(opacity=" + i + ")") : n.filter = r.replace(b, "opacity=" + i))
            };
            ye("opacity,alpha,autoAlpha", {
                defaultValue: "1",
                parser: function(t, e, n, r, o, s) {
                    var a = parseFloat(Q(t, "opacity", i, !1, "1")),
                        l = t.style,
                        u = "autoAlpha" === n;
                    return "string" == typeof e && "=" === e.charAt(1) && (e = ("-" === e.charAt(0) ? -1 : 1) * parseFloat(e.substr(2)) + a), u && 1 === a && "hidden" === Q(t, "visibility", i) && 0 !== e && (a = 0), X ? o = new de(l, "opacity", a, e - a, o) : (o = new de(l, "opacity", 100 * a, 100 * (e - a), o), o.xn1 = u ? 1 : 0, l.zoom = 1, o.type = 2, o.b = "alpha(opacity=" + o.s + ")", o.e = "alpha(opacity=" + (o.s + o.c) + ")", o.data = t, o.plugin = s, o.setRatio = Re), u && (o = new de(l, "visibility", 0, 0, o, -1, null, !1, 0, 0 !== a ? "inherit" : "hidden", 0 === e ? "hidden" : "inherit"), o.xs0 = "inherit", r._overwriteProps.push(o.n), r._overwriteProps.push(n)), o
                }
            });
            var Fe = function(t, e) {
                    e && (t.removeProperty ? ("ms" === e.substr(0, 2) && (e = "M" + e.substr(1)), t.removeProperty(e.replace(S, "-$1").toLowerCase())) : t.removeAttribute(e))
                },
                qe = function(t) {
                    if (this.t._gsClassPT = this, 1 === t || 0 === t) {
                        this.t.setAttribute("class", 0 === t ? this.b : this.e);
                        for (var e = this.data, n = this.t.style; e;) e.v ? n[e.p] = e.v : Fe(n, e.p), e = e._next;
                        1 === t && this.t._gsClassPT === this && (this.t._gsClassPT = null)
                    } else this.t.getAttribute("class") !== this.e && this.t.setAttribute("class", this.e)
                };
            ye("className", {
                parser: function(t, e, r, o, s, a, l) {
                    var u, c, f, p, h, d = t.getAttribute("class") || "",
                        m = t.style.cssText;
                    if (s = o._classNamePT = new de(t, r, 0, 0, s, 2), s.setRatio = qe, s.pr = -11, n = !0, s.b = d, c = K(t, i), f = t._gsClassPT) {
                        for (p = {}, h = f.data; h;) p[h.p] = 1, h = h._next;
                        f.setRatio(1)
                    }
                    return t._gsClassPT = s, s.e = "=" !== e.charAt(1) ? e : d.replace(new RegExp("\\s*\\b" + e.substr(2) + "\\b"), "") + ("+" === e.charAt(0) ? " " + e.substr(2) : ""), o._tween._duration && (t.setAttribute("class", s.e), u = J(t, c, K(t), l, p), t.setAttribute("class", d), s.data = u.firstMPT, t.style.cssText = m, s = s.xfirst = o.parse(t, u.difs, s, a)), s
                }
            });
            var He = function(t) {
                if ((1 === t || 0 === t) && this.data._totalTime === this.data._totalDuration && "isFromStart" !== this.data.data) {
                    var e, n, r, i, o = this.t.style,
                        s = l.transform.parse;
                    if ("all" === this.e) o.cssText = "", i = !0;
                    else
                        for (e = this.e.split(" ").join("").split(","), r = e.length; --r > -1;) n = e[r], l[n] && (l[n].parse === s ? i = !0 : n = "transformOrigin" === n ? ke : l[n].p), Fe(o, n);
                    i && (Fe(o, we), this.t._gsTransform && delete this.t._gsTransform)
                }
            };
            for (ye("clearProps", {
                    parser: function(t, e, r, i, o) {
                        return o = new de(t, r, 0, 0, o, 2), o.setRatio = He, o.e = e, o.pr = -10, o.data = i._tween, n = !0, o
                    }
                }), u = "bezier,throwProps,physicsProps,physics2D".split(","), ge = u.length; ge--;) _e(u[ge]);
            u = s.prototype, u._firstPT = u._lastParsedTransform = u._transform = null, u._onInitTween = function(t, e, a) {
                if (!t.nodeType) return !1;
                this._target = t, this._tween = a, this._vars = e, c = e.autoRound, n = !1, r = e.suffixMap || s.suffixMap, i = V(t, ""), o = this._overwriteProps;
                var l, u, h, m, g, v, y, _, x, b = t.style;
                if (f && "" === b.zIndex && (l = Q(t, "zIndex", i), ("auto" === l || "" === l) && this._addLazySet(b, "zIndex", 0)), "string" == typeof e && (m = b.cssText, l = K(t, i), b.cssText = m + ";" + e, l = J(t, l, K(t)).difs, !X && w.test(e) && (l.opacity = parseFloat(RegExp.$1)), e = l, b.cssText = m), this._firstPT = u = this.parse(t, e, null), this._transformType) {
                    for (x = 3 === this._transformType, we ? p && (f = !0, "" === b.zIndex && (y = Q(t, "zIndex", i), ("auto" === y || "" === y) && this._addLazySet(b, "zIndex", 0)), d && this._addLazySet(b, "WebkitBackfaceVisibility", this._vars.WebkitBackfaceVisibility || (x ? "visible" : "hidden"))) : b.zoom = 1, h = u; h && h._next;) h = h._next;
                    _ = new de(t, "transform", 0, 0, null, 2), this._linkCSSP(_, null, h), _.setRatio = x && Se ? Me : we ? Le : De, _.data = this._transform || je(t, i, !0), o.pop()
                }
                if (n) {
                    for (; u;) {
                        for (v = u._next, h = m; h && h.pr > u.pr;) h = h._next;
                        (u._prev = h ? h._prev : g) ? u._prev._next = u: m = u, (u._next = h) ? h._prev = u : g = u, u = v
                    }
                    this._firstPT = m
                }
                return !0
            }, u.parse = function(t, e, n, o) {
                var s, a, u, f, p, h, d, m, g, v, y = t.style;
                for (s in e) h = e[s], a = l[s], a ? n = a.parse(t, h, s, this, n, o, e) : (p = Q(t, s, i) + "", g = "string" == typeof h, "color" === s || "fill" === s || "stroke" === s || -1 !== s.indexOf("Color") || g && k.test(h) ? (g || (h = ue(h), h = (h.length > 3 ? "rgba(" : "rgb(") + h.join(",") + ")"), n = me(y, s, p, h, !0, "transparent", n, 0, o)) : !g || -1 === h.indexOf(" ") && -1 === h.indexOf(",") ? (u = parseFloat(p), d = u || 0 === u ? p.substr((u + "").length) : "", ("" === p || "auto" === p) && ("width" === s || "height" === s ? (u = ne(t, s, i), d = "px") : "left" === s || "top" === s ? (u = Z(t, s, i), d = "px") : (u = "opacity" !== s ? 0 : 1, d = "")), v = g && "=" === h.charAt(1), v ? (f = parseInt(h.charAt(0) + "1", 10), h = h.substr(2), f *= parseFloat(h), m = h.replace(x, "")) : (f = parseFloat(h), m = g ? h.replace(x, "") : ""), "" === m && (m = s in r ? r[s] : d), h = f || 0 === f ? (v ? f + u : f) + m : e[s], d !== m && "" !== m && (f || 0 === f) && u && (u = G(t, s, u, d), "%" === m ? (u /= G(t, s, 100, "%") / 100, e.strictUnits !== !0 && (p = u + "%")) : "em" === m ? u /= G(t, s, 1, "em") : "px" !== m && (f = G(t, s, f, m), m = "px"), v && (f || 0 === f) && (h = f + u + m)), v && (f += u), !u && 0 !== u || !f && 0 !== f ? void 0 !== y[s] && (h || h + "" != "NaN" && null != h) ? (n = new de(y, s, f || u || 0, 0, n, -1, s, !1, 0, p, h), n.xs0 = "none" !== h || "display" !== s && -1 === s.indexOf("Style") ? h : p) : $("invalid " + s + " tween value: " + e[s]) : (n = new de(y, s, u, f - u, n, 0, s, c !== !1 && ("px" === m || "zIndex" === s), 0, p, h), n.xs0 = m)) : n = me(y, s, p, h, !0, null, n, 0, o)), o && n && !n.plugin && (n.plugin = o);
                return n
            }, u.setRatio = function(t) {
                var e, n, r, i = this._firstPT,
                    o = 1e-6;
                if (1 !== t || this._tween._time !== this._tween._duration && 0 !== this._tween._time)
                    if (t || this._tween._time !== this._tween._duration && 0 !== this._tween._time || this._tween._rawPrevTime === -1e-6)
                        for (; i;) {
                            if (e = i.c * t + i.s, i.r ? e = Math.round(e) : o > e && e > -o && (e = 0), i.type)
                                if (1 === i.type)
                                    if (r = i.l, 2 === r) i.t[i.p] = i.xs0 + e + i.xs1 + i.xn1 + i.xs2;
                                    else if (3 === r) i.t[i.p] = i.xs0 + e + i.xs1 + i.xn1 + i.xs2 + i.xn2 + i.xs3;
                            else if (4 === r) i.t[i.p] = i.xs0 + e + i.xs1 + i.xn1 + i.xs2 + i.xn2 + i.xs3 + i.xn3 + i.xs4;
                            else if (5 === r) i.t[i.p] = i.xs0 + e + i.xs1 + i.xn1 + i.xs2 + i.xn2 + i.xs3 + i.xn3 + i.xs4 + i.xn4 + i.xs5;
                            else {
                                for (n = i.xs0 + e + i.xs1, r = 1; r < i.l; r++) n += i["xn" + r] + i["xs" + (r + 1)];
                                i.t[i.p] = n
                            } else -1 === i.type ? i.t[i.p] = i.xs0 : i.setRatio && i.setRatio(t);
                            else i.t[i.p] = e + i.xs0;
                            i = i._next
                        } else
                            for (; i;) 2 !== i.type ? i.t[i.p] = i.b : i.setRatio(t), i = i._next;
                    else
                        for (; i;) 2 !== i.type ? i.t[i.p] = i.e : i.setRatio(t), i = i._next
            }, u._enableTransforms = function(t) {
                this._transform = this._transform || je(this._target, i, !0), this._transformType = this._transform.svg && xe || !t && 3 !== this._transformType ? 2 : 3
            };
            var Ie = function() {
                this.t[this.p] = this.e, this.data._linkCSSP(this, this._next, null, !0)
            };
            u._addLazySet = function(t, e, n) {
                var r = this._firstPT = new de(t, e, 0, 0, this._firstPT, 2);
                r.e = n, r.setRatio = Ie, r.data = this
            }, u._linkCSSP = function(t, e, n, r) {
                return t && (e && (e._prev = t), t._next && (t._next._prev = t._prev), t._prev ? t._prev._next = t._next : this._firstPT === t && (this._firstPT = t._next, r = !0), n ? n._next = t : r || null !== this._firstPT || (this._firstPT = t), t._next = e, t._prev = n), t
            }, u._kill = function(e) {
                var n, r, i, o = e;
                if (e.autoAlpha || e.alpha) {
                    o = {};
                    for (r in e) o[r] = e[r];
                    o.opacity = 1, o.autoAlpha && (o.visibility = 1)
                }
                return e.className && (n = this._classNamePT) && (i = n.xfirst, i && i._prev ? this._linkCSSP(i._prev, n._next, i._prev._prev) : i === this._firstPT && (this._firstPT = n._next), n._next && this._linkCSSP(n._next, n._next._next, i._prev), this._classNamePT = null), t.prototype._kill.call(this, o)
            };
            var ze = function(t, e, n) {
                var r, i, o, s;
                if (t.slice)
                    for (i = t.length; --i > -1;) ze(t[i], e, n);
                else
                    for (r = t.childNodes, i = r.length; --i > -1;) o = r[i], s = o.type, o.style && (e.push(K(o)), n && n.push(o)), 1 !== s && 9 !== s && 11 !== s || !o.childNodes.length || ze(o, e, n)
            };
            return s.cascadeTo = function(t, n, r) {
                var i, o, s, a = e.to(t, n, r),
                    l = [a],
                    u = [],
                    c = [],
                    f = [],
                    p = e._internals.reservedProps;
                for (t = a._targets || a.target, ze(t, u, f), a.render(n, !0), ze(t, c), a.render(0, !0), a._enabled(!0), i = f.length; --i > -1;)
                    if (o = J(f[i], u[i], c[i]), o.firstMPT) {
                        o = o.difs;
                        for (s in r) p[s] && (o[s] = r[s]);
                        l.push(e.to(f[i], n, o))
                    }
                return l
            }, t.activate([s]), s
        }, !0)
    }), _gsScope._gsDefine && _gsScope._gsQueue.pop()(),
    function(t) {
        "use strict";
        var e = function() {
            return (_gsScope.GreenSockGlobals || _gsScope)[t]
        };
        "function" == typeof define && define.amd ? define(["TweenLite"], e) : "undefined" != typeof module && module.exports && (require("../TweenLite.js"), module.exports = e())
    }("CSSPlugin"),
    /*!
     * VERSION: 1.15.1
     * DATE: 2015-01-08
     * UPDATES AND DOCS AT: http://greensock.com
     *
     * @license Copyright (c) 2008-2015, GreenSock. All rights reserved.
     * This work is subject to the terms at http://greensock.com/standard-license or for
     * Club GreenSock members, the software agreement that was issued with your membership.
     * 
     * @author: Jack Doyle, jack@greensock.com
     */
    function(t, e) {
        "use strict";
        var n = t.GreenSockGlobals = t.GreenSockGlobals || t;
        if (!n.TweenLite) {
            var r, i, o, s, a, l = function(t) {
                    var e, r = t.split("."),
                        i = n;
                    for (e = 0; e < r.length; e++) i[r[e]] = i = i[r[e]] || {};
                    return i
                },
                u = l("com.greensock"),
                c = 1e-10,
                f = function(t) {
                    var e, n = [],
                        r = t.length;
                    for (e = 0; e !== r; n.push(t[e++]));
                    return n
                },
                p = function() {},
                h = function() {
                    var t = Object.prototype.toString,
                        e = t.call([]);
                    return function(n) {
                        return null != n && (n instanceof Array || "object" == typeof n && !!n.push && t.call(n) === e)
                    }
                }(),
                d = {},
                m = function(r, i, o, s) {
                    this.sc = d[r] ? d[r].sc : [], d[r] = this, this.gsClass = null, this.func = o;
                    var a = [];
                    this.check = function(u) {
                        for (var c, f, p, h, g = i.length, v = g; --g > -1;)(c = d[i[g]] || new m(i[g], [])).gsClass ? (a[g] = c.gsClass, v--) : u && c.sc.push(this);
                        if (0 === v && o)
                            for (f = ("com.greensock." + r).split("."), p = f.pop(), h = l(f.join("."))[p] = this.gsClass = o.apply(o, a), s && (n[p] = h, "function" == typeof define && define.amd ? define((t.GreenSockAMDPath ? t.GreenSockAMDPath + "/" : "") + r.split(".").pop(), [], function() {
                                    return h
                                }) : r === e && "undefined" != typeof module && module.exports && (module.exports = h)), g = 0; g < this.sc.length; g++) this.sc[g].check()
                    }, this.check(!0)
                },
                g = t._gsDefine = function(t, e, n, r) {
                    return new m(t, e, n, r)
                },
                v = u._class = function(t, e, n) {
                    return e = e || function() {}, g(t, [], function() {
                        return e
                    }, n), e
                };
            g.globals = n;
            var y = [0, 0, 1, 1],
                _ = [],
                x = v("easing.Ease", function(t, e, n, r) {
                    this._func = t, this._type = n || 0, this._power = r || 0, this._params = e ? y.concat(e) : y
                }, !0),
                b = x.map = {},
                w = x.register = function(t, e, n, r) {
                    for (var i, o, s, a, l = e.split(","), c = l.length, f = (n || "easeIn,easeOut,easeInOut").split(","); --c > -1;)
                        for (o = l[c], i = r ? v("easing." + o, null, !0) : u.easing[o] || {}, s = f.length; --s > -1;) a = f[s], b[o + "." + a] = b[a + o] = i[a] = t.getRatio ? t : t[a] || new t
                };
            for (o = x.prototype, o._calcEnd = !1, o.getRatio = function(t) {
                    if (this._func) return this._params[0] = t, this._func.apply(null, this._params);
                    var e = this._type,
                        n = this._power,
                        r = 1 === e ? 1 - t : 2 === e ? t : .5 > t ? 2 * t : 2 * (1 - t);
                    return 1 === n ? r *= r : 2 === n ? r *= r * r : 3 === n ? r *= r * r * r : 4 === n && (r *= r * r * r * r), 1 === e ? 1 - r : 2 === e ? r : .5 > t ? r / 2 : 1 - r / 2
                }, r = ["Linear", "Quad", "Cubic", "Quart", "Quint,Strong"], i = r.length; --i > -1;) o = r[i] + ",Power" + i, w(new x(null, null, 1, i), o, "easeOut", !0), w(new x(null, null, 2, i), o, "easeIn" + (0 === i ? ",easeNone" : "")), w(new x(null, null, 3, i), o, "easeInOut");
            b.linear = u.easing.Linear.easeIn, b.swing = u.easing.Quad.easeInOut;
            var T = v("events.EventDispatcher", function(t) {
                this._listeners = {}, this._eventTarget = t || this
            });
            o = T.prototype, o.addEventListener = function(t, e, n, r, i) {
                i = i || 0;
                var o, l, u = this._listeners[t],
                    c = 0;
                for (null == u && (this._listeners[t] = u = []), l = u.length; --l > -1;) o = u[l], o.c === e && o.s === n ? u.splice(l, 1) : 0 === c && o.pr < i && (c = l + 1);
                u.splice(c, 0, {
                    c: e,
                    s: n,
                    up: r,
                    pr: i
                }), this !== s || a || s.wake()
            }, o.removeEventListener = function(t, e) {
                var n, r = this._listeners[t];
                if (r)
                    for (n = r.length; --n > -1;)
                        if (r[n].c === e) return void r.splice(n, 1)
            }, o.dispatchEvent = function(t) {
                var e, n, r, i = this._listeners[t];
                if (i)
                    for (e = i.length, n = this._eventTarget; --e > -1;) r = i[e], r && (r.up ? r.c.call(r.s || n, {
                        type: t,
                        target: n
                    }) : r.c.call(r.s || n))
            };
            var k = t.requestAnimationFrame,
                S = t.cancelAnimationFrame,
                C = Date.now || function() {
                    return (new Date).getTime()
                },
                P = C();
            for (r = ["ms", "moz", "webkit", "o"], i = r.length; --i > -1 && !k;) k = t[r[i] + "RequestAnimationFrame"], S = t[r[i] + "CancelAnimationFrame"] || t[r[i] + "CancelRequestAnimationFrame"];
            v("Ticker", function(t, e) {
                var n, r, i, o, l, u = this,
                    f = C(),
                    h = e !== !1 && k,
                    d = 500,
                    m = 33,
                    g = "tick",
                    v = function(t) {
                        var e, s, a = C() - P;
                        a > d && (f += a - m), P += a, u.time = (P - f) / 1e3, e = u.time - l, (!n || e > 0 || t === !0) && (u.frame++, l += e + (e >= o ? .004 : o - e), s = !0), t !== !0 && (i = r(v)), s && u.dispatchEvent(g)
                    };
                T.call(u), u.time = u.frame = 0, u.tick = function() {
                    v(!0)
                }, u.lagSmoothing = function(t, e) {
                    d = t || 1 / c, m = Math.min(e, d, 0)
                }, u.sleep = function() {
                    null != i && (h && S ? S(i) : clearTimeout(i), r = p, i = null, u === s && (a = !1))
                }, u.wake = function() {
                    null !== i ? u.sleep() : u.frame > 10 && (P = C() - d + 5), r = 0 === n ? p : h && k ? k : function(t) {
                        return setTimeout(t, 1e3 * (l - u.time) + 1 | 0)
                    }, u === s && (a = !0), v(2)
                }, u.fps = function(t) {
                    return arguments.length ? (n = t, o = 1 / (n || 60), l = this.time + o, void u.wake()) : n
                }, u.useRAF = function(t) {
                    return arguments.length ? (u.sleep(), h = t, void u.fps(n)) : h
                }, u.fps(t), setTimeout(function() {
                    h && (!i || u.frame < 5) && u.useRAF(!1)
                }, 1500)
            }), o = u.Ticker.prototype = new u.events.EventDispatcher, o.constructor = u.Ticker;
            var E = v("core.Animation", function(t, e) {
                if (this.vars = e = e || {}, this._duration = this._totalDuration = t || 0, this._delay = Number(e.delay) || 0, this._timeScale = 1, this._active = e.immediateRender === !0, this.data = e.data, this._reversed = e.reversed === !0, B) {
                    a || s.wake();
                    var n = this.vars.useFrames ? X : B;
                    n.add(this, n._time), this.vars.paused && this.paused(!0)
                }
            });
            s = E.ticker = new u.Ticker, o = E.prototype, o._dirty = o._gc = o._initted = o._paused = !1, o._totalTime = o._time = 0, o._rawPrevTime = -1, o._next = o._last = o._onUpdate = o._timeline = o.timeline = null, o._paused = !1;
            var A = function() {
                a && C() - P > 2e3 && s.wake(), setTimeout(A, 2e3)
            };
            A(), o.play = function(t, e) {
                return null != t && this.seek(t, e), this.reversed(!1).paused(!1)
            }, o.pause = function(t, e) {
                return null != t && this.seek(t, e), this.paused(!0)
            }, o.resume = function(t, e) {
                return null != t && this.seek(t, e), this.paused(!1)
            }, o.seek = function(t, e) {
                return this.totalTime(Number(t), e !== !1)
            }, o.restart = function(t, e) {
                return this.reversed(!1).paused(!1).totalTime(t ? -this._delay : 0, e !== !1, !0)
            }, o.reverse = function(t, e) {
                return null != t && this.seek(t || this.totalDuration(), e), this.reversed(!0).paused(!1)
            }, o.render = function() {}, o.invalidate = function() {
                return this._time = this._totalTime = 0, this._initted = this._gc = !1, this._rawPrevTime = -1, (this._gc || !this.timeline) && this._enabled(!0), this
            }, o.isActive = function() {
                var t, e = this._timeline,
                    n = this._startTime;
                return !e || !this._gc && !this._paused && e.isActive() && (t = e.rawTime()) >= n && t < n + this.totalDuration() / this._timeScale
            }, o._enabled = function(t, e) {
                return a || s.wake(), this._gc = !t, this._active = this.isActive(), e !== !0 && (t && !this.timeline ? this._timeline.add(this, this._startTime - this._delay) : !t && this.timeline && this._timeline._remove(this, !0)), !1
            }, o._kill = function() {
                return this._enabled(!1, !1)
            }, o.kill = function(t, e) {
                return this._kill(t, e), this
            }, o._uncache = function(t) {
                for (var e = t ? this : this.timeline; e;) e._dirty = !0, e = e.timeline;
                return this
            }, o._swapSelfInParams = function(t) {
                for (var e = t.length, n = t.concat(); --e > -1;) "{self}" === t[e] && (n[e] = this);
                return n
            }, o.eventCallback = function(t, e, n, r) {
                if ("on" === (t || "").substr(0, 2)) {
                    var i = this.vars;
                    if (1 === arguments.length) return i[t];
                    null == e ? delete i[t] : (i[t] = e, i[t + "Params"] = h(n) && -1 !== n.join("").indexOf("{self}") ? this._swapSelfInParams(n) : n, i[t + "Scope"] = r), "onUpdate" === t && (this._onUpdate = e)
                }
                return this
            }, o.delay = function(t) {
                return arguments.length ? (this._timeline.smoothChildTiming && this.startTime(this._startTime + t - this._delay), this._delay = t, this) : this._delay
            }, o.duration = function(t) {
                return arguments.length ? (this._duration = this._totalDuration = t, this._uncache(!0), this._timeline.smoothChildTiming && this._time > 0 && this._time < this._duration && 0 !== t && this.totalTime(this._totalTime * (t / this._duration), !0), this) : (this._dirty = !1, this._duration)
            }, o.totalDuration = function(t) {
                return this._dirty = !1, arguments.length ? this.duration(t) : this._totalDuration
            }, o.time = function(t, e) {
                return arguments.length ? (this._dirty && this.totalDuration(), this.totalTime(t > this._duration ? this._duration : t, e)) : this._time
            }, o.totalTime = function(t, e, n) {
                if (a || s.wake(), !arguments.length) return this._totalTime;
                if (this._timeline) {
                    if (0 > t && !n && (t += this.totalDuration()), this._timeline.smoothChildTiming) {
                        this._dirty && this.totalDuration();
                        var r = this._totalDuration,
                            i = this._timeline;
                        if (t > r && !n && (t = r), this._startTime = (this._paused ? this._pauseTime : i._time) - (this._reversed ? r - t : t) / this._timeScale, i._dirty || this._uncache(!1), i._timeline)
                            for (; i._timeline;) i._timeline._time !== (i._startTime + i._totalTime) / i._timeScale && i.totalTime(i._totalTime, !0), i = i._timeline
                    }
                    this._gc && this._enabled(!0, !1), (this._totalTime !== t || 0 === this._duration) && (this.render(t, e, !1), M.length && $())
                }
                return this
            }, o.progress = o.totalProgress = function(t, e) {
                return arguments.length ? this.totalTime(this.duration() * t, e) : this._time / this.duration()
            }, o.startTime = function(t) {
                return arguments.length ? (t !== this._startTime && (this._startTime = t, this.timeline && this.timeline._sortChildren && this.timeline.add(this, t - this._delay)), this) : this._startTime
            }, o.endTime = function(t) {
                return this._startTime + (0 != t ? this.totalDuration() : this.duration()) / this._timeScale
            }, o.timeScale = function(t) {
                if (!arguments.length) return this._timeScale;
                if (t = t || c, this._timeline && this._timeline.smoothChildTiming) {
                    var e = this._pauseTime,
                        n = e || 0 === e ? e : this._timeline.totalTime();
                    this._startTime = n - (n - this._startTime) * this._timeScale / t
                }
                return this._timeScale = t, this._uncache(!1)
            }, o.reversed = function(t) {
                return arguments.length ? (t != this._reversed && (this._reversed = t, this.totalTime(this._timeline && !this._timeline.smoothChildTiming ? this.totalDuration() - this._totalTime : this._totalTime, !0)), this) : this._reversed
            }, o.paused = function(t) {
                if (!arguments.length) return this._paused;
                if (t != this._paused && this._timeline) {
                    a || t || s.wake();
                    var e = this._timeline,
                        n = e.rawTime(),
                        r = n - this._pauseTime;
                    !t && e.smoothChildTiming && (this._startTime += r, this._uncache(!1)), this._pauseTime = t ? n : null, this._paused = t, this._active = this.isActive(), !t && 0 !== r && this._initted && this.duration() && this.render(e.smoothChildTiming ? this._totalTime : (n - this._startTime) / this._timeScale, !0, !0)
                }
                return this._gc && !t && this._enabled(!0, !1), this
            };
            var N = v("core.SimpleTimeline", function(t) {
                E.call(this, 0, t), this.autoRemoveChildren = this.smoothChildTiming = !0
            });
            o = N.prototype = new E, o.constructor = N, o.kill()._gc = !1, o._first = o._last = o._recent = null, o._sortChildren = !1, o.add = o.insert = function(t, e) {
                var n, r;
                if (t._startTime = Number(e || 0) + t._delay, t._paused && this !== t._timeline && (t._pauseTime = t._startTime + (this.rawTime() - t._startTime) / t._timeScale), t.timeline && t.timeline._remove(t, !0), t.timeline = t._timeline = this, t._gc && t._enabled(!0, !0), n = this._last, this._sortChildren)
                    for (r = t._startTime; n && n._startTime > r;) n = n._prev;
                return n ? (t._next = n._next, n._next = t) : (t._next = this._first, this._first = t), t._next ? t._next._prev = t : this._last = t, t._prev = n, this._recent = t, this._timeline && this._uncache(!0), this
            }, o._remove = function(t, e) {
                return t.timeline === this && (e || t._enabled(!1, !0), t._prev ? t._prev._next = t._next : this._first === t && (this._first = t._next), t._next ? t._next._prev = t._prev : this._last === t && (this._last = t._prev), t._next = t._prev = t.timeline = null, t === this._recent && (this._recent = this._last), this._timeline && this._uncache(!0)), this
            }, o.render = function(t, e, n) {
                var r, i = this._first;
                for (this._totalTime = this._time = this._rawPrevTime = t; i;) r = i._next, (i._active || t >= i._startTime && !i._paused) && (i._reversed ? i.render((i._dirty ? i.totalDuration() : i._totalDuration) - (t - i._startTime) * i._timeScale, e, n) : i.render((t - i._startTime) * i._timeScale, e, n)), i = r
            }, o.rawTime = function() {
                return a || s.wake(), this._totalTime
            };
            var O = v("TweenLite", function(e, n, r) {
                    if (E.call(this, n, r), this.render = O.prototype.render, null == e) throw "Cannot tween a null target.";
                    this.target = e = "string" != typeof e ? e : O.selector(e) || e;
                    var i, o, s, a = e.jquery || e.length && e !== t && e[0] && (e[0] === t || e[0].nodeType && e[0].style && !e.nodeType),
                        l = this.vars.overwrite;
                    if (this._overwrite = l = null == l ? z[O.defaultOverwrite] : "number" == typeof l ? l >> 0 : z[l], (a || e instanceof Array || e.push && h(e)) && "number" != typeof e[0])
                        for (this._targets = s = f(e), this._propLookup = [], this._siblings = [], i = 0; i < s.length; i++) o = s[i], o ? "string" != typeof o ? o.length && o !== t && o[0] && (o[0] === t || o[0].nodeType && o[0].style && !o.nodeType) ? (s.splice(i--, 1), this._targets = s = s.concat(f(o))) : (this._siblings[i] = W(o, this, !1), 1 === l && this._siblings[i].length > 1 && U(o, this, null, 1, this._siblings[i])) : (o = s[i--] = O.selector(o), "string" == typeof o && s.splice(i + 1, 1)) : s.splice(i--, 1);
                    else this._propLookup = {}, this._siblings = W(e, this, !1), 1 === l && this._siblings.length > 1 && U(e, this, null, 1, this._siblings);
                    (this.vars.immediateRender || 0 === n && 0 === this._delay && this.vars.immediateRender !== !1) && (this._time = -c, this.render(-this._delay))
                }, !0),
                j = function(e) {
                    return e && e.length && e !== t && e[0] && (e[0] === t || e[0].nodeType && e[0].style && !e.nodeType)
                },
                D = function(t, e) {
                    var n, r = {};
                    for (n in t) I[n] || n in e && "transform" !== n && "x" !== n && "y" !== n && "width" !== n && "height" !== n && "className" !== n && "border" !== n || !(!F[n] || F[n] && F[n]._autoCSS) || (r[n] = t[n], delete t[n]);
                    t.css = r
                };
            o = O.prototype = new E, o.constructor = O, o.kill()._gc = !1, o.ratio = 0, o._firstPT = o._targets = o._overwrittenProps = o._startAt = null, o._notifyPluginsOfEnabled = o._lazy = !1, O.version = "1.15.1", O.defaultEase = o._ease = new x(null, null, 1, 1), O.defaultOverwrite = "auto", O.ticker = s, O.autoSleep = !0, O.lagSmoothing = function(t, e) {
                s.lagSmoothing(t, e)
            }, O.selector = t.$ || t.jQuery || function(e) {
                var n = t.$ || t.jQuery;
                return n ? (O.selector = n, n(e)) : "undefined" == typeof document ? e : document.querySelectorAll ? document.querySelectorAll(e) : document.getElementById("#" === e.charAt(0) ? e.substr(1) : e)
            };
            var M = [],
                L = {},
                R = O._internals = {
                    isArray: h,
                    isSelector: j,
                    lazyTweens: M
                },
                F = O._plugins = {},
                q = R.tweenLookup = {},
                H = 0,
                I = R.reservedProps = {
                    ease: 1,
                    delay: 1,
                    overwrite: 1,
                    onComplete: 1,
                    onCompleteParams: 1,
                    onCompleteScope: 1,
                    useFrames: 1,
                    runBackwards: 1,
                    startAt: 1,
                    onUpdate: 1,
                    onUpdateParams: 1,
                    onUpdateScope: 1,
                    onStart: 1,
                    onStartParams: 1,
                    onStartScope: 1,
                    onReverseComplete: 1,
                    onReverseCompleteParams: 1,
                    onReverseCompleteScope: 1,
                    onRepeat: 1,
                    onRepeatParams: 1,
                    onRepeatScope: 1,
                    easeParams: 1,
                    yoyo: 1,
                    immediateRender: 1,
                    repeat: 1,
                    repeatDelay: 1,
                    data: 1,
                    paused: 1,
                    reversed: 1,
                    autoCSS: 1,
                    lazy: 1,
                    onOverwrite: 1
                },
                z = {
                    none: 0,
                    all: 1,
                    auto: 2,
                    concurrent: 3,
                    allOnStart: 4,
                    preexisting: 5,
                    "true": 1,
                    "false": 0
                },
                X = E._rootFramesTimeline = new N,
                B = E._rootTimeline = new N,
                $ = R.lazyRender = function() {
                    var t, e = M.length;
                    for (L = {}; --e > -1;) t = M[e], t && t._lazy !== !1 && (t.render(t._lazy[0], t._lazy[1], !0), t._lazy = !1);
                    M.length = 0
                };
            B._startTime = s.time, X._startTime = s.frame, B._active = X._active = !0, setTimeout($, 1), E._updateRoot = O.render = function() {
                var t, e, n;
                if (M.length && $(), B.render((s.time - B._startTime) * B._timeScale, !1, !1), X.render((s.frame - X._startTime) * X._timeScale, !1, !1), M.length && $(), !(s.frame % 120)) {
                    for (n in q) {
                        for (e = q[n].tweens, t = e.length; --t > -1;) e[t]._gc && e.splice(t, 1);
                        0 === e.length && delete q[n]
                    }
                    if (n = B._first, (!n || n._paused) && O.autoSleep && !X._first && 1 === s._listeners.tick.length) {
                        for (; n && n._paused;) n = n._next;
                        n || s.sleep()
                    }
                }
            }, s.addEventListener("tick", E._updateRoot);
            var W = function(t, e, n) {
                    var r, i, o = t._gsTweenID;
                    if (q[o || (t._gsTweenID = o = "t" + H++)] || (q[o] = {
                            target: t,
                            tweens: []
                        }), e && (r = q[o].tweens, r[i = r.length] = e, n))
                        for (; --i > -1;) r[i] === e && r.splice(i, 1);
                    return q[o].tweens
                },
                Y = function(t, e, n, r) {
                    var i, o, s = t.vars.onOverwrite;
                    return s && (i = s(t, e, n, r)), s = O.onOverwrite, s && (o = s(t, e, n, r)), i !== !1 && o !== !1
                },
                U = function(t, e, n, r, i) {
                    var o, s, a, l;
                    if (1 === r || r >= 4) {
                        for (l = i.length, o = 0; l > o; o++)
                            if ((a = i[o]) !== e) a._gc || Y(a, e) && a._enabled(!1, !1) && (s = !0);
                            else if (5 === r) break;
                        return s
                    }
                    var u, f = e._startTime + c,
                        p = [],
                        h = 0,
                        d = 0 === e._duration;
                    for (o = i.length; --o > -1;)(a = i[o]) === e || a._gc || a._paused || (a._timeline !== e._timeline ? (u = u || V(e, 0, d), 0 === V(a, u, d) && (p[h++] = a)) : a._startTime <= f && a._startTime + a.totalDuration() / a._timeScale > f && ((d || !a._initted) && f - a._startTime <= 2e-10 || (p[h++] = a)));
                    for (o = h; --o > -1;)
                        if (a = p[o], 2 === r && a._kill(n, t, e) && (s = !0), 2 !== r || !a._firstPT && a._initted) {
                            if (2 !== r && !Y(a, e)) continue;
                            a._enabled(!1, !1) && (s = !0)
                        }
                    return s
                },
                V = function(t, e, n) {
                    for (var r = t._timeline, i = r._timeScale, o = t._startTime; r._timeline;) {
                        if (o += r._startTime, i *= r._timeScale, r._paused) return -100;
                        r = r._timeline
                    }
                    return o /= i, o > e ? o - e : n && o === e || !t._initted && 2 * c > o - e ? c : (o += t.totalDuration() / t._timeScale / i) > e + c ? 0 : o - e - c
                };
            o._init = function() {
                var t, e, n, r, i, o = this.vars,
                    s = this._overwrittenProps,
                    a = this._duration,
                    l = !!o.immediateRender,
                    u = o.ease;
                if (o.startAt) {
                    this._startAt && (this._startAt.render(-1, !0), this._startAt.kill()), i = {};
                    for (r in o.startAt) i[r] = o.startAt[r];
                    if (i.overwrite = !1, i.immediateRender = !0, i.lazy = l && o.lazy !== !1, i.startAt = i.delay = null, this._startAt = O.to(this.target, 0, i), l)
                        if (this._time > 0) this._startAt = null;
                        else if (0 !== a) return
                } else if (o.runBackwards && 0 !== a)
                    if (this._startAt) this._startAt.render(-1, !0), this._startAt.kill(), this._startAt = null;
                    else {
                        0 !== this._time && (l = !1), n = {};
                        for (r in o) I[r] && "autoCSS" !== r || (n[r] = o[r]);
                        if (n.overwrite = 0, n.data = "isFromStart", n.lazy = l && o.lazy !== !1, n.immediateRender = l, this._startAt = O.to(this.target, 0, n), l) {
                            if (0 === this._time) return
                        } else this._startAt._init(), this._startAt._enabled(!1), this.vars.immediateRender && (this._startAt = null)
                    }
                if (this._ease = u = u ? u instanceof x ? u : "function" == typeof u ? new x(u, o.easeParams) : b[u] || O.defaultEase : O.defaultEase, o.easeParams instanceof Array && u.config && (this._ease = u.config.apply(u, o.easeParams)), this._easeType = this._ease._type, this._easePower = this._ease._power, this._firstPT = null, this._targets)
                    for (t = this._targets.length; --t > -1;) this._initProps(this._targets[t], this._propLookup[t] = {}, this._siblings[t], s ? s[t] : null) && (e = !0);
                else e = this._initProps(this.target, this._propLookup, this._siblings, s);
                if (e && O._onPluginEvent("_onInitAllProps", this), s && (this._firstPT || "function" != typeof this.target && this._enabled(!1, !1)), o.runBackwards)
                    for (n = this._firstPT; n;) n.s += n.c, n.c = -n.c, n = n._next;
                this._onUpdate = o.onUpdate, this._initted = !0
            }, o._initProps = function(e, n, r, i) {
                var o, s, a, l, u, c;
                if (null == e) return !1;
                L[e._gsTweenID] && $(), this.vars.css || e.style && e !== t && e.nodeType && F.css && this.vars.autoCSS !== !1 && D(this.vars, e);
                for (o in this.vars) {
                    if (c = this.vars[o], I[o]) c && (c instanceof Array || c.push && h(c)) && -1 !== c.join("").indexOf("{self}") && (this.vars[o] = c = this._swapSelfInParams(c, this));
                    else if (F[o] && (l = new F[o])._onInitTween(e, this.vars[o], this)) {
                        for (this._firstPT = u = {
                                _next: this._firstPT,
                                t: l,
                                p: "setRatio",
                                s: 0,
                                c: 1,
                                f: !0,
                                n: o,
                                pg: !0,
                                pr: l._priority
                            }, s = l._overwriteProps.length; --s > -1;) n[l._overwriteProps[s]] = this._firstPT;
                        (l._priority || l._onInitAllProps) && (a = !0), (l._onDisable || l._onEnable) && (this._notifyPluginsOfEnabled = !0)
                    } else this._firstPT = n[o] = u = {
                        _next: this._firstPT,
                        t: e,
                        p: o,
                        f: "function" == typeof e[o],
                        n: o,
                        pg: !1,
                        pr: 0
                    }, u.s = u.f ? e[o.indexOf("set") || "function" != typeof e["get" + o.substr(3)] ? o : "get" + o.substr(3)]() : parseFloat(e[o]), u.c = "string" == typeof c && "=" === c.charAt(1) ? parseInt(c.charAt(0) + "1", 10) * Number(c.substr(2)) : Number(c) - u.s || 0;
                    u && u._next && (u._next._prev = u)
                }
                return i && this._kill(i, e) ? this._initProps(e, n, r, i) : this._overwrite > 1 && this._firstPT && r.length > 1 && U(e, this, n, this._overwrite, r) ? (this._kill(n, e), this._initProps(e, n, r, i)) : (this._firstPT && (this.vars.lazy !== !1 && this._duration || this.vars.lazy && !this._duration) && (L[e._gsTweenID] = !0), a)
            }, o.render = function(t, e, n) {
                var r, i, o, s, a = this._time,
                    l = this._duration,
                    u = this._rawPrevTime;
                if (t >= l) this._totalTime = this._time = l, this.ratio = this._ease._calcEnd ? this._ease.getRatio(1) : 1, this._reversed || (r = !0, i = "onComplete"), 0 === l && (this._initted || !this.vars.lazy || n) && (this._startTime === this._timeline._duration && (t = 0), (0 === t || 0 > u || u === c && "isPause" !== this.data) && u !== t && (n = !0, u > c && (i = "onReverseComplete")), this._rawPrevTime = s = !e || t || u === t ? t : c);
                else if (1e-7 > t) this._totalTime = this._time = 0, this.ratio = this._ease._calcEnd ? this._ease.getRatio(0) : 0, (0 !== a || 0 === l && u > 0 && u !== c) && (i = "onReverseComplete", r = this._reversed), 0 > t && (this._active = !1, 0 === l && (this._initted || !this.vars.lazy || n) && (u >= 0 && (u !== c || "isPause" !== this.data) && (n = !0), this._rawPrevTime = s = !e || t || u === t ? t : c)), this._initted || (n = !0);
                else if (this._totalTime = this._time = t, this._easeType) {
                    var f = t / l,
                        p = this._easeType,
                        h = this._easePower;
                    (1 === p || 3 === p && f >= .5) && (f = 1 - f), 3 === p && (f *= 2), 1 === h ? f *= f : 2 === h ? f *= f * f : 3 === h ? f *= f * f * f : 4 === h && (f *= f * f * f * f), this.ratio = 1 === p ? 1 - f : 2 === p ? f : .5 > t / l ? f / 2 : 1 - f / 2
                } else this.ratio = this._ease.getRatio(t / l);
                if (this._time !== a || n) {
                    if (!this._initted) {
                        if (this._init(), !this._initted || this._gc) return;
                        if (!n && this._firstPT && (this.vars.lazy !== !1 && this._duration || this.vars.lazy && !this._duration)) return this._time = this._totalTime = a, this._rawPrevTime = u, M.push(this), void(this._lazy = [t, e]);
                        this._time && !r ? this.ratio = this._ease.getRatio(this._time / l) : r && this._ease._calcEnd && (this.ratio = this._ease.getRatio(0 === this._time ? 0 : 1))
                    }
                    for (this._lazy !== !1 && (this._lazy = !1), this._active || !this._paused && this._time !== a && t >= 0 && (this._active = !0), 0 === a && (this._startAt && (t >= 0 ? this._startAt.render(t, e, n) : i || (i = "_dummyGS")), this.vars.onStart && (0 !== this._time || 0 === l) && (e || this.vars.onStart.apply(this.vars.onStartScope || this, this.vars.onStartParams || _))), o = this._firstPT; o;) o.f ? o.t[o.p](o.c * this.ratio + o.s) : o.t[o.p] = o.c * this.ratio + o.s, o = o._next;
                    this._onUpdate && (0 > t && this._startAt && t !== -1e-4 && this._startAt.render(t, e, n), e || (this._time !== a || r) && this._onUpdate.apply(this.vars.onUpdateScope || this, this.vars.onUpdateParams || _)), i && (!this._gc || n) && (0 > t && this._startAt && !this._onUpdate && t !== -1e-4 && this._startAt.render(t, e, n), r && (this._timeline.autoRemoveChildren && this._enabled(!1, !1), this._active = !1), !e && this.vars[i] && this.vars[i].apply(this.vars[i + "Scope"] || this, this.vars[i + "Params"] || _), 0 === l && this._rawPrevTime === c && s !== c && (this._rawPrevTime = 0))
                }
            }, o._kill = function(t, e, n) {
                if ("all" === t && (t = null), null == t && (null == e || e === this.target)) return this._lazy = !1, this._enabled(!1, !1);
                e = "string" != typeof e ? e || this._targets || this.target : O.selector(e) || e;
                var r, i, o, s, a, l, u, c, f;
                if ((h(e) || j(e)) && "number" != typeof e[0])
                    for (r = e.length; --r > -1;) this._kill(t, e[r]) && (l = !0);
                else {
                    if (this._targets) {
                        for (r = this._targets.length; --r > -1;)
                            if (e === this._targets[r]) {
                                a = this._propLookup[r] || {}, this._overwrittenProps = this._overwrittenProps || [], i = this._overwrittenProps[r] = t ? this._overwrittenProps[r] || {} : "all";
                                break
                            }
                    } else {
                        if (e !== this.target) return !1;
                        a = this._propLookup, i = this._overwrittenProps = t ? this._overwrittenProps || {} : "all"
                    }
                    if (a) {
                        if (u = t || a, c = t !== i && "all" !== i && t !== a && ("object" != typeof t || !t._tempKill), n && (O.onOverwrite || this.vars.onOverwrite)) {
                            for (o in u) a[o] && (f || (f = []), f.push(o));
                            if (!Y(this, n, e, f)) return !1
                        }
                        for (o in u)(s = a[o]) && (s.pg && s.t._kill(u) && (l = !0), s.pg && 0 !== s.t._overwriteProps.length || (s._prev ? s._prev._next = s._next : s === this._firstPT && (this._firstPT = s._next), s._next && (s._next._prev = s._prev), s._next = s._prev = null), delete a[o]), c && (i[o] = 1);
                        !this._firstPT && this._initted && this._enabled(!1, !1)
                    }
                }
                return l
            }, o.invalidate = function() {
                return this._notifyPluginsOfEnabled && O._onPluginEvent("_onDisable", this), this._firstPT = this._overwrittenProps = this._startAt = this._onUpdate = null, this._notifyPluginsOfEnabled = this._active = this._lazy = !1, this._propLookup = this._targets ? {} : [], E.prototype.invalidate.call(this), this.vars.immediateRender && (this._time = -c, this.render(-this._delay)), this
            }, o._enabled = function(t, e) {
                if (a || s.wake(), t && this._gc) {
                    var n, r = this._targets;
                    if (r)
                        for (n = r.length; --n > -1;) this._siblings[n] = W(r[n], this, !0);
                    else this._siblings = W(this.target, this, !0)
                }
                return E.prototype._enabled.call(this, t, e), this._notifyPluginsOfEnabled && this._firstPT ? O._onPluginEvent(t ? "_onEnable" : "_onDisable", this) : !1
            }, O.to = function(t, e, n) {
                return new O(t, e, n)
            }, O.from = function(t, e, n) {
                return n.runBackwards = !0, n.immediateRender = 0 != n.immediateRender, new O(t, e, n)
            }, O.fromTo = function(t, e, n, r) {
                return r.startAt = n, r.immediateRender = 0 != r.immediateRender && 0 != n.immediateRender, new O(t, e, r)
            }, O.delayedCall = function(t, e, n, r, i) {
                return new O(e, 0, {
                    delay: t,
                    onComplete: e,
                    onCompleteParams: n,
                    onCompleteScope: r,
                    onReverseComplete: e,
                    onReverseCompleteParams: n,
                    onReverseCompleteScope: r,
                    immediateRender: !1,
                    lazy: !1,
                    useFrames: i,
                    overwrite: 0
                })
            }, O.set = function(t, e) {
                return new O(t, 0, e)
            }, O.getTweensOf = function(t, e) {
                if (null == t) return [];
                t = "string" != typeof t ? t : O.selector(t) || t;
                var n, r, i, o;
                if ((h(t) || j(t)) && "number" != typeof t[0]) {
                    for (n = t.length, r = []; --n > -1;) r = r.concat(O.getTweensOf(t[n], e));
                    for (n = r.length; --n > -1;)
                        for (o = r[n], i = n; --i > -1;) o === r[i] && r.splice(n, 1)
                } else
                    for (r = W(t).concat(), n = r.length; --n > -1;)(r[n]._gc || e && !r[n].isActive()) && r.splice(n, 1);
                return r
            }, O.killTweensOf = O.killDelayedCallsTo = function(t, e, n) {
                "object" == typeof e && (n = e, e = !1);
                for (var r = O.getTweensOf(t, e), i = r.length; --i > -1;) r[i]._kill(n, t)
            };
            var Q = v("plugins.TweenPlugin", function(t, e) {
                this._overwriteProps = (t || "").split(","), this._propName = this._overwriteProps[0], this._priority = e || 0, this._super = Q.prototype
            }, !0);
            if (o = Q.prototype, Q.version = "1.10.1", Q.API = 2, o._firstPT = null, o._addTween = function(t, e, n, r, i, o) {
                    var s, a;
                    return null != r && (s = "number" == typeof r || "=" !== r.charAt(1) ? Number(r) - n : parseInt(r.charAt(0) + "1", 10) * Number(r.substr(2))) ? (this._firstPT = a = {
                        _next: this._firstPT,
                        t: t,
                        p: e,
                        s: n,
                        c: s,
                        f: "function" == typeof t[e],
                        n: i || e,
                        r: o
                    }, a._next && (a._next._prev = a), a) : void 0
                }, o.setRatio = function(t) {
                    for (var e, n = this._firstPT, r = 1e-6; n;) e = n.c * t + n.s, n.r ? e = Math.round(e) : r > e && e > -r && (e = 0), n.f ? n.t[n.p](e) : n.t[n.p] = e, n = n._next
                }, o._kill = function(t) {
                    var e, n = this._overwriteProps,
                        r = this._firstPT;
                    if (null != t[this._propName]) this._overwriteProps = [];
                    else
                        for (e = n.length; --e > -1;) null != t[n[e]] && n.splice(e, 1);
                    for (; r;) null != t[r.n] && (r._next && (r._next._prev = r._prev), r._prev ? (r._prev._next = r._next, r._prev = null) : this._firstPT === r && (this._firstPT = r._next)), r = r._next;
                    return !1
                }, o._roundProps = function(t, e) {
                    for (var n = this._firstPT; n;)(t[this._propName] || null != n.n && t[n.n.split(this._propName + "_").join("")]) && (n.r = e), n = n._next
                }, O._onPluginEvent = function(t, e) {
                    var n, r, i, o, s, a = e._firstPT;
                    if ("_onInitAllProps" === t) {
                        for (; a;) {
                            for (s = a._next, r = i; r && r.pr > a.pr;) r = r._next;
                            (a._prev = r ? r._prev : o) ? a._prev._next = a: i = a, (a._next = r) ? r._prev = a : o = a, a = s
                        }
                        a = e._firstPT = i
                    }
                    for (; a;) a.pg && "function" == typeof a.t[t] && a.t[t]() && (n = !0), a = a._next;
                    return n
                }, Q.activate = function(t) {
                    for (var e = t.length; --e > -1;) t[e].API === Q.API && (F[(new t[e])._propName] = t[e]);
                    return !0
                }, g.plugin = function(t) {
                    if (!(t && t.propName && t.init && t.API)) throw "illegal plugin definition.";
                    var e, n = t.propName,
                        r = t.priority || 0,
                        i = t.overwriteProps,
                        o = {
                            init: "_onInitTween",
                            set: "setRatio",
                            kill: "_kill",
                            round: "_roundProps",
                            initAll: "_onInitAllProps"
                        },
                        s = v("plugins." + n.charAt(0).toUpperCase() + n.substr(1) + "Plugin", function() {
                            Q.call(this, n, r), this._overwriteProps = i || []
                        }, t.global === !0),
                        a = s.prototype = new Q(n);
                    a.constructor = s, s.API = t.API;
                    for (e in o) "function" == typeof t[e] && (a[o[e]] = t[e]);
                    return s.version = t.version, Q.activate([s]), s
                }, r = t._gsQueue) {
                for (i = 0; i < r.length; i++) r[i]();
                for (o in d) d[o].func || t.console.log("GSAP encountered missing dependency: com.greensock." + o)
            }
            a = !1
        }
    }("undefined" != typeof module && module.exports && "undefined" != typeof global ? global : this || window, "TweenLite"),
    function() {
        var t, e, n = function(t, e) {
            return function() {
                return t.apply(e, arguments)
            }
        };
        e = "undefined" != typeof exports && null !== exports ? exports : this, t = function() {
            function t(t) {
                this.reflow = n(this.reflow, this), this.article_cards = t.data("loaded", !0), this.display_mode = "default", this.register_events()
            }
            return t.init = function() {
                var e;
                return e = $(".article-card"), e.length > 0 ? new t(e) : void 0
            }, t.prototype.register_events = function() {
                var t;
                return this.article_cards.find("img").load(this.reflow), enquire.register("screen and (max-width: 959px)", {
                    match: function(t) {
                        return function() {
                            return t.display_mode = "mobile", t.reset_heights()
                        }
                    }(this)
                }), enquire.register("screen and (min-width: 960px)", {
                    match: function(t) {
                        return function() {
                            return t.display_mode = "desktop", t.reflow()
                        }
                    }(this)
                }), enquire.register("screen and (min-width: 1260px)", {
                    match: function(t) {
                        return function() {
                            return t.display_mode = "large-desktop", t.reflow()
                        }
                    }(this),
                    unmatch: function(t) {
                        return function() {
                            return t.display_mode = "desktop", t.reflow()
                        }
                    }(this)
                }), TweenLite.defaultEase = Sine.easeOut, t = function(t) {
                    var e;
                    return t.data("components") ? e = t.data("components") : (e = {
                        photo: t.find(".cover-image"),
                        title: t.find(".content"),
                        rider: t.find(".rider"),
                        metadata: t.find(".metadata")
                    }, t.data("components", e)), e
                }, $(".articles-list").on("mouseenter", ".article-card", function(e) {
                    return function(n) {
                        var r, i, o, s, a, l, u, c;
                        if ("mobile" !== e.display_mode) return r = $(n.currentTarget), o = t(r), a = e.display_mode + "-distances", r.data(a) ? s = r.data(a) : (i = r.outerHeight(), u = o.rider.outerHeight(), l = o.metadata.outerHeight(), c = o.title.position().top + o.title.outerHeight(), r.data(a, s = {
                            rider: -(u + l),
                            title: Math.min(0, i - u - l - c)
                        })), TweenLite.to(o.rider, .2, {
                            y: s.rider
                        }), TweenLite.to(o.title, .2, {
                            y: s.title
                        }), TweenLite.to(o.photo, .2, {
                            y: s.title / 2
                        })
                    }
                }(this)), $(".articles-list").on("mouseleave", ".article-card", function(e) {
                    var n, r;
                    return n = $(e.currentTarget), r = t(n), TweenLite.to([r.rider, r.title, r.photo], .4, {
                        y: 0,
                        delay: .25,
                        ease: Sine.easeIn
                    })
                })
            }, t.prototype.reset_heights = function() {
                return this.article_cards.each(function() {
                    return $(this).height("auto")
                })
            }, t.prototype.reflow = function() {
                return this.d || (this.d = debounce(function(t) {
                    return function() {
                        return t.reset_heights(), "mobile" !== t.display_mode ? t.article_cards.height(t.article_cards.maxHeight()) : void 0
                    }
                }(this))), this.d()
            }, t
        }(), on_page_load(function() {
            var e, n;
            return t.init(), e = $(".load-more a"), n = e.data("total-pages"), e.on("ajax:before", function() {
                return e.data("disabled") === !0 ? !1 : void 0
            }).on("ajax:send", function() {
                return e.data("disabled", !0)
            }).on("ajax:complete", function() {
                return e.data("disabled", !1)
            }).on("ajax:success", function(r, i) {
                var o, s;
                return $(".articles-list").append(i), o = +e.attr("href").match(/page\/([0-9]+)/)[1], n > o ? (s = Math.min(o + 1, n), e.attr("href", e.attr("href").replace(/page\/[0-9]+/, "page/" + s))) : e.hide(), t.init(), $(document.body).trigger("sticky_kit:recalc")
            })
        })
    }.call(this),
    function() {
        var t, e;
        t = this.jQuery || window.jQuery, e = t(window), t.fn.stick_in_parent = function(n) {
            var r, i, o, s, a, l, u, c, f, p;
            for (null == n && (n = {}), u = n.sticky_class, i = n.inner_scrolling, l = n.recalc_every, a = n.parent, s = n.offset_top, o = n.spacer, r = n.bottoming, null == s && (s = 0), null == a && (a = void 0), null == i && (i = !0), null == u && (u = "is_stuck"), null == r && (r = !0), c = function(n, c, f, p, h, d, m, g) {
                    var v, y, _, x, b, w, T, k, S, C, P;
                    if (!n.data("sticky_kit")) {
                        if (n.data("sticky_kit", !0), w = n.parent(), null != a && (w = w.closest(a)), !w.length) throw "failed to find stick parent";
                        if (v = _ = !1, (C = null != o ? o && n.closest(o) : t("<div />")) && C.css("position", n.css("position")), T = function() {
                                var t, e, r;
                                return !g && (t = parseInt(w.css("border-top-width"), 10), e = parseInt(w.css("padding-top"), 10), c = parseInt(w.css("padding-bottom"), 10), f = w.offset().top + t + e, p = w.height(), _ && (v = _ = !1, null == o && (n.insertAfter(C), C.detach()), n.css({
                                    position: "",
                                    top: "",
                                    width: "",
                                    bottom: ""
                                }).removeClass(u), r = !0), h = n.offset().top - parseInt(n.css("margin-top"), 10) - s, d = n.outerHeight(!0), m = n.css("float"), C && C.css({
                                    width: n.outerWidth(!0),
                                    height: d,
                                    display: n.css("display"),
                                    "vertical-align": n.css("vertical-align"),
                                    "float": m
                                }), r) ? P() : void 0
                            }, T(), d !== p) return x = void 0, b = s, S = l, P = function() {
                            var t, a, y, k;
                            return !g && (null != S && (--S, 0 >= S && (S = l, T())), y = e.scrollTop(), null != x && (a = y - x), x = y, _ ? (r && (k = y + d + b > p + f, v && !k && (v = !1, n.css({
                                position: "fixed",
                                bottom: "",
                                top: b
                            }).trigger("sticky_kit:unbottom"))), h > y && (_ = !1, b = s, null == o && ("left" !== m && "right" !== m || n.insertAfter(C), C.detach()), t = {
                                position: "",
                                width: "",
                                top: ""
                            }, n.css(t).removeClass(u).trigger("sticky_kit:unstick")), i && (t = e.height(), d + s > t && !v && (b -= a, b = Math.max(t - d, b), b = Math.min(s, b), _ && n.css({
                                top: b + "px"
                            })))) : y > h && (_ = !0, t = {
                                position: "fixed",
                                top: b
                            }, t.width = "border-box" === n.css("box-sizing") ? n.outerWidth() + "px" : n.width() + "px", n.css(t).addClass(u), null == o && (n.after(C), "left" !== m && "right" !== m || C.append(n)), n.trigger("sticky_kit:stick")), _ && r && (null == k && (k = y + d + b > p + f), !v && k)) ? (v = !0, "static" === w.css("position") && w.css({
                                position: "relative"
                            }), n.css({
                                position: "absolute",
                                bottom: c,
                                top: "auto"
                            }).trigger("sticky_kit:bottom")) : void 0
                        }, k = function() {
                            return T(), P()
                        }, y = function() {
                            return g = !0, e.off("touchmove", P), e.off("scroll", P), e.off("resize", k), t(document.body).off("sticky_kit:recalc", k), n.off("sticky_kit:detach", y), n.removeData("sticky_kit"), n.css({
                                position: "",
                                bottom: "",
                                top: "",
                                width: ""
                            }), w.position("position", ""), _ ? (null == o && ("left" !== m && "right" !== m || n.insertAfter(C), C.remove()), n.removeClass(u)) : void 0
                        }, e.on("touchmove", P), e.on("scroll", P), e.on("resize", k), t(document.body).on("sticky_kit:recalc", k), n.on("sticky_kit:detach", y), setTimeout(P, 0)
                    }
                }, f = 0, p = this.length; p > f; f++) n = this[f], c(t(n));
            return this
        }
    }.call(this),
    function() {
        var t;
        t = "undefined" != typeof exports && null !== exports ? exports : this, t.on_page_load(function() {
            return $(".sidebar.sticky").stick_in_parent({
                recalc_every: 50
            })
        })
    }.call(this),
    function() {
        var t, e, n, r, i, o, s, a, l, u, c, f, p, h, d, m, g, v, y, _, x, b, w, T, k, S, C, P, E, A, N, O, j, D, M, L, R, F, q, H, I, z, X, B, $, W, Y, U, V, Q, G, Z, K, J, te, ee, ne, re, ie, oe, se = [].indexOf || function(t) {
                for (var e = 0, n = this.length; n > e; e++)
                    if (e in this && this[e] === t) return e;
                return -1
            },
            ae = [].slice;
        R = {}, c = 10, te = !1, m = null, j = null, S = ["html"], X = null, h = null, ie = null, x = function(t) {
            var e;
            return U(), u(), B(t), te && (e = ee(t)) ? (b(e), w(t)) : w(t, K)
        }, ee = function(t) {
            var e;
            return e = R[t], e && !e.transitionCacheDisabled ? e : void 0
        }, g = function(t) {
            return null == t && (t = !0), te = t
        }, w = function(t, e) {
            return null == e && (e = function() {
                return function() {}
            }(this)), ne("page:fetch", {
                url: t
            }), null != ie && ie.abort(), ie = new XMLHttpRequest, ie.open("GET", Q(t), !0), ie.setRequestHeader("Accept", "text/html, application/xhtml+xml, application/xml"), ie.setRequestHeader("X-XHR-Referer", X), ie.onload = function() {
                var n;
                return ne("page:receive"), (n = I()) ? (f.apply(null, _(n)), $(), e(), ne("page:load")) : document.location.href = t
            }, ie.onloadend = function() {
                return ie = null
            }, ie.onerror = function() {
                return document.location.href = t
            }, ie.send()
        }, b = function(t) {
            return null != ie && ie.abort(), f(t.title, t.body), z(t), ne("page:restore")
        }, u = function() {
            return R[m.url] = {
                url: document.location.href,
                body: document.body,
                title: document.title,
                positionY: window.pageYOffset,
                positionX: window.pageXOffset,
                cachedAt: (new Date).getTime(),
                transitionCacheDisabled: null != document.querySelector("[data-no-transition-cache]")
            }, p(c)
        }, q = function(t) {
            return null == t && (t = c), /^[\d]+$/.test(t) ? c = parseInt(t) : void 0
        }, p = function(t) {
            var e, n, r, i, o, s;
            for (r = Object.keys(R), e = r.map(function(t) {
                    return R[t].cachedAt
                }).sort(function(t, e) {
                    return e - t
                }), s = [], i = 0, o = r.length; o > i; i++) n = r[i], R[n].cachedAt <= e[t] && (ne("page:expire", R[n]), s.push(delete R[n]));
            return s
        }, f = function(e, n, r, i) {
            return document.title = e, document.documentElement.replaceChild(n, document.body), null != r && t.update(r), i && v(), m = window.history.state, ne("page:change"), ne("page:update")
        }, v = function() {
            var t, e, n, r, i, o, s, a, l, u, c, f;
            for (o = Array.prototype.slice.call(document.body.querySelectorAll('script:not([data-turbolinks-eval="false"])')), s = 0, l = o.length; l > s; s++)
                if (i = o[s], "" === (c = i.type) || "text/javascript" === c) {
                    for (e = document.createElement("script"), f = i.attributes, a = 0, u = f.length; u > a; a++) t = f[a], e.setAttribute(t.name, t.value);
                    e.appendChild(document.createTextNode(i.innerHTML)), r = i.parentNode, n = i.nextSibling, r.removeChild(i), r.insertBefore(e, n)
                }
        }, G = function(t) {
            return t.innerHTML = t.innerHTML.replace(/<noscript[\S\s]*?<\/noscript>/gi, ""), t
        }, B = function(t) {
            return t !== X ? window.history.pushState({
                turbolinks: !0,
                url: t
            }, "", t) : void 0
        }, $ = function() {
            var t, e;
            return (t = ie.getResponseHeader("X-XHR-Redirected-To")) ? (e = V(t) === t ? document.location.hash : "", window.history.replaceState(m, "", t + e)) : void 0
        }, U = function() {
            return X = document.location.href
        }, Y = function() {
            return window.history.replaceState({
                turbolinks: !0,
                url: document.location.href
            }, "", document.location.href)
        }, W = function() {
            return m = window.history.state
        }, z = function(t) {
            return window.scrollTo(t.positionX, t.positionY)
        }, K = function() {
            return document.location.hash ? document.location.href = document.location.href : window.scrollTo(0, 0)
        }, Q = function(t) {
            return V(t)
        }, V = function(t) {
            var e;
            return e = t, null == t.href && (e = document.createElement("A"), e.href = t), e.href.replace(e.hash, "")
        }, H = function(t) {
            var e, n;
            return e = (null != (n = document.cookie.match(new RegExp(t + "=(\\w+)"))) ? n[1].toUpperCase() : void 0) || "", document.cookie = t + "=; expires=Thu, 01-Jan-70 00:00:01 GMT; path=/", e
        }, ne = function(t, e) {
            var n;
            return n = document.createEvent("Events"), e && (n.data = e), n.initEvent(t, !0, !0), document.dispatchEvent(n)
        }, F = function() {
            return !ne("page:before-change")
        }, I = function() {
            var t, e, n, r, i, o;
            return e = function() {
                var t;
                return 400 <= (t = ie.status) && 600 > t
            }, o = function() {
                return ie.getResponseHeader("Content-Type").match(/^(?:text\/html|application\/xhtml\+xml|application\/xml)(?:;|$)/)
            }, r = function(t) {
                var e, n, r, i, o;
                for (i = t.head.childNodes, o = [], n = 0, r = i.length; r > n; n++) e = i[n], null != ("function" == typeof e.getAttribute ? e.getAttribute("data-turbolinks-track") : void 0) && o.push(e.getAttribute("src") || e.getAttribute("href"));
                return o
            }, t = function(t) {
                var e;
                return j || (j = r(document)), e = r(t), e.length !== j.length || i(e, j).length !== j.length
            }, i = function(t, e) {
                var n, r, i, o, s;
                for (t.length > e.length && (o = [e, t], t = o[0], e = o[1]), s = [], r = 0, i = t.length; i > r; r++) n = t[r], se.call(e, n) >= 0 && s.push(n);
                return s
            }, !e() && o() && (n = h(ie.responseText), n && !t(n)) ? n : void 0
        }, _ = function(e) {
            var n;
            return n = e.querySelector("title"), [null != n ? n.textContent : void 0, G(e.body), t.get(e).token, "runScripts"]
        }, t = {
            get: function(t) {
                var e;
                return null == t && (t = document), {
                    node: e = t.querySelector('meta[name="csrf-token"]'),
                    token: null != e && "function" == typeof e.getAttribute ? e.getAttribute("content") : void 0
                }
            },
            update: function(t) {
                var e;
                return e = this.get(), null != e.token && null != t && e.token !== t ? e.node.setAttribute("content", t) : void 0
            }
        }, r = function() {
            var t, e, n, r, i, o;
            e = function(t) {
                return (new DOMParser).parseFromString(t, "text/html")
            }, t = function(t) {
                var e;
                return e = document.implementation.createHTMLDocument(""), e.documentElement.innerHTML = t, e
            }, n = function(t) {
                var e;
                return e = document.implementation.createHTMLDocument(""), e.open("replace"), e.write(t), e.close(), e
            };
            try {
                if (window.DOMParser) return i = e("<html><body><p>test"), e
            } catch (s) {
                return r = s, i = t("<html><body><p>test"), t
            } finally {
                if (1 !== (null != i && null != (o = i.body) ? o.childNodes.length : void 0)) return n
            }
        }, E = function(t) {
            return t.defaultPrevented ? void 0 : (document.removeEventListener("click", T, !1), document.addEventListener("click", T, !1))
        }, T = function(t) {
            var e;
            return t.defaultPrevented || (e = y(t), "A" !== e.nodeName || C(t, e)) ? void 0 : (F() || re(e.href), t.preventDefault())
        }, y = function(t) {
            var e;
            for (e = t.target; e.parentNode && "A" !== e.nodeName;) e = e.parentNode;
            return e
        }, d = function(t) {
            return location.protocol !== t.protocol || location.host !== t.host
        }, n = function(t) {
            return (t.hash && V(t)) === V(location) || t.href === location.href + "#"
        }, M = function(t) {
            var e;
            return e = V(t), e.match(/\.[a-z]+(\?.*)?$/g) && !e.match(new RegExp("\\.(?:" + S.join("|") + ")?(\\?.*)?$", "g"))
        }, D = function(t) {
            for (var e; !e && t !== document;) e = null != t.getAttribute("data-no-turbolink"), t = t.parentNode;
            return e
        }, J = function(t) {
            return 0 !== t.target.length
        }, L = function(t) {
            return t.which > 1 || t.metaKey || t.ctrlKey || t.shiftKey || t.altKey
        }, C = function(t, e) {
            return d(e) || n(e) || M(e) || D(e) || J(e) || L(t)
        }, e = function() {
            var t, e, n, r;
            for (e = 1 <= arguments.length ? ae.call(arguments, 0) : [], n = 0, r = e.length; r > n; n++) t = e[n], S.push(t);
            return S
        }, l = function(t) {
            return setTimeout(t, 500)
        }, A = function() {
            return document.addEventListener("DOMContentLoaded", function() {
                return ne("page:change"), ne("page:update")
            }, !0)
        }, O = function() {
            return "undefined" != typeof jQuery ? jQuery(document).on("ajaxSuccess", function(t, e) {
                return jQuery.trim(e.responseText) ? ne("page:update") : void 0
            }) : void 0
        }, N = function(t) {
            var e, n;
            return (null != (n = t.state) ? n.turbolinks : void 0) ? (e = R[t.state.url]) ? (u(), b(e)) : re(t.target.location.href) : void 0
        }, P = function() {
            return Y(), W(), h = r(), document.addEventListener("click", E, !0), l(function() {
                return window.addEventListener("popstate", N, !1)
            })
        }, k = void 0 !== window.history.state || navigator.userAgent.match(/Firefox\/2[6|7]/), s = window.history && window.history.pushState && window.history.replaceState && k, i = !navigator.userAgent.match(/CriOS\//), Z = "GET" === (oe = H("request_method")) || "" === oe, a = s && i && Z, o = document.addEventListener && document.createEvent, o && (A(), O()), a ? (re = x, P()) : re = function(t) {
            return document.location.href = t
        }, this.Turbolinks = {
            visit: re,
            pagesCached: q,
            enableTransitionCache: g,
            allowLinkExtensions: e,
            supported: a
        }
    }.call(this),
    function() {
        var t, e;
        e = "undefined" != typeof exports && null !== exports ? exports : this, t = {
            elements: {
                selectors: ["img"]
            }
        }, $(document).on("page:fetch page:change", function() {
            return Pace.restart()
        }), e.on_page_load(function() {
            return $(document.body).hasClass("articles-show") ? ($("pre code").each(function() {
                return hljs.highlightBlock(this)
            }), "undefined" != typeof DISQUS && null !== DISQUS ? DISQUS.reset({
                reload: !0,
                config: function() {
                    return this.page.url = window.location, this.page.language = "en"
                }
            }) : void 0) : void 0
        }), $(document).on("click", ".nav-toggle", function(t) {
            return $("#primary-nav").toggle(), t.preventDefault() && !1
        }), $(document).on("page:fetch page:change", function() {
            return $("#search-link").removeAttr("href"), $("#search-link").click(function() {
                return $("#search-container").toggleClass("icon-search-hidden"), $("#search-container").toggleClass("icon-search-visible"), $("#nav-search-text-box").focus()
            })
        })
    }.call(this);