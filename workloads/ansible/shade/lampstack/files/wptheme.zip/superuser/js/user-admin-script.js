jQuery( document ).ready(function() {
	jQuery("#send_user_notification").attr("checked", false);
	jQuery(".user-description-wrap").css("display", "none");
});