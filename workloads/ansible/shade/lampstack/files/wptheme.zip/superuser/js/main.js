jQuery(function($) {
	$('.article-card')
		.each(function() {
			var self = $(this),
				cover = self.find('.article-cover'),
				rider = self.find('.rider'),
				content = self.find('.content'),
				self_height = self.height(),
				cover_height = cover.outerHeight(), 
				content_height = content.outerHeight(),
				rider_height = rider.outerHeight();
				
				rider.css('transform', 'translate(0, -' + (rider_height + rider.next().outerHeight()) + 'px)');
				content.css('transform', 'translate(0, -' + (rider_height - (self_height - cover_height - content_height)) + 'px)');
				cover.css('transform', 'translate(0, -' + ((cover_height - (self_height - content_height - rider_height)) / 2) + 'px)');
		})
		.on('mouseover mouseout', function() {
			var self = $(this);
			requestAnimationFrame(function(timestamp) {
				self.toggleClass('hover');
			});
		});
});
