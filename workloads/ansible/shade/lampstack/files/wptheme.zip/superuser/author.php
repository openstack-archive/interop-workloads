<?php
/**
 * The template for displaying search results pages.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package superuser
 */

get_header(); ?>
	<section id="primary" class="content-area">
		<main id="main" class="site-main search-page container" role="main">
			<div class="search-page ">
				<?php
				if ( have_posts() ) :
					$wp_query->query_vars["posts_per_page"] = 1500;
					$wp_query->get_posts();
				 ?>

					<header class="grid cf">
						<div class="author_avatar"><?php echo get_photo_or_avatar(get_the_author_meta( 'ID' ), 90 ); ?></div>
						<div class="author_bio">
							<h1 class="author-pag-title"><?php printf( esc_html__( "%s", "superuser" ), '<span>' .  get_the_author() . '</span>' ); ?></h1>
							<?php the_field('biography', 'user_'.get_the_author_meta( 'ID' )); ?>
						</div>
					</header><!-- .page-header -->
					<div class="results-container grid">
						<div class="results-articles-container col col--2-of-3">
							<?php
							$num = $wp_query->post_count;
							?>

							<h3><?php echo $num ?> articles from <?php the_author()?></h3>
							<?php
							/* Start the Loop */
							while ( have_posts() ) : the_post();

								get_template_part( 'template-parts/content', 'search' );

							endwhile;

							the_posts_navigation();
							?>
						</div>
						<?php get_sidebar('inner'); ?>
					</div>
				<?php
				else :

					get_template_part( 'template-parts/content', 'none' );

				endif; ?>
			
			</div>
		</main><!-- #main -->
	</section><!-- #primary -->

<?php
get_footer();
