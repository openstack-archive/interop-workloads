<?php
/**
 * The header for our theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package superuser
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico">
<!--
<script type="text/javascript" src="//use.typekit.net/kwc8mda.js"></script>
<script type="text/javascript">try{Typekit.load();}catch(e){}</script>
-->
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/js/highlight/styles/default.css">
<script src="<?php echo get_template_directory_uri(); ?>/js/highlight/highlight.pack.js"></script>
<script>hljs.initHighlightingOnLoad();</script>
<?php wp_head(); ?>

</head>

<body <?php body_class(); ?>>
<div id="page" class="site">
	<header class="page-header">
		<div class="page-header-container container">
			<div class="logo">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<img src="<?php echo get_template_directory_uri(); ?>/images/superuser.svg" class="logomark" alt="&gt; SU">
					<img src="<?php echo get_template_directory_uri(); ?>/images/superuser-wordmark.png" class="wordmark" alt="OpenStack Superuser">
				</a>
			</div>

			<nav>
				<?php 
					wp_nav_menu( array(
					    'menu' => 'Main menu',
					    'menu_id' => 'primary-nav',
					) );
					?>
				<a href="#primary-nav" class="nav-toggle">Menu</a>
			</nav>
			
			<div id="search-container" class="container search-container icon-search-hidden">
				<form role="search" method="get" id="nav-search-form" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
					<img class="nav-search-icon icon-search" src="<?php echo get_template_directory_uri(); ?>/images/search-icon-navy.svg" alt="Search icon navy">
					<input type="text" required="required" placeholder="Type to search" name="s" id="nav-search-text-box" class="search-text-field" autocomplete="off">
					<input type="submit" value="Search" class="button">
				</form>
			</div>
		</div>
	</header>
	<div id="content" class="site-content">