<?php
/**
 * Template part for displaying results in search pages.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package superuser
 */

?>
<div class="result-container grid">
	<div class="image-container col col--2-of-12">
		<a href="<?php the_permalink(); ?>">
			<img alt="<?php the_title(); ?>" src="<?php the_post_thumbnail_url( 'search-result' ); ?>" / >
		</a>
	</div>
	<div class="information-container col col--10-of-12">
		<h2 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		<p class="summary"><?php echo get_the_excerpt(); ?></p>
		<?php if ( 'post' === get_post_type() ) : ?>
		<?php echo get_the_tag_list('<p class="post_tags">Tags: ',', ','</p>'); ?>
			<p class="author">
				<?php 
				if (!is_author()) {
					echo get_photo_or_avatar(get_the_author_meta( 'ID' ), 45 ); 
					the_author_posts_link();
				} else {
				?>
						Published 
				<?php
				}
				?>
					on 
				<?php echo get_the_date(); ?>
			</p>
		<?php endif; ?>
	</div>
</div>