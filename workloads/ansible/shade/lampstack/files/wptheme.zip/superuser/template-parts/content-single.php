<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package superuser
 */

?>

<div class="article-header" style="background-image: url(<?php echo get_image_or_fallback($post->ID, 'header-image');?>);">
	<div class="overlay"></div>
	<div class="content">
		<div class="container">
	  		<div class="grid">
				<div class="col col--2-of-2">
					<div class="cover-image">
						<?php echo get_image_or_fallback($post->ID, 'featured-image');?>
					</div>
					<div class="article-category">
						<span><?php $categories = get_the_category ();
						echo $categories[0]->name; ?></span>
					</div>
					<h1>
						<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
					</h1>
				</div>
				<div class="col col--2-of-3">
					<div class="article-rider">
						<?php the_excerpt(); ?>
					</div>
				</div>
				<div class="col col--1-of-3">
					<div class="article-metadata">
						<?php
						echo get_authors_list();
						?>
						<div class="publication-date"><?php echo get_the_date(); ?></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="container">
	<div class="grid">
		<div class="col col--2-of-3">
			<div class="article-body">
				<?php the_content(); ?>
			</div>
			<div class="comments">
				<?php // the_post_navigation();
				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;
			?>	
			</div>

		</div>
		<?php get_sidebar('inner'); ?>
	</div>
</div>