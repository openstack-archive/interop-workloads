<?php
/**
 * Template part for displaying page content in page.php.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package superuser
 */

?>

<div id="post-<?php the_ID(); ?>" <?php post_class('static-page'); ?>>
	<div class="container">
  		<div class="grid">
			<div class="col col--1-of-4">
				<nav id="sidebar">
				<?php if ( is_nav_menu( 'Superuser' )) { ?>
					<div class="nav-group widget widget_nav_menu">
					<h4>Superuser</h4>
					<?php 
					wp_nav_menu( array(
					    'menu' => 'Superuser',
					    'container' => 'div',
					    'container_class' => 'menu-container',
					) );
					?>
					</div>
				<?php } ?>
				<?php if ( is_nav_menu( 'Community' )) { ?>
					<div class="nav-group widget widget_nav_menu">
					<h4>Community</h4>
					<?php
					wp_nav_menu( array(
					    'menu' => 'Community',
					    'container' => 'div',
					    'container_class' => 'menu-container',
					) );
					?>
					</div>
				<?php } ?>
				<?php if ( is_nav_menu( 'User Resources' )) { ?>
					<div class="nav-group widget widget_nav_menu">
					<h4>User Resources</h4>
					<?php
					wp_nav_menu( array(
					    'menu' => 'User Resources',
					    'container' => 'div',
					    'container_class' => 'menu-container',
					) );
					?>
					</div>
				<?php } ?>
				</nav>
			</div>	
			<div class="col col--3-of-4">
				<div class="content">
				<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
					<?php the_content(); ?>
				</div><!-- .entry-content -->
			</div>
		</div>
</div><!-- #post-## -->
