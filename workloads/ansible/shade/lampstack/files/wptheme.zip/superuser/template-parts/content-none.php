<?php
/**
 * Template part for displaying a message that posts cannot be found.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package superuser
 */

?>

<section id="primary" class="content-area">
	<main id="main" class="site-main search-page container" role="main">
		<div class="search-page ">
		<?php if ( is_search() ) : ?>
			<header class="grid">
				<h1 class="search-page-title"><?php printf( esc_html__( 'Search Results for: %s', 'superuser' ), '<span>' . get_search_query() . '</span>' ); ?></h1>
				<?php get_template_part( 'template-parts/content', 'searchform' );?>
			</header><!-- .page-header -->
		<?php else : ?>
			<header class="page-header">
				<h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'superuser' ); ?></h1>
			</header><!-- .page-header -->
		<?php endif; ?>

			

			<div class="results-container grid">
				<div class="results-articles-container col col--2-of-3">
				
				<?php if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>
						<p><?php printf( wp_kses( __( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'superuser' ), array( 'a' => array( 'href' => array() ) ) ), esc_url( admin_url( 'post-new.php' ) ) ); ?></p>
				
				<?php elseif ( is_search() ) : ?>

						
					<h2>Your search - <em><?php printf( esc_html__( '%s', 'superuser' ), '<span>' . get_search_query() . '</span>' ); ?></em> - did not match any articles.</h2>

					<p>Suggestions:</p>

					<ul class="no-results-list">
						<li>Make sure all words are spelled correctly.</li>
						<li>Try different keywords.</li>
						<li>Try more general keywords.</li>
					</ul>

				
				<?php else : ?>
						
						<p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'superuser' ); ?></p>
						<div class="search-footer search-container grid">
							<?php get_template_part( 'template-parts/content', 'searchform' );?>
						</div>
				
				<?php endif; ?>
				</div>
				<?php get_sidebar('inner'); ?>
			</div>
		</div>
	</main>
</section><!-- .no-results -->
