<?php
/**
 * Template part for searchform.
 *
 *
 * @package superuser
 */

?>
<div class="search-container">
	<form role="search" action="<?php echo esc_url( home_url( '/' ) ); ?>" id="search-form" method="get">
		<div class="grid">
			<div class="col col--10-of-12">
				<img alt="Search icon navy" class="search-page-icon icon-search" src="<?php echo get_template_directory_uri(); ?>/images/search-icon-navy.svg">
				<input autocomplete="off" class="search-text-field" id="search-page-text-box" name="s" placeholder="Type to search" required="required" value="<?php echo get_search_query(); ?>" type="text">
			</div>
			<div class="col col--2-of-12">
				<input class="button" value="Search" type="submit">
			</div>
		</div>
	</form>
</div>