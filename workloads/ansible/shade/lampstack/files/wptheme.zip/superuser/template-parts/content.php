<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package superuser
 */

?>
<li id="post-<?php the_ID(); ?>" <?php post_class('card-container col'); ?> >
	<div class="article-card">
		<a href="<?php the_permalink(); ?>">
			<div class="article-cover">		
				<?php echo get_image_or_fallback($post->ID, 'featured-image');?>
				<div class="date">
					<?php echo get_the_date(); ?>
				</div>
			</div>
			<div class="content">
				<h3><?php the_title(); ?></h3>
			</div>
			<div class="rider">
				<?php the_excerpt(); ?>
			</div>
			<div class="metadata">
				<div class="author">
					<?php echo get_authors_list(20, false); ?>
				</div>	
			</div>
		</a>
	</div>
</li>