<?php

// Update scripts and styles version
function _update_script_version( $src ){
    $ver = "20161003";
    return preg_replace('%ver=[\d\.]+%i', 'ver='.$ver, $src);;
}
add_filter( 'script_loader_src', '_update_script_version', 15, 1 );
add_filter( 'style_loader_src', '_update_script_version', 15, 1 ); 

/**
 * superuser functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package superuser
 */

if ( ! function_exists( 'superuser_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function superuser_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on superuser, use a find and replace
	 * to change 'superuser' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'superuser', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => esc_html__( 'Primary', 'superuser' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

}
endif;
add_action( 'after_setup_theme', 'superuser_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function superuser_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'superuser_content_width', 640 );
}
add_action( 'after_setup_theme', 'superuser_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */

/**
 * Enqueue scripts and styles.
 */
function superuser_scripts() {
	wp_enqueue_style( 'superuser-style', get_stylesheet_uri() );
	
	//wp_enqueue_style( 'highlight-style', get_template_directory_uri(). '/js/highlight/styles/default.css');

	//wp_enqueue_script( 'superuser-pace', get_template_directory_uri() . '/js/pace.min.js', array(), '20151215', true );
	wp_enqueue_script( 'enquire', get_template_directory_uri() . '/js/enquire.min.js', array(), '20151215', true );
	wp_enqueue_script( 'waypoints', get_template_directory_uri() . '/js/waypoints.js', array(), '20151215', true );

	//wp_enqueue_script( 'highlight', get_template_directory_uri() . '/js/highlight/highlight.pack.js', array(), '20160815', true );

	wp_enqueue_script( 'superuser-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'superuser-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	wp_enqueue_script( 'superuser-application', get_template_directory_uri() . '/js/application.js', array('jquery'), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}


add_action( 'wp_enqueue_scripts', 'superuser_scripts' );


/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';


add_image_size( 'featured-image', 387, 258, true);
add_image_size( 'featured-half-image', 387, 110, true);
add_image_size( 'header-image', 1500, 3000, true);
add_image_size( 'inline-image', 250, 750, true);
add_image_size( 'block-image', 607, 1800, false);
add_image_size( 'full-width-image', 793, 2400, false);
add_image_size( 'search-result', 600, 400, true);



add_filter('wp_nav_menu_items','add_search_box', 10, 2);

function add_search_box( $nav, $args ) {
    if( $args->theme_location == 'primary' )
        return $nav.'<li><a id="search-link" class="search-link" href="'. esc_url( home_url( '/' ) ). '"><img class="icon-search" src="'. get_template_directory_uri().'/images/search-icon-white.svg" alt="Search icon white"></a></li>';
    return $nav;
}

// Register fields for Select Post Widget based on sidebar area
if (function_exists('spw_register_field')){
	spw_register_field(
		array(
			'widget' => array('post'),
			'sidebars' => array('home-sidebar', 'inner-sidebar'),
			'id' => 'layout',
			'label' => 'Layout',
			'type' => 'radio',
			'values' => array('full' => 'Full', 'featured' => 'Featured', 'trending' => 'Trending'),
			'default' => 'full',
		)
	);
}

// Add a default avatar to Settings > Discussion
if ( !function_exists('su_addgravatar') ) {
	function su_addgravatar( $avatar_defaults ) {
		$myavatar = get_bloginfo('template_directory') . '/images/social-icon-bracket.png';
		$avatar_defaults[$myavatar] = 'Superuser';

		return $avatar_defaults;
	}

	add_filter( 'avatar_defaults', 'su_addgravatar' );
} 


//User use avatar if no user Photo is set


function get_photo_or_avatar($authorID, $size){
	
	$image = get_field('user_photo', 'user_'.$authorID);

	if( $image ) {
		$show = wp_get_attachment_image( $image, array($size, $size), "", array( "class" => "avatar-45" ) );
	} else{
		$show = get_avatar( $authorID, $size );
	}
	
	return $show; 
}


function edit_user_enqueue($hook) {
    if ( 'user-new.php' != $hook && 'user-edit.php' != $hook ) {
        return;
    }

    wp_enqueue_script( 'user-admin-script', get_template_directory_uri() . '/js/user-admin-script.js' );
}
add_action( 'admin_enqueue_scripts', 'edit_user_enqueue' );

// Remove related posts at the bottom of each post
add_filter( 'wp', 'jetpackme_remove_rp', 20 );
function jetpackme_remove_rp() {
	if (class_exists("Jetpack_RelatedPosts")){
	    $jprp = Jetpack_RelatedPosts::init();
	    $callback = array( $jprp, 'filter_add_target_to_dom' );
	    remove_filter( 'the_content', $callback, 40 );
	}
}




add_filter('the_content', 'show_tags', 1 );

function show_tags($content){
	if (is_singular('post')) {
		$content = $content . get_the_tag_list('<p class="post_tags">Tags: ',', ','</p>');
	}
	return $content;
}


add_filter( 'mce_buttons_2', 'superuser_mce_buttons_2' );

function superuser_mce_buttons_2( $buttons ) {
    array_unshift( $buttons, 'styleselect' );
    return $buttons;
}

add_filter( 'tiny_mce_before_init', 'superuser_mce_style_formats' );
function superuser_mce_style_formats( $settings ) {

	$style_formats = array(
		array(
			'title' => 'Images',
			'items' => array(
				array(
					'title' => 'Full width',
					'selector' => 'img',
					'classes' => 'size-full-width-image',
					'wrapper' => false
				),
			)
		),
		array(
			'title' => 'Codes',
			'items' => array(
				array(
					'title' => 'Html',
					'block' => 'code',
					'classes' => 'html',
					'wrapper' => true
				),
				array(
					'title' => 'Coffescript',
					'block' => 'code',
					'classes' => 'coffescript',
					'wrapper' => true
				),
				array(
					'title' => 'Css',
					'block' => 'code',
					'classes' => 'css',
					'wrapper' => true
				),
				array(
					'title' => 'Javascript',
					'block' => 'code',
					'classes' => 'javascript',
					'wrapper' => true
				),
				array(
					'title' => 'Perl',
					'block' => 'code',
					'classes' => 'perl',
					'wrapper' => true
				),
				array(
					'title' => 'Python',
					'block' => 'code',
					'classes' => 'python',
					'wrapper' => true
				),
				array(
					'title' => 'Ruby',
					'block' => 'code',
					'classes' => 'ruby',
					'wrapper' => true
				),
				array(
					'title' => 'Xml',
					'block' => 'code',
					'classes' => 'xml',
					'wrapper' => true
				),							
			)
		),
	);

	// Styles select
	$settings['style_formats'] = json_encode( $style_formats );
	$settings['style_formats_merge'] = false;

	return $settings;

}

// Add custom css to RTE
function superuser_theme_add_editor_styles() {
    add_editor_style( 'editor_style.css' );
}
add_action( 'admin_init', 'superuser_theme_add_editor_styles' );


// remove extra buttons from acf rte
//http://www.advancedcustomfields.com/resources/customize-the-wysiwyg-toolbars/

add_filter( 'acf/fields/wysiwyg/toolbars' , 'sapiens_toolbars'  );
function sapiens_toolbars( $toolbars ){

	$toolbars['Simple' ] = array();
	$toolbars['Simple' ][1] = array('bold' , 'italic', 'separator','link', 'unlink' );

	return $toolbars;
}

// Add Styles to the Admin Panel

add_action( 'admin_enqueue_scripts', 'load_admin_style', 10, 2);
function load_admin_style() {
	wp_enqueue_style( 'admin_css', get_template_directory_uri() . '/admin_styles.css', false, '1.0.0' );
}

// Format caption in HTML shortcode for theme
add_filter( 'img_caption_shortcode', 'custom_caption_html', 10, 3 );
function custom_caption_html( $current_html, $attr, $content ) {
	extract(shortcode_atts(array(
		'id'    => '',
		'align' => 'alignnone',
		'width' => '',
		'caption' => ''
	), $attr));
	if ( 1 > (int) $width || empty($caption) )
		return $content;

	$credits = get_field('credits', str_replace('attachment_', '', $id));
	$usage_rights = get_field('usage_rights', str_replace('attachment_', '', $id));

	$print_credits_usage_rights = isset($usage_rights) ? ' // <small>' . $usage_rights . '</small>' : false ;
	
	if ($credits) $print_credits = '<small>' . $credits . '</small>';
	$print_credits = str_replace('<p>', '', $print_credits);
	$print_credits = str_replace('</p>', '', $print_credits);

	$title = get_the_title();
	if ($title) $print_title = '<strong class="image-title">' . $title . '</strong>';

	if ( $id ) $id = 'id="' . esc_attr($id) . '" ';

	return '<figure ' . $id . 'class="wp-caption ' . esc_attr($align) . '" style="width: ' . (10 + (int) $width) . 'px">'
	. do_shortcode( $content ) . '<figcaption class="wp-caption-text">
	<span>' . $caption . '</span> ' .$print_credits. $print_credits_usage_rights . '</figcaption>
	</figure>';
}

// Use custom caption on TinyMCE on Editor Admin
add_filter( 'media_send_to_editor', 'use_custom_caption_admin', 20, 3 );

function use_custom_caption_admin( $html, $id, $attachment ) {

	$custom_caption = get_field('custom_caption', $attachment['id'], false, false);
	$credits = get_field('credits', $attachment['id'], false, false);
	$usage_rights = get_field('usage_rights', $attachment['id'], false, false);

	if(strpos($html, '[caption') !== FALSE ){
		$close_link = strpos($html, '</a>');
    	$beginning = substr($html, 0, $close_link);
    	$html = $beginning . '</a>' . $custom_caption .' '.$credits.' '.$usage_rights. '[/caption]';
	} else {

		$meta_data = wp_get_attachment_metadata($attachment['id']);
		$size = $attachment['image-size'];
		$image_width = $meta_data['sizes'][$size]['width'];

		$class_start = strpos($html, '="align');
    	$beginning_class = substr($html, $class_start, 20);
    	$classes = trim(substr($beginning_class, 2));
    	$class = explode(' ', $classes);

		$caption_start = '[caption id="attachment_'.$attachment['id'].'" align="' . $class[0] . '" width="'.$image_width.'"]';
		$caption_end = $custom_caption.' '.$credits.' '.$usage_rights. "[/caption]";

		$html = $caption_start . $html . $caption_end;

	}
	return $html;
}


function sapiens_feed_format($content) {

	// Add featurd image at the top
	if (get_field('header_image')) {
		$image = get_field('header_image');
		$thumb_id = $image['id'];
		if (preg_match("%\.gif$%", $image['url'])){
			$image = wp_get_attachment_image( $image['id'], 'full' );
		} else {
			$image = wp_get_attachment_image( $image['id'], 'article-featured' );
		}

		$header_html = '<figure itemscope itemtype="http://schema.org/ImageObject" itemprop="image" class="featured-image">';
		$header_html .= $image;

		if( get_field('custom_caption', $thumb_id, false, false) != '') {
			$header_html .= '<figcaption>
				<span itemprop="caption">'. get_field('custom_caption', $thumb_id, false, false) . '</span>
				<small itemprop="publisher">'.  str_replace(array('<p>','</p>'),'',get_field('credits',$thumb_id)) . '</small>
			</figcaption>';
		}
			
		$header_html .= '</figure>';

		$content = $header_html . $content;
	}

	// For aside
	$content = preg_replace('%<aside([^>]*)>(.*?)</aside>%si', '<blockquote$1>$2</blockquote>', $content);
	// For figcaption
	$content = preg_replace('%<figcaption([^>]*)>(.*?)</figcaption>%si', '<figcaption$1><small><i>$2</i></small></figcaption>', $content);

	return $content;
}


add_filter('the_content', 'show_credits', 0 );

function show_credits($content){
	if (is_singular('post') && get_field('credits', get_post_thumbnail_id())) {
		$content = $content . '<div class="credits">'.get_field('credits', get_post_thumbnail_id(), false, false).' // '.get_field('usage_rights', get_post_thumbnail_id(), false, false).'</div>';
	}
	return $content;
}

function show_featured_area() {
	global $wp_registered_widgets;
	$widgets = wp_get_sidebars_widgets(); 
	$widgets_count = count($widgets['home_main_featured-sidebar']);

	if($widgets_count >=1){
		foreach ($widgets['home_main_featured-sidebar'] as $widget) {
			$main_featured = $wp_registered_widgets[$widget]['name'];
		}
	}

	if ( is_active_sidebar( 'home_main_featured-sidebar' ) && $main_featured == 'Select post' && $widgets_count == 1 ) :
		return dynamic_sidebar( 'home_main_featured-sidebar' ); 
	endif;
}


function get_authors_list($avatar_size = '45',$use_links = true) {
	$authors_list .= '<div class="author-name">';
	if ( function_exists( 'coauthors_posts_links' ) ) {
		$coauthors = get_coauthors();
		if (count($coauthors)>=2) {
			$authors_list .='<ul class="authors_list">';
			foreach( $coauthors as $coauthor ):
				$authors_list .='<li>';
				$authors_list .=  get_photo_or_avatar($coauthor->ID , '20' );
				if ($use_links == true){
					$authors_list .= '<a href="'.get_author_posts_url( $coauthor->ID ).'">'. get_the_author_meta( 'display_name', $coauthor->ID ). '</a>';
		 		} else {
		 			$authors_list .= get_the_author_meta( 'display_name', $coauthor->ID );
		 		}
		 		$authors_list .='</li>';
		 	endforeach; 
			$authors_list .='</ul>';
		} else {
			$authors_list .=  get_photo_or_avatar(get_the_author_meta( 'ID' ), $avatar_size );
			if ($use_links == true){
				$authors_list .= get_the_author_posts_link();
			} else {
				$authors_list .= get_the_author_meta( 'display_name', $coauthor->ID );
			}
		} 
	

	} else {
		$authors_list .=  get_photo_or_avatar(get_the_author_meta( 'ID' ), $avatar_size );
		$authors_list .= get_the_author_posts_link();
	}

	$authors_list .= '</div>';
	return $authors_list;
}
//turn on filter for rss and remove filters that duplicate the value

function create_multiple_authors_feed() {  
    load_template( TEMPLATEPATH . '/feed-rss2.php');  
}  
add_feed('rss2', 'create_multiple_authors_feed');



require_once get_template_directory() . '/inc/class-tgm-plugin-activation.php';
add_action( 'tgmpa_register', 'su_register_required_plugins' );


function su_register_required_plugins() {
	/*
	 * Array of plugin arrays. Required keys are name and slug.
	 * If the source is NOT from the .org repo, then source is also required.
	 */
	$plugins = array(

		// This is an example of how to include a plugin bundled with a theme.
		array(
			'name'               => 'Advanced Custom Fields', // The plugin name.
			'slug'               => 'advanced-custom-fields', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
			),

		array(
			'name'               => 'Cforms 2', // The plugin name.
			'slug'               => 'cforms2', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
		),
			
		array(
			'name'               => 'Co-Authors Plus', // The plugin name.
			'slug'               => 'co-authors-plus', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
		),
		
		array(
			'name'               => 'Disable Domments', // The plugin name.
			'slug'               => 'disable-comments', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
		),

		array(
			'name'               => 'PDB ajax load posts', // The plugin name.
			'slug'               => 'pbd-ajax-load-posts', // The plugin slug (typically the folder name).
			'source'             => get_template_directory() . '/src/plugins/pbd-ajax-load-posts.zip', // The plugin source.
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
		),
		
		array(
			'name'               => 'PMZEZ page loader', // The plugin name.
			'slug'               => 'pmzez-page-loader', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
		),

		array(
			'name'               => 'Responsive Lightbox', // The plugin name.
			'slug'               => 'responsive-lightbox', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
		),

		array(
			'name'               => 'Share links', // The plugin name.
			'slug'               => 'share-links', // The plugin slug (typically the folder name).
			'source'             => get_template_directory() . '/src/plugins/share-links.zip', // The plugin source.
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
		),


	);

	/*
	 * Array of configuration settings. Amend each line as needed.
	 */
	$config = array(
		'id'           => 'superuser',             // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' =>  '',                     // Default absolute path to bundled plugins.
		'menu'         => 'tgmpa-install-plugins', // Menu slug.
		'parent_slug'  => 'themes.php',            // Parent menu slug.
		'capability'   => 'edit_theme_options',    // Capability needed to view plugin install page, should be a capability associated with the parent menu used.
		'has_notices'  => true,                    // Show admin notices or not.
		'dismissable'  => false,                   // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => true,                    // Automatically activate plugins after installation or not.
		'message'      => '',                      // Message to output right before the plugins table.

	);

	tgmpa( $plugins, $config );
}


function required_plugins() {

	include_once ABSPATH . 'wp-admin/includes/plugin.php';

	if ( !is_plugin_active( 'advanced-custom-fields/acf.php' ) ) {
	    $required_list .= "<li>Advanced custom fields</li>";
	}
	if ( !is_plugin_active( 'disable-comments/disable-comments.php' ) ) {
	    $required_list .= "<li>Disable comments</li>";
	}
	if ( !is_plugin_active( 'co-authors-plus/co-authors-plus.php' ) ) {
	    $required_list .= "<li>Co authors plus</li>";
	}
	if ( !is_plugin_active( 'cforms2/cforms.php' ) ) {
	    $required_list .= "<li>Cforms 2</li>";
	}
	if ( !is_plugin_active( 'pmzez-page-loader/myfunction.php' ) ) {
	    $required_list .= "<li>Pmzez page loader</li>";
	}
	if ( !is_plugin_active( 'share-links/share.php' ) ) {
	    $required_list .= "<li>Share links</li>";
	}	

	if ( !is_plugin_active( 'responsive-lightbox/responsive-lightbox.php' ) ) {
	    $required_list .= "<li>Responsive-lightbox</li>";
	}
	if ( !is_plugin_active( 'pbd-ajax-load-posts/pbd-ajax-load-posts.php' ) ) {
	    $required_list .= "<li>Pbd ajax load posts</li>";
	}

	if (isset($required_list)){
		$required_list = "<ul>".$required_list."</ul>";
		$required_list = "<h3>The following plugins are required. Please install and activate them from the <a style='border-bottom:1px dashed #999;' href='".esc_url( home_url( '/' ) )."wp-admin/themes.php?page=tgmpa-install-plugins&plugin_status=install'>required plugins administration page</a>.</h3>".$required_list;
		return $required_list;
	}
}

function get_image_or_fallback($id, $size){

	switch ($size) {
		case 'header-image':
			$fallback_size = "";
			break;
		case 'featured-half-image':
			$fallback_size = "-387x110";
			break;
		case 'thumbnail':
			$fallback_size = "-150x150";
			break;
		case 'featured-image':
			$fallback_size = "-387x258";
			break;		
	}

	$src = (get_the_post_thumbnail_url( $id, $size )) ? get_the_post_thumbnail_url( $id, $size ) : get_template_directory_uri()."/images/featured-image-fallback".$fallback_size.".jpg";
	
	if ($size=='header-image') {
		$image = $src;	
	} else {
		$image = "<img src='".$src."' class='cover-image' alt='".get_the_title()."'>";
	}	
	
	
	return $image;
}


add_action( 'after_switch_theme', 'add_superuser_theme_options' );

function add_superuser_theme_options() {

	if ( !get_option('plugins-setings-initial-updated') == 1) {
		add_option( 'plugins-setings-initial-updated', 1 );

		$sharing_options = 'a:1:{s:6:"global";a:5:{s:12:"button_style";s:4:"icon";s:13:"sharing_label";s:11:"Share this:";s:10:"open_links";s:4:"same";s:4:"show";a:1:{i:0;s:4:"post";}s:6:"custom";a:0:{}}}';
		$sharing_options = unserialize($sharing_options);
		update_option( 'sharing-options', $sharing_options );
		
			
		$sharing_services ='a:2:{s:7:"visible";a:3:{i:0;s:7:"twitter";i:1;s:8:"facebook";i:2;s:13:"google-plus-1";}s:6:"hidden";a:0:{}}';
		$sharing_services = unserialize($sharing_services);
		update_option( 'sharing-services', $sharing_services );
		
		$sl_social_networks ='a:4:{i:0;s:8:"facebook";i:1;s:7:"twitter";i:2;s:10:"googleplus";i:3;s:8:"linkedin";}';
		$sl_social_networks = unserialize($sl_social_networks);
		update_option( 'sl_social_networks', $sl_social_networks );
		
		$sl_custom_post_types ='a:1:{i:0;s:4:"post";}';
		$sl_custom_post_types = unserialize($sl_custom_post_types);
		update_option( 'sl_custom_post_types', $sl_custom_post_types );
		
		$pmzez_lazy_loader_options ='a:1:{s:9:"all_color";s:7:"#00abef";}';
		$pmzez_lazy_loader_options = unserialize($pmzez_lazy_loader_options);
		update_option( 'pmzez_lazy_loader_options', $pmzez_lazy_loader_options );
		
		$sl_share_label = '';
		update_option( 'sl_share_label', $sl_share_label );
		
		$sl_colorized = 'print';
		update_option( 'sl_colorized', $sl_colorized );
		
		$sl_show_total = '';
		update_option( 'sl_show_total', $sl_show_total );
				
		$sl_position = 'bottom';
		update_option( 'sl_position', $sl_position );
		
		$sl_on_archive = '';
		update_option( 'sl_on_archive', $sl_on_archive );
		
		$sl_twitter_via = '@openstack';
		update_option( 'sl_twitter_via', $sl_twitter_via );
		
		$disable_comments_options = 'a:5:{s:19:"disabled_post_types";a:3:{i:0;s:4:"post";i:1;s:4:"page";i:2;s:10:"attachment";}s:17:"remove_everywhere";b:1;s:9:"permanent";b:0;s:16:"extra_post_types";b:0;s:10:"db_version";i:6;}';
		$disable_comments_options = unserialize($disable_comments_options);
		update_option( 'disable_comments_options', $disable_comments_options );
		
		$responsive_lightbox_settings = 'a:18:{s:6:"script";s:8:"swipebox";s:8:"selector";s:8:"lightbox";s:9:"galleries";b:1;s:18:"gallery_image_size";s:4:"full";s:19:"gallery_image_title";s:7:"caption";s:20:"force_custom_gallery";b:0;s:28:"woocommerce_gallery_lightbox";b:0;s:6:"videos";b:1;s:11:"image_links";b:1;s:11:"image_title";s:7:"caption";s:17:"images_as_gallery";b:1;s:19:"deactivation_delete";b:0;s:13:"loading_place";s:6:"header";s:19:"conditional_loading";b:0;s:20:"enable_custom_events";b:0;s:13:"custom_events";s:12:"ajaxComplete";s:14:"update_version";i:1;s:13:"update_notice";b:0;}';
		$responsive_lightbox_settings = unserialize($responsive_lightbox_settings);
		update_option( 'responsive-lightbox-settings', $responsive_lightbox_settings );
		
		$permalink_structure = '/articles/%postname%/';
		update_option( 'permalink_structure', $permalink_structure );
		
		$category_base = '/section';
		update_option( 'category_base', $category_base );

		wp_delete_post(1); // hello world		

		flush_rewrite_rules();
	}
}