<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package superuser
 */

get_header(); 

$request = $_SERVER['REQUEST_URI'];
$from = (wp_get_referer())?" from ".wp_get_referer().".":"";
$body = "I found a broken link to ".esc_url( home_url( '' ) ).$request.$from;

?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<div class="error-page not-found">
				<div class="container">
					<div class="grid">
						<div class="col col--1-of-3 col--align-middle">
							<img src="<?php echo get_template_directory_uri(); ?>/images/bracket.svg" class="bracket" alt="bracket">
						</div>
						<div class="heading col col--2-of-3 col--align-middle">
							<h1>404: Article Not Found</h1>
							<p class="lead">We couldn't find the page or article you were looking for.</p>
							<p>If you reached this page by following a link on Superuser or another website, please <a href="editor@openstack.org?subject=Broken Link&body=<?php echo $body;?>">let us know</a> so we can fix the mistake.</p>
							<p>In the meantime, perhaps one of these fascinating articles will pique your curiosity.</p>
						</div>
						<div class="col col--2-of-2">
						<?php
						$args = array( 
							'posts_per_page' => 6, 
							'orderby' => 'date', 
							'order' => 'DESC', 
							'ignore_sticky_posts' => 1 );
						query_posts( $args );
						if ( have_posts() ) :
						?>
							<ul class="articles-list grid page_404">
								<?php
								/* Start the Loop */
								while ( have_posts() ) : the_post();

									/*
									 * Include the Post-Format-specific template for the content.
									 * If you want to override this in a child theme, then include a file
									 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
									 */
									get_template_part( 'template-parts/content', get_post_format() );

								endwhile;
							?>
							</ul>
						</div>
						<?php
						else :

							get_template_part( 'template-parts/content', 'none' );

						endif; 

						?>
					</div>
				</div>
			</div>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
