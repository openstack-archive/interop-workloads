<?php
/**
 * The sidebar containing the related-posts-sidebar widget area.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package superuser
 */

$related = false;
if ( class_exists( 'Jetpack_RelatedPosts' ) && method_exists( 'Jetpack_RelatedPosts', 'init_raw' ) ) {
	$related = Jetpack_RelatedPosts::init_raw()
    	->set_query_name( 'jetpackme-related-posts' ) // Optional, name can be anything
    	->get_for_post_id(
            get_the_ID(),
            array( 'size' => 3 )
	    );
}
if ( $related ) { 
    foreach ( $related as $result ) {
        // Get the related post IDs
        $post = get_post( $result[ 'id' ] );
        setup_postdata($post); ?>
        <li id="post-<?php the_ID(); ?>" <?php post_class('mobile-grid articles-list'); ?> >
				<div class="mobile-col articles-list__item">
					<div class="article-card">
						<a href="<?php the_permalink(); ?>">
							<div class="article-cover">
								<img src="<?php the_post_thumbnail_url( 'featured-image' ); ?>" class="cover-image" alt="Build it yourself: How a small team deployed OpenStack">
								<div class="date">
									<?php echo get_the_date(); ?>
								</div>
							</div>
							<div class="content">
								<h3><?php the_title(); ?></h3>
							</div>
							<div class="rider">
								<?php the_excerpt(); ?>
							</div>
							<div class="metadata">
								<div class="author">
									<?php echo get_authors_list(20, false); ?>
								</div>
							</div>
						</a>
					</div>
				</div>
			</li>
        <?php
		wp_reset_postdata();
	}
}
?>
